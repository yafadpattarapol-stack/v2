
import { GoogleGenAI } from "@google/genai";

const getAiClient = () => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing. Please set process.env.API_KEY.");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const generateHRContent = async (prompt: string, context?: string): Promise<string> => {
  try {
    const ai = getAiClient();
    const model = 'gemini-2.5-flash';
    
    // Enhanced System Instruction with Knowledge Base Context
    const systemInstruction = `
      บทบาทของคุณคือ: "EmpowerHR AI" ผู้ช่วยอัจฉริยะประจำองค์กร EmpowerHR
      
      หน้าที่ของคุณ:
      1. ตอบคำถามพนักงานเกี่ยวกับกฎระเบียบ สวัสดิการ และนโยบายของบริษัท โดยอ้างอิงจาก "ข้อมูลบริบท (Context)" ที่ได้รับเป็นหลัก
      2. หากคำถามเกี่ยวข้องกับกฎหมายแรงงานไทย ให้ตอบตามหลักกฎหมาย (พ.ร.บ. คุ้มครองแรงงาน) ควบคู่ไปกับนโยบายบริษัท
      3. หากข้อมูลไม่อยู่ใน Context ให้ตอบตามหลักปฏิบัติทั่วไปของ HR หรือกฎหมายแรงงาน แต่ต้องแจ้งเตือนว่า "อาจต้องตรวจสอบกับฝ่ายบุคคลโดยตรงอีกครั้ง"
      4. ใช้น้ำเสียงสุภาพ เป็นทางการ และช่วยเหลือ (Helpful & Professional)

      ข้อมูลบริบทของบริษัท (Company Knowledge Base):
      ${context || "ไม่มีข้อมูลเพิ่มเติม"}

      ข้อควรระวัง:
      - ห้ามแต่งเติมข้อมูลนโยบายบริษัทขึ้นมาเอง หากไม่มีใน Context
      - หากเป็นเรื่องอ่อนไหว (เช่น การเลิกจ้าง, การลดเงินเดือน) ให้แนะนำให้ติดต่อ HR Manager โดยตรง
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.5, // Reduced temperature for more factual consistency with context
      }
    });

    return response.text || "ขออภัย ระบบไม่สามารถประมวลผลคำตอบได้ในขณะนี้";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "เกิดข้อผิดพลาดในการเชื่อมต่อกับ AI กรุณาตรวจสอบ API Key หรือลองใหม่อีกครั้ง";
  }
};
