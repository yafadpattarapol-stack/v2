
import React, { useState, useMemo, useEffect } from 'react';
import { Employee, CompanySettings, Role, LeaveRequest, LeaveStatus, PayrollRecord, PayrollWorkflowStatus, AppNotification } from '../types';
import { User, LogOut, Settings, Bell, ChevronRight, QrCode, Phone, Mail, Building, MapPin, CreditCard, Shield, RotateCcw, Banknote, ChevronLeft, Download, FileText, Globe, Moon, Lock, Info, CheckCircle2, Megaphone, Trash2, Key, Monitor, Briefcase, Calendar, FolderOpen, Laptop } from 'lucide-react';

interface MobileProfileProps {
  currentUser: Employee;
  companySettings: CompanySettings;
  leaves: LeaveRequest[];
  payroll: PayrollRecord[];
  notifications: AppNotification[]; // New Prop
  onMarkAsRead: (id?: string) => void; // New Prop
  onLogout: () => void;
}

// Separate component for Settings to handle its own state correctly
const SettingsView: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [passForm, setPassForm] = useState({ current: '', new: '', confirm: '' });
  const [isSaving, setIsSaving] = useState(false);

  const handleSavePassword = (e: React.FormEvent) => {
     e.preventDefault();
     if(passForm.new !== passForm.confirm) {
        alert("รหัสผ่านใหม่ไม่ตรงกัน");
        return;
     }
     setIsSaving(true);
     setTimeout(() => {
        setIsSaving(false);
        setPassForm({ current: '', new: '', confirm: '' });
        alert("เปลี่ยนรหัสผ่านเรียบร้อยแล้ว");
     }, 1500);
  };

  return (
     <div className="animate-fade-in space-y-6 pb-20">
        <div className="flex items-center gap-3 mb-2 sticky top-0 bg-slate-50 py-2 z-10">
           <button onClick={onBack} className="p-2 bg-white rounded-full shadow-sm border border-slate-200 text-slate-600 hover:text-slate-900 active:scale-95 transition-transform">
              <ChevronLeft size={20} />
           </button>
           <h3 className="text-xl font-bold text-slate-800">ตั้งค่าบัญชี</h3>
        </div>

        {/* Preference Section */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
           <div className="p-4 border-b border-slate-50 flex justify-between items-center">
              <div className="flex items-center gap-3">
                 <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg"><Globe size={18}/></div>
                 <span className="text-sm font-bold text-slate-700">ภาษา (Language)</span>
              </div>
              <span className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded-lg">ไทย</span>
           </div>
           <div className="p-4 flex justify-between items-center">
              <div className="flex items-center gap-3">
                 <div className="p-2 bg-slate-100 text-slate-600 rounded-lg"><Moon size={18}/></div>
                 <span className="text-sm font-bold text-slate-700">โหมดมืด (Dark Mode)</span>
              </div>
              <div className="w-10 h-6 bg-slate-200 rounded-full relative cursor-pointer"><div className="w-4 h-4 bg-white rounded-full absolute top-1 left-1 shadow-sm"></div></div>
           </div>
        </div>

        {/* Security Section */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
           <h4 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2"><Lock size={16} className="text-slate-400"/> ความปลอดภัย</h4>
           <form onSubmit={handleSavePassword} className="space-y-4">
              <div>
                 <label className="text-xs font-bold text-slate-500 mb-1 block">รหัสผ่านปัจจุบัน</label>
                 <input type="password" required className="w-full border border-slate-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" value={passForm.current} onChange={e => setPassForm({...passForm, current: e.target.value})} />
              </div>
              <div>
                 <label className="text-xs font-bold text-slate-500 mb-1 block">รหัสผ่านใหม่</label>
                 <input type="password" required className="w-full border border-slate-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" value={passForm.new} onChange={e => setPassForm({...passForm, new: e.target.value})} />
              </div>
              <div>
                 <label className="text-xs font-bold text-slate-500 mb-1 block">ยืนยันรหัสผ่านใหม่</label>
                 <input type="password" required className="w-full border border-slate-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" value={passForm.confirm} onChange={e => setPassForm({...passForm, confirm: e.target.value})} />
              </div>
              <button type="submit" disabled={isSaving} className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-indigo-200 active:scale-95 transition-all flex justify-center items-center gap-2">
                 {isSaving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <><Key size={16}/> เปลี่ยนรหัสผ่าน</>}
              </button>
           </form>
        </div>

        {/* App Info */}
        <div className="text-center">
           <p className="text-xs text-slate-400 font-bold">EmpowerHR Mobile</p>
           <p className="text-[10px] text-slate-300">Version 2.5.0 (Build 2025)</p>
        </div>
     </div>
  );
};

export const MobileProfile: React.FC<MobileProfileProps> = ({ currentUser, companySettings, leaves, payroll, notifications, onMarkAsRead, onLogout }) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const [view, setView] = useState<'main' | 'payslip_list' | 'payslip_detail' | 'settings' | 'notifications' | 'documents' | 'assets' | 'history'>('main');
  const [selectedPayslip, setSelectedPayslip] = useState<PayrollRecord | null>(null);

  // Helper
  const formatCurrency = (amount: number) => new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB', maximumFractionDigits: 2 }).format(amount);

  // Simple stats calculation
  const approvedLeaves = leaves.filter(l => l.employeeId === currentUser.id && l.status === LeaveStatus.APPROVED);
  const vacationQuota = companySettings.leaveQuotas.find(q => q.type.includes('Vacation'))?.quota || 6;
  const vacationUsed = approvedLeaves.filter(l => l.type.includes('Vacation')).length;

  // Filter My Payslips
  const myPayslips = useMemo(() => {
     return payroll
        .filter(p => p.employeeId === currentUser.id && p.workflowStatus === PayrollWorkflowStatus.PAID)
        .sort((a, b) => b.month.localeCompare(a.month)); 
  }, [payroll, currentUser.id]);

  // Unread Count
  const unreadCount = notifications.filter(n => !n.isRead).length;

  // --- SUB-VIEWS RENDERERS ---

  const renderNotifications = () => (
     <div className="animate-fade-in space-y-4">
        <div className="flex items-center justify-between mb-4 sticky top-0 bg-slate-50 py-2 z-10">
           <div className="flex items-center gap-3">
              <button onClick={() => setView('main')} className="p-2 bg-white rounded-full shadow-sm border border-slate-200 text-slate-600 hover:text-slate-900 active:scale-95 transition-transform">
                 <ChevronLeft size={20} />
              </button>
              <h3 className="text-xl font-bold text-slate-800">การแจ้งเตือน</h3>
           </div>
           {notifications.length > 0 && (
              <button onClick={() => onMarkAsRead()} className="text-xs font-bold text-blue-600 bg-blue-50 px-3 py-1.5 rounded-lg active:bg-blue-100 transition-colors">
                 อ่านทั้งหมด
              </button>
           )}
        </div>

        <div className="space-y-3 pb-20">
           {notifications.length > 0 ? (
              notifications.map(notif => (
                 <div 
                    key={notif.id} 
                    onClick={() => onMarkAsRead(notif.id)}
                    className={`bg-white p-4 rounded-2xl border shadow-sm flex gap-4 transition-all active:scale-[0.98] ${!notif.isRead ? 'border-blue-200 bg-blue-50/30' : 'border-slate-100'}`}
                 >
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                       notif.type === 'Announcement' ? 'bg-purple-100 text-purple-600' : 
                       notif.type === 'Alert' ? 'bg-amber-100 text-amber-600' : 'bg-blue-100 text-blue-600'
                    }`}>
                       {notif.type === 'Announcement' ? <Megaphone size={18} /> : notif.type === 'Alert' ? <Bell size={18} /> : <Info size={18} />}
                    </div>
                    <div className="flex-1">
                       <div className="flex justify-between items-start mb-1">
                          <h4 className={`text-sm ${!notif.isRead ? 'font-bold text-slate-800' : 'font-medium text-slate-600'}`}>{notif.title}</h4>
                          {!notif.isRead && <div className="w-2 h-2 bg-blue-500 rounded-full mt-1.5"></div>}
                       </div>
                       <p className="text-xs text-slate-500 line-clamp-2 mb-2">{notif.message}</p>
                       <p className="text-[10px] text-slate-400">{new Date(notif.timestamp).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</p>
                    </div>
                 </div>
              ))
           ) : (
              <div className="flex flex-col items-center justify-center py-20 text-slate-400">
                 <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                    <Bell size={40} className="opacity-20" />
                 </div>
                 <p className="text-sm font-medium">ไม่มีการแจ้งเตือนใหม่</p>
              </div>
           )}
        </div>
     </div>
  );

  const renderPayslipList = () => (
     <div className="animate-fade-in space-y-4">
        <div className="flex items-center gap-3 mb-6 sticky top-0 bg-slate-50 py-2 z-10">
           <button onClick={() => setView('main')} className="p-2 bg-white rounded-full shadow-sm border border-slate-200 text-slate-600 hover:text-slate-900 active:scale-95 transition-transform">
              <ChevronLeft size={20} />
           </button>
           <h3 className="text-xl font-bold text-slate-800">ประวัติเงินเดือน</h3>
        </div>

        {myPayslips.length > 0 ? (
           <div className="space-y-3 pb-20">
              {myPayslips.map(slip => {
                 const dateObj = new Date(slip.month + '-01');
                 const monthName = dateObj.toLocaleDateString('th-TH', { month: 'long', year: 'numeric' });
                 return (
                    <div 
                       key={slip.id} 
                       onClick={() => { setSelectedPayslip(slip); setView('payslip_detail'); }}
                       className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex justify-between items-center active:scale-95 transition-transform"
                    >
                       <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-green-50 text-green-600 rounded-full flex items-center justify-center">
                             <Banknote size={20} />
                          </div>
                          <div>
                             <p className="text-sm font-bold text-slate-800">{monthName}</p>
                             <p className="text-xs text-slate-500">จ่ายแล้ว: {slip.paymentDate || '-'}</p>
                          </div>
                       </div>
                       <div className="text-right">
                          <p className="text-sm font-bold text-slate-800 font-mono">{formatCurrency(slip.netTotal)}</p>
                          <ChevronRight size={16} className="text-slate-300 ml-auto" />
                       </div>
                    </div>
                 );
              })}
           </div>
        ) : (
           <div className="flex flex-col items-center justify-center py-12 text-slate-400">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                 <FileText size={32} className="opacity-30" />
              </div>
              <p className="text-sm">ยังไม่มีประวัติสลิปเงินเดือน</p>
           </div>
        )}
     </div>
  );

  const renderPayslipDetail = () => {
     if (!selectedPayslip) return null;
     const slip = selectedPayslip;
     const dateObj = new Date(slip.month + '-01');
     const monthName = dateObj.toLocaleDateString('th-TH', { month: 'long', year: 'numeric' });

     return (
        <div className="animate-fade-in pb-20">
           <div className="flex items-center gap-3 mb-4 sticky top-0 bg-slate-50 py-2 z-10">
              <button onClick={() => setView('payslip_list')} className="p-2 bg-white rounded-full shadow-sm border border-slate-200 text-slate-600 hover:text-slate-900 active:scale-95 transition-transform">
                 <ChevronLeft size={20} />
              </button>
              <h3 className="text-lg font-bold text-slate-800">รายละเอียดสลิป</h3>
           </div>

           {/* Receipt Card */}
           <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden relative">
              {/* Top Pattern */}
              <div className="h-2 bg-gradient-to-r from-blue-500 to-indigo-600"></div>
              
              <div className="p-6">
                 {/* Header */}
                 <div className="text-center mb-6">
                    <h4 className="font-bold text-slate-800 text-lg">{companySettings.name}</h4>
                    <p className="text-xs text-slate-500">Payslip for {monthName}</p>
                 </div>

                 {/* Employee Info */}
                 <div className="flex justify-between text-xs text-slate-500 mb-6 pb-4 border-b border-slate-100 border-dashed">
                    <div>
                       <p className="uppercase font-bold tracking-wider mb-1">Employee</p>
                       <p className="text-slate-800 font-bold">{currentUser.firstName} {currentUser.lastName}</p>
                       <p>{currentUser.position}</p>
                    </div>
                    <div className="text-right">
                       <p className="uppercase font-bold tracking-wider mb-1">Payment Date</p>
                       <p className="text-slate-800">{slip.paymentDate}</p>
                       <p className="bg-green-100 text-green-700 px-1.5 py-0.5 rounded inline-block mt-1 font-bold">PAID</p>
                    </div>
                 </div>

                 {/* Earnings */}
                 <div className="mb-4">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Earnings (รายได้)</p>
                    <div className="space-y-2 text-sm">
                       <div className="flex justify-between"><span className="text-slate-600">Salary</span><span className="font-mono font-medium">{formatCurrency(slip.baseSalary)}</span></div>
                       {slip.ot > 0 && <div className="flex justify-between"><span className="text-slate-600">Overtime</span><span className="font-mono font-medium">{formatCurrency(slip.ot)}</span></div>}
                       {slip.positionAllowance && <div className="flex justify-between"><span className="text-slate-600">Position Allow.</span><span className="font-mono font-medium">{formatCurrency(slip.positionAllowance)}</span></div>}
                       {slip.travelAllowance && <div className="flex justify-between"><span className="text-slate-600">Travel Allow.</span><span className="font-mono font-medium">{formatCurrency(slip.travelAllowance)}</span></div>}
                       {slip.bonus && <div className="flex justify-between"><span className="text-slate-600">Bonus</span><span className="font-mono font-medium">{formatCurrency(slip.bonus)}</span></div>}
                       {slip.expenses && <div className="flex justify-between"><span className="text-slate-600">Expenses</span><span className="font-mono font-medium">{formatCurrency(slip.expenses)}</span></div>}
                    </div>
                 </div>

                 {/* Deductions */}
                 <div className="mb-6">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Deductions (รายการหัก)</p>
                    <div className="space-y-2 text-sm">
                       {slip.socialSecurity > 0 && <div className="flex justify-between"><span className="text-slate-600">Social Security</span><span className="font-mono text-red-500">-{formatCurrency(slip.socialSecurity)}</span></div>}
                       {slip.tax > 0 && <div className="flex justify-between"><span className="text-slate-600">Tax</span><span className="font-mono text-red-500">-{formatCurrency(slip.tax)}</span></div>}
                       {slip.lateDeduction > 0 && <div className="flex justify-between"><span className="text-slate-600">Late</span><span className="font-mono text-red-500">-{formatCurrency(slip.lateDeduction)}</span></div>}
                       {slip.absentDeduction > 0 && <div className="flex justify-between"><span className="text-slate-600">Absent</span><span className="font-mono text-red-500">-{formatCurrency(slip.absentDeduction)}</span></div>}
                    </div>
                 </div>

                 {/* Net Pay */}
                 <div className="bg-slate-50 rounded-xl p-4 flex justify-between items-center border border-slate-100">
                    <span className="text-xs font-bold text-slate-500 uppercase">Net Pay</span>
                    <span className="text-xl font-bold text-slate-900 font-mono">{formatCurrency(slip.netTotal)}</span>
                 </div>
              </div>

              {/* Footer Actions */}
              <div className="bg-slate-50 p-4 border-t border-slate-100 flex gap-3">
                 <button className="flex-1 py-3 bg-white border border-slate-200 text-slate-700 rounded-xl text-sm font-bold shadow-sm flex items-center justify-center gap-2 active:scale-95 transition-transform">
                    <Download size={16} /> Download PDF
                 </button>
              </div>
           </div>
        </div>
     );
  };

  const renderDocuments = () => (
     <div className="animate-fade-in space-y-4">
        <div className="flex items-center gap-3 mb-6 sticky top-0 bg-slate-50 py-2 z-10">
           <button onClick={() => setView('main')} className="p-2 bg-white rounded-full shadow-sm border border-slate-200 text-slate-600 hover:text-slate-900 active:scale-95 transition-transform">
              <ChevronLeft size={20} />
           </button>
           <h3 className="text-xl font-bold text-slate-800">เอกสารของฉัน (My Docs)</h3>
        </div>

        {currentUser.documents && currentUser.documents.length > 0 ? (
           <div className="grid grid-cols-1 gap-3 pb-20">
              {currentUser.documents.map(doc => (
                 <div key={doc.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                       doc.type === 'PDF' ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'
                    }`}>
                       <FileText size={24} />
                    </div>
                    <div className="flex-1 min-w-0">
                       <h4 className="font-bold text-slate-800 text-sm truncate">{doc.name}</h4>
                       <p className="text-xs text-slate-500">{doc.category} • {doc.uploadDate}</p>
                    </div>
                    <button className="p-2 text-slate-400 hover:text-indigo-600"><Download size={20}/></button>
                 </div>
              ))}
           </div>
        ) : (
           <div className="flex flex-col items-center justify-center py-12 text-slate-400">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                 <FolderOpen size={32} className="opacity-30" />
              </div>
              <p className="text-sm">ไม่มีเอกสารในระบบ</p>
           </div>
        )}
     </div>
  );

  const renderAssets = () => (
     <div className="animate-fade-in space-y-4">
        <div className="flex items-center gap-3 mb-6 sticky top-0 bg-slate-50 py-2 z-10">
           <button onClick={() => setView('main')} className="p-2 bg-white rounded-full shadow-sm border border-slate-200 text-slate-600 hover:text-slate-900 active:scale-95 transition-transform">
              <ChevronLeft size={20} />
           </button>
           <h3 className="text-xl font-bold text-slate-800">ทรัพย์สินที่ครอบครอง</h3>
        </div>

        {currentUser.assets && currentUser.assets.length > 0 ? (
           <div className="grid grid-cols-1 gap-3 pb-20">
              {currentUser.assets.map(asset => (
                 <div key={asset.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                    <div className="flex justify-between items-start mb-2">
                       <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-orange-50 text-orange-600 rounded-full flex items-center justify-center">
                             {asset.type === 'Laptop' ? <Laptop size={18}/> : <Monitor size={18}/>}
                          </div>
                          <div>
                             <h4 className="font-bold text-slate-800 text-sm">{asset.name}</h4>
                             <p className="text-xs text-slate-500 font-mono">{asset.serialNumber}</p>
                          </div>
                       </div>
                       <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${asset.status === 'Assigned' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'}`}>
                          {asset.status}
                       </span>
                    </div>
                    <div className="text-xs text-slate-400 flex items-center gap-1 mt-2 pl-13 ml-12">
                       <Calendar size={12}/> รับเมื่อ: {asset.assignedDate}
                    </div>
                 </div>
              ))}
           </div>
        ) : (
           <div className="flex flex-col items-center justify-center py-12 text-slate-400">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                 <Monitor size={32} className="opacity-30" />
              </div>
              <p className="text-sm">ไม่มีรายการทรัพย์สิน</p>
           </div>
        )}
     </div>
  );

  // --- MAIN VIEW ---
  if (view === 'payslip_list') return renderPayslipList();
  if (view === 'payslip_detail') return renderPayslipDetail();
  if (view === 'documents') return renderDocuments();
  if (view === 'assets') return renderAssets();
  if (view === 'settings') return <SettingsView onBack={() => setView('main')} />;
  if (view === 'notifications') return renderNotifications();

  return (
    <div className="space-y-6 animate-fade-in pb-24">
      
      <div className="flex justify-between items-center px-2">
         <div>
            <h2 className="text-2xl font-bold text-slate-800">โปรไฟล์ของฉัน</h2>
            <p className="text-slate-500 text-sm">ข้อมูลส่วนตัว & บัตรพนักงาน</p>
         </div>
         <button onClick={onLogout} className="p-2 bg-red-50 text-red-500 rounded-xl hover:bg-red-100 transition-colors">
            <LogOut size={20} />
         </button>
      </div>

      {/* --- DIGITAL ID CARD (FLIPPABLE) --- */}
      <div className="perspective-1000 w-full h-[220px] cursor-pointer group" onClick={() => setIsFlipped(!isFlipped)}>
         <div className={`relative w-full h-full transition-transform duration-700 transform-style-3d ${isFlipped ? 'rotate-y-180' : ''}`}>
            
            {/* FRONT SIDE */}
            <div className="absolute w-full h-full backface-hidden">
               <div className="w-full h-full rounded-3xl bg-gradient-luxury p-6 text-white shadow-2xl relative overflow-hidden border border-white/10">
                  {/* Background Decoration */}
                  <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full blur-3xl -mr-10 -mt-10"></div>
                  <div className="absolute bottom-0 left-0 w-32 h-32 bg-gold-500/20 rounded-full blur-2xl -ml-10 -mb-10"></div>
                  
                  {/* Company Logo */}
                  <div className="flex justify-between items-start mb-4">
                     <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-white/20 backdrop-blur-md rounded-lg flex items-center justify-center border border-white/10">
                           <Building size={16} className="text-gold-400" />
                        </div>
                        <span className="font-bold text-sm tracking-wide opacity-90">{companySettings.nameEn || 'EmpowerHR'}</span>
                     </div>
                     <div className="bg-white/20 backdrop-blur-md px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider border border-white/10">
                        {currentUser.employmentType.split(' ')[0]}
                     </div>
                  </div>

                  {/* User Details */}
                  <div className="flex items-center gap-5 mt-4">
                     <div className="w-20 h-20 rounded-2xl bg-white/20 p-1 border border-white/30 shadow-inner backdrop-blur-sm">
                        <img src={currentUser.avatarUrl} className="w-full h-full object-cover rounded-xl" />
                     </div>
                     <div>
                        <h3 className="text-xl font-bold leading-tight mb-1">{currentUser.firstName} <br/> {currentUser.lastName}</h3>
                        <p className="text-xs text-gold-400 font-medium uppercase tracking-wide mb-1">{currentUser.position}</p>
                        <p className="text-[10px] text-slate-300 bg-black/20 px-2 py-0.5 rounded-md inline-block">ID: {currentUser.id}</p>
                     </div>
                  </div>

                  {/* Footer Hint */}
                  <div className="absolute bottom-4 right-4 flex items-center gap-1 text-[10px] text-slate-400 animate-pulse">
                     <RotateCcw size={10} /> Tap to flip
                  </div>
               </div>
            </div>

            {/* BACK SIDE */}
            <div className="absolute w-full h-full backface-hidden rotate-y-180">
               <div className="w-full h-full rounded-3xl bg-white p-6 shadow-xl border border-slate-200 relative overflow-hidden flex flex-col items-center justify-center text-center">
                  <h4 className="text-sm font-bold text-slate-800 uppercase tracking-widest mb-4">Employee QR Code</h4>
                  <div className="p-3 bg-white rounded-xl border-2 border-slate-900 shadow-sm mb-4">
                     <QrCode size={80} className="text-slate-900" />
                  </div>
                  <p className="text-xs text-slate-500 max-w-[200px]">
                     ใช้สแกนเพื่อยืนยันตัวตน หรือเข้า-ออกอาคาร
                  </p>
                  <p className="text-[10px] text-slate-400 mt-2">Issued: {new Date(currentUser.joinDate).getFullYear()}</p>
               </div>
            </div>

         </div>
      </div>

      {/* --- QUICK STATS --- */}
      <div className="grid grid-cols-2 gap-4">
         <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex flex-col items-center justify-center">
            <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mb-2">
               <Shield size={20} />
            </div>
            <span className="text-2xl font-bold text-slate-800">{vacationQuota - vacationUsed}</span>
            <span className="text-xs text-slate-500">วันลาคงเหลือ</span>
         </div>
         <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex flex-col items-center justify-center">
            <div className="w-10 h-10 bg-green-50 text-green-600 rounded-full flex items-center justify-center mb-2">
               <CreditCard size={20} />
            </div>
            <span className="text-lg font-bold text-slate-800">{currentUser.salary > 0 ? 'Confidential' : '-'}</span>
            <span className="text-xs text-slate-500">ฐานเงินเดือน</span>
         </div>
      </div>

      {/* --- MENU LIST --- */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
         {/* Payslip Menu Item */}
         <div 
            onClick={() => setView('payslip_list')}
            className="p-4 flex items-center gap-4 hover:bg-slate-50 transition-colors cursor-pointer border-b border-slate-50 group"
         >
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg group-hover:bg-indigo-100 transition-colors"><Banknote size={18}/></div>
            <div className="flex-1">
               <p className="text-sm font-bold text-slate-700">สลิปเงินเดือน (My Payslips)</p>
               <p className="text-xs text-slate-500">ดูประวัติการจ่ายเงินย้อนหลัง</p>
            </div>
            <ChevronRight size={16} className="text-slate-300" />
         </div>

         {/* NEW: Documents Menu */}
         <div 
            onClick={() => setView('documents')}
            className="p-4 flex items-center gap-4 hover:bg-slate-50 transition-colors cursor-pointer border-b border-slate-50 group"
         >
            <div className="p-2 bg-orange-50 text-orange-600 rounded-lg group-hover:bg-orange-100 transition-colors"><FolderOpen size={18}/></div>
            <div className="flex-1">
               <p className="text-sm font-bold text-slate-700">เอกสารของฉัน (My Docs)</p>
               <p className="text-xs text-slate-500">สัญญาจ้าง, สำเนาบัตร, วุฒิการศึกษา</p>
            </div>
            <ChevronRight size={16} className="text-slate-300" />
         </div>

         {/* NEW: Assets Menu */}
         <div 
            onClick={() => setView('assets')}
            className="p-4 flex items-center gap-4 hover:bg-slate-50 transition-colors cursor-pointer border-b border-slate-50 group"
         >
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg group-hover:bg-blue-100 transition-colors"><Monitor size={18}/></div>
            <div className="flex-1">
               <p className="text-sm font-bold text-slate-700">ทรัพย์สิน (My Assets)</p>
               <p className="text-xs text-slate-500">อุปกรณ์ที่บริษัทมอบให้ใช้งาน</p>
            </div>
            <ChevronRight size={16} className="text-slate-300" />
         </div>

         {/* Personal Info Items */}
         <div className="p-4 flex items-center gap-4 hover:bg-slate-50 transition-colors cursor-pointer border-b border-slate-50">
            <div className="p-2 bg-slate-100 text-slate-600 rounded-lg"><Phone size={18}/></div>
            <div className="flex-1">
               <p className="text-sm font-bold text-slate-700">เบอร์โทรศัพท์</p>
               <p className="text-xs text-slate-500">{currentUser.phone || '-'}</p>
            </div>
         </div>
         <div className="p-4 flex items-center gap-4 hover:bg-slate-50 transition-colors cursor-pointer border-b border-slate-50">
            <div className="p-2 bg-slate-100 text-slate-600 rounded-lg"><Mail size={18}/></div>
            <div className="flex-1">
               <p className="text-sm font-bold text-slate-700">อีเมล</p>
               <p className="text-xs text-slate-500">{currentUser.email}</p>
            </div>
         </div>
         <div className="p-4 flex items-center gap-4 hover:bg-slate-50 transition-colors cursor-pointer">
            <div className="p-2 bg-slate-100 text-slate-600 rounded-lg"><MapPin size={18}/></div>
            <div className="flex-1">
               <p className="text-sm font-bold text-slate-700">ที่อยู่ปัจจุบัน</p>
               <p className="text-xs text-slate-500 line-clamp-1">{currentUser.address || '-'}</p>
            </div>
         </div>
      </div>

      {/* --- SETTINGS & NOTIFICATION MENUS --- */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
         <button 
            onClick={() => setView('settings')}
            className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors text-left border-b border-slate-50 group active:bg-slate-100"
         >
            <div className="flex items-center gap-3">
               <div className="p-2 bg-slate-100 text-slate-600 rounded-lg group-hover:bg-slate-200 transition-colors"><Settings size={18}/></div>
               <span className="text-sm font-bold text-slate-700">ตั้งค่าบัญชี (Account Settings)</span>
            </div>
            <ChevronRight size={16} className="text-slate-300" />
         </button>
         <button 
            onClick={() => setView('notifications')}
            className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors text-left group active:bg-slate-100"
         >
            <div className="flex items-center gap-3">
               <div className="p-2 bg-slate-100 text-slate-600 rounded-lg group-hover:bg-slate-200 transition-colors"><Bell size={18}/></div>
               <span className="text-sm font-bold text-slate-700">การแจ้งเตือน (Notifications)</span>
            </div>
            <div className="flex items-center gap-2">
               {unreadCount > 0 && <span className="bg-red-500 text-white text-[10px] font-bold px-1.5 rounded-full">{unreadCount}</span>}
               <ChevronRight size={16} className="text-slate-300" />
            </div>
         </button>
      </div>

      <div className="text-center text-xs text-slate-400 mt-8 mb-4">
         EmpowerHR Mobile v2.5.0 (Build 2025)
      </div>

    </div>
  );
};
