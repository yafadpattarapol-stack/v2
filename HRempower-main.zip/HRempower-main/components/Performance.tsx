
import React, { useState, useMemo } from 'react';
import { Employee, Goal, GoalType, GoalStatus, GoalScope, GoalApprovalStatus, PerformanceReview, Role, CompetencyScore } from '../types';
import { Target, TrendingUp, Plus, Edit2, CheckCircle2, AlertCircle, BarChart2, Star, Users, Briefcase, Globe, User, Layers, Link as LinkIcon, Lock, Unlock, Send, XCircle, Check, Award, Calculator, Clock, MoreHorizontal, ChevronRight, X, ArrowUpRight, MessageSquare, Play, RefreshCw } from 'lucide-react';

// ... (Keep existing interfaces and CheckInModal) ...
interface PerformanceProps {
  employees: Employee[];
  goals: Goal[];
  reviews: PerformanceReview[];
  onAddGoal: (goal: Goal) => void;
  onUpdateGoal: (goal: Goal) => void;
  onGoalApproval: (goalId: string, action: 'submit' | 'approve' | 'reject' | 'unlock', feedback?: string) => void;
  currentUser: Employee;
}

// --- Check-in Modal (Internal Component) ---
const CheckInModal = ({ goal, onClose, onConfirm }: { goal: Goal, onClose: () => void, onConfirm: (val: number, note: string) => void }) => {
   const [val, setVal] = useState(goal.currentValue);
   const [note, setNote] = useState('');

   return (
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-[60]" onClick={onClose}>
         <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 animate-fade-in-up" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-slate-800 mb-1 flex items-center gap-2">
               <TrendingUp className="text-emerald-600" /> Check-in Progress
            </h3>
            <p className="text-sm text-slate-500 mb-4">{goal.title}</p>
            
            <div className="space-y-4">
               <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Current Value ({goal.unit})</label>
                  <input 
                     type="number" 
                     className="w-full border border-slate-200 rounded-xl p-3 text-3xl font-bold text-slate-800 text-center focus:ring-4 focus:ring-emerald-100 focus:border-emerald-500 outline-none transition-all"
                     value={val}
                     onChange={e => setVal(Number(e.target.value))}
                     autoFocus
                  />
                  <div className="flex justify-between text-xs text-slate-400 mt-2 px-1">
                     <span>Start: 0</span>
                     <span>Target: {goal.targetValue}</span>
                  </div>
               </div>
               
               <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Note / Evidence</label>
                  <textarea 
                     className="w-full border border-slate-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-emerald-500 outline-none resize-none h-24"
                     placeholder="e.g. Completed monthly report, attached file sent via email..."
                     value={note}
                     onChange={e => setNote(e.target.value)}
                  ></textarea>
               </div>

               <div className="flex gap-2 pt-2">
                  <button onClick={onClose} className="flex-1 py-3 rounded-xl border border-slate-200 font-bold text-sm text-slate-600 hover:bg-slate-50 transition-colors">Cancel</button>
                  <button onClick={() => onConfirm(val, note)} className="flex-1 py-3 rounded-xl bg-emerald-600 text-white font-bold text-sm hover:bg-emerald-700 shadow-lg shadow-emerald-200 transition-colors flex items-center justify-center gap-2">
                     <CheckCircle2 size={18}/> Update
                  </button>
               </div>
            </div>
         </div>
      </div>
   );
};

interface GoalCardProps {
  goal: Goal;
  allGoals: Goal[];
  onUpdate: (goal: Goal, val: number, note?: string) => void; 
  onVerify: (goal: Goal, approved: boolean) => void;
  onApprovalAction: (goalId: string, action: 'submit' | 'approve' | 'reject' | 'unlock') => void;
  currentUser: Employee;
}

const GoalCard: React.FC<GoalCardProps> = ({ goal, allGoals, onUpdate, onVerify, onApprovalAction, currentUser }) => {
  const [showCheckIn, setShowCheckIn] = useState(false);
  const parentGoal = goal.parentId ? allGoals.find(g => g.id === goal.parentId) : null;
  const isLocked = goal.approvalStatus === GoalApprovalStatus.APPROVED || goal.approvalStatus === GoalApprovalStatus.PENDING;
  
  // Permissions
  const isOwner = goal.employeeId === currentUser.id;
  const isManager = currentUser.role === Role.MANAGER || currentUser.role === Role.CEO || currentUser.role === Role.SUPER_ADMIN; 
  const isHR = currentUser.role === Role.HR_MANAGER || currentUser.role === Role.SUPER_ADMIN;
  
  // NEW: Verification Logic
  const hasPendingProgress = goal.pendingCurrentValue !== undefined;

  const getApprovalBadge = () => {
     switch(goal.approvalStatus) {
        case GoalApprovalStatus.DRAFT: return <span className="bg-slate-100 text-slate-500 text-[10px] px-2 py-0.5 rounded font-bold uppercase border border-slate-200">Draft</span>;
        case GoalApprovalStatus.PENDING: return <span className="bg-amber-100 text-amber-700 text-[10px] px-2 py-0.5 rounded font-bold uppercase border border-amber-200 flex items-center gap-1"><Clock size={10}/> Pending Review</span>;
        case GoalApprovalStatus.APPROVED: return <span className="bg-green-100 text-green-700 text-[10px] px-2 py-0.5 rounded font-bold uppercase border border-green-200 flex items-center gap-1"><Lock size={10}/> Approved</span>;
        case GoalApprovalStatus.REJECTED: return <span className="bg-red-100 text-red-700 text-[10px] px-2 py-0.5 rounded font-bold uppercase border border-red-200">Rejected</span>;
        default: return null;
     }
  };

  return (
    <>
    <div className={`bg-white rounded-2xl p-6 border shadow-soft hover:shadow-lg transition-all duration-300 group relative flex flex-col h-full ${goal.approvalStatus === GoalApprovalStatus.REJECTED ? 'border-red-200' : 'border-slate-200'}`}>
       
       {/* Hierarchy Badge */}
       {parentGoal && (
          <div className="absolute -top-3 left-6 bg-slate-50 border border-slate-200 text-slate-500 text-[10px] px-3 py-1 rounded-full flex items-center gap-1 shadow-sm max-w-[80%] z-10 truncate" title={`Aligned to: ${parentGoal.title}`}>
             <LinkIcon size={10} className="text-blue-500 shrink-0"/>
             <span className="truncate">Aligned to: <strong>{parentGoal.title}</strong></span>
          </div>
       )}

       {/* Header: Scope & Status */}
       <div className="flex justify-between items-start mb-4 mt-2">
          <div className="flex gap-2 items-center flex-wrap">
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-widest border ${
               goal.type === GoalType.OKR ? 'bg-purple-50 text-purple-700 border-purple-100' : 'bg-blue-50 text-blue-700 border-blue-100'
            }`}>
               {goal.type}
            </span>
            {getApprovalBadge()}
          </div>
          
          <div className="flex items-center gap-2">
             {/* Unlock Button for HR / Super Admin */}
             {isLocked && isHR && (
                <button onClick={() => onApprovalAction(goal.id, 'unlock')} className="text-slate-300 hover:text-amber-500 transition-colors" title="Unlock Goal (HR/Admin Only)">
                   <Unlock size={14} />
                </button>
             )}
             
             {/* Edit Button (Only if not locked) */}
             {!isLocked && (isOwner || isManager) && (
               <button className="text-slate-400 hover:text-brand-600 transition-colors p-1 hover:bg-slate-50 rounded">
                  <Edit2 size={14} />
               </button>
             )}
          </div>
       </div>

       {/* Content */}
       <div className="flex-1">
          <h4 className={`font-bold text-slate-800 text-lg mb-2 leading-tight ${isLocked ? 'opacity-90' : ''}`}>{goal.title}</h4>
          <p className="text-sm text-slate-500 mb-4 line-clamp-2 leading-relaxed">{goal.description}</p>
          
          {goal.approvalStatus === GoalApprovalStatus.REJECTED && goal.feedback && (
             <div className="bg-red-50 p-2 rounded-lg text-xs text-red-600 mb-4 border border-red-100">
                <strong>Feedback:</strong> {goal.feedback}
             </div>
          )}
       </div>

       {/* Progress Section */}
       <div className="mt-auto">
          <div className="mb-2 flex justify-between text-xs font-bold text-slate-400 uppercase tracking-wide">
             <span className="flex items-center gap-2">
                {goal.currentValue} {goal.unit}
                {hasPendingProgress && (
                   <span className="text-[10px] bg-amber-100 text-amber-700 px-1.5 rounded flex items-center gap-1 animate-pulse" title="Waiting for Manager Approval">
                      <ArrowUpRight size={10}/> {goal.pendingCurrentValue}
                   </span>
                )}
             </span>
             <span>Target: {goal.targetValue} {goal.unit}</span>
          </div>
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden relative">
             <div 
               className={`h-full rounded-full transition-all duration-1000 ${
                  goal.progress >= 100 ? 'bg-emerald-500' : goal.progress > 50 ? 'bg-brand-500' : 'bg-amber-500'
               }`} 
               style={{ width: `${goal.progress}%` }}
             ></div>
             {/* Pending Progress Bar Ghost */}
             {hasPendingProgress && goal.pendingCurrentValue !== undefined && (
                <div 
                  className="h-full bg-amber-400/50 absolute top-0 left-0 transition-all duration-1000" 
                  style={{ width: `${Math.min(100, (goal.pendingCurrentValue / goal.targetValue) * 100)}%`, zIndex: 0 }}
                ></div>
             )}
          </div>
          <div className="flex justify-between mt-3 mb-4">
             <span className="text-xs text-brand-700 font-medium bg-brand-50 px-2 py-0.5 rounded">Weight: {goal.weight}%</span>
             <span className={`text-sm font-bold ${goal.progress >= 100 ? 'text-emerald-600' : 'text-slate-700'}`}>
                {goal.progress}% Achieved
             </span>
          </div>

          {/* ACTIONS FOOTER */}
          <div className="pt-4 border-t border-slate-100 flex flex-col gap-2">
             
             {/* 1. Setup Phase: Submit/Approve Goal Creation */}
             <div className="flex gap-2">
               {(isOwner || isManager) && (goal.approvalStatus === GoalApprovalStatus.DRAFT || goal.approvalStatus === GoalApprovalStatus.REJECTED) && (
                  <button 
                    onClick={() => onApprovalAction(goal.id, 'submit')}
                    className="flex-1 bg-blue-600 text-white px-3 py-2 rounded-lg text-xs font-bold hover:bg-blue-700 transition-colors flex items-center justify-center gap-1"
                  >
                     <Send size={12} /> Submit Goal
                  </button>
               )}

               {isManager && goal.approvalStatus === GoalApprovalStatus.PENDING && (
                  <>
                     <button onClick={() => onApprovalAction(goal.id, 'reject')} className="flex-1 bg-white border border-red-200 text-red-600 px-3 py-2 rounded-lg text-xs font-bold hover:bg-red-50 transition-colors">Reject Goal</button>
                     <button onClick={() => onApprovalAction(goal.id, 'approve')} className="flex-1 bg-emerald-600 text-white px-3 py-2 rounded-lg text-xs font-bold hover:bg-emerald-700 transition-colors">Approve Goal</button>
                  </>
               )}
             </div>

             {/* 2. Execution Phase: Update/Verify Progress */}
             {goal.approvalStatus === GoalApprovalStatus.APPROVED && (
                <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
                   {/* If Manager and Pending Update exists */}
                   {hasPendingProgress && isManager ? (
                      <div className="flex flex-col gap-2">
                         <div className="text-xs text-slate-500 font-medium flex items-center gap-1">
                            <AlertCircle size={12} className="text-amber-500"/>
                            Update Request: <strong>{goal.currentValue}</strong> ➔ <strong className="text-amber-600">{goal.pendingCurrentValue}</strong>
                         </div>
                         {goal.pendingUpdateNote && (
                            <div className="text-[10px] text-slate-600 bg-white p-2 rounded border border-slate-100 italic">
                               "{goal.pendingUpdateNote}"
                            </div>
                         )}
                         <div className="flex gap-2 mt-1">
                            <button onClick={() => onVerify(goal, false)} className="flex-1 bg-white border border-red-200 text-red-600 text-[10px] font-bold py-1.5 rounded hover:bg-red-50">Reject</button>
                            <button onClick={() => onVerify(goal, true)} className="flex-1 bg-emerald-600 text-white text-[10px] font-bold py-1.5 rounded hover:bg-emerald-700">Verify & Update</button>
                         </div>
                      </div>
                   ) : (
                      /* Standard Update Check-in - UPDATED VISUAL */
                      <div className="flex flex-col gap-2">
                         <button 
                           onClick={() => setShowCheckIn(true)}
                           disabled={hasPendingProgress}
                           className={`w-full py-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-sm ${
                              hasPendingProgress 
                                 ? 'bg-amber-100 text-amber-700 cursor-not-allowed' 
                                 : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-200 hover:shadow-lg active:scale-95'
                           }`}
                         >
                            {hasPendingProgress ? <Clock size={14}/> : <Play size={14} fill="currentColor" />}
                            {hasPendingProgress ? 'Waiting Approval...' : 'Check-in / Update'}
                         </button>
                      </div>
                   )}
                   {hasPendingProgress && !isManager && (
                      <div className="text-[10px] text-amber-600 font-bold mt-2 text-center flex justify-center items-center gap-1">
                         <Clock size={10}/> Waiting for manager verification...
                      </div>
                   )}
                </div>
             )}
             
             {/* Pending Creation Visual */}
             {goal.approvalStatus === GoalApprovalStatus.PENDING && !isManager && (
                <div className="text-center text-xs text-amber-600 font-bold bg-amber-50 py-2 rounded-lg border border-amber-100">
                   Goal waiting for approval
                </div>
             )}
          </div>
       </div>
    </div>
    
    {/* Check-in Modal */}
    {showCheckIn && (
       <CheckInModal 
          goal={goal} 
          onClose={() => setShowCheckIn(false)} 
          onConfirm={(val, note) => { onUpdate(goal, val, note); setShowCheckIn(false); }}
       />
    )}
    </>
  );
};

// ... (ReviewModal component remains unchanged) ...
// --- REVIEW MODAL COMPONENT ---
interface ReviewModalProps {
   employee: Employee;
   goals: Goal[];
   onClose: () => void;
   onSave: (review: Partial<PerformanceReview>) => void;
}

const ReviewModal: React.FC<ReviewModalProps> = ({ employee, goals, onClose, onSave }) => {
   const [activeStep, setActiveStep] = useState(1);
   const [competencies, setCompetencies] = useState<CompetencyScore[]>([
      { name: 'Teamwork & Collaboration', rating: 0, comment: '' },
      { name: 'Problem Solving', rating: 0, comment: '' },
      { name: 'Communication', rating: 0, comment: '' },
      { name: 'Leadership & Initiative', rating: 0, comment: '' },
      { name: 'Discipline & Punctuality', rating: 0, comment: '' },
   ]);
   const [finalFeedback, setFinalFeedback] = useState('');

   const totalGoalWeight = goals.reduce((sum, g) => sum + g.weight, 0);
   const weightedGoalScore = goals.reduce((sum, g) => sum + (Math.min(g.progress, 100) * g.weight / 100), 0);
   const goalScoreNormalized = totalGoalWeight > 0 ? (weightedGoalScore / totalGoalWeight) * 100 : 0;
   const competencyScore = (competencies.reduce((sum, c) => sum + c.rating, 0) / (competencies.length * 5)) * 100;
   const finalScore = (goalScoreNormalized * 0.7) + (competencyScore * 0.3);
   
   const getGrade = (score: number) => {
      if (score >= 90) return 'A';
      if (score >= 80) return 'B';
      if (score >= 70) return 'C';
      if (score >= 60) return 'D';
      return 'F';
   };

   const handleRatingChange = (idx: number, rating: number) => {
      const newComps = [...competencies];
      newComps[idx].rating = rating;
      setCompetencies(newComps);
   };

   const handleSubmit = () => {
      onSave({
         goalsScore: goalScoreNormalized,
         competencyScore: competencyScore,
         finalScore: finalScore,
         grade: getGrade(finalScore),
         competencies: competencies,
         feedback: finalFeedback,
         rating: Math.round(finalScore / 20),
         status: 'Submitted'
      });
   };

   return (
      <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-[70]">
         <div className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl h-[90vh] flex flex-col overflow-hidden animate-fade-in-up">
            <div className="px-8 py-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
               <div className="flex items-center gap-4">
                  <img src={employee.avatarUrl} className="w-14 h-14 rounded-full border-2 border-white shadow-md" />
                  <div>
                     <h3 className="text-xl font-bold text-slate-800">Performance Review</h3>
                     <p className="text-sm text-slate-500">{employee.firstName} {employee.lastName} • {employee.position}</p>
                  </div>
               </div>
               <div className="flex items-center gap-2">
                  {[1, 2, 3].map(step => (
                     <div key={step} className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${activeStep === step ? 'bg-brand-600 text-white' : activeStep > step ? 'bg-green-500 text-white' : 'bg-slate-200 text-slate-500'}`}>
                        {activeStep > step ? <Check size={14}/> : step}
                     </div>
                  ))}
               </div>
            </div>
            <div className="flex-1 overflow-y-auto custom-scrollbar p-8 bg-slate-50/50">
               {activeStep === 1 && (
                  <div className="space-y-6 animate-fade-in">
                     <div className="flex justify-between items-center mb-4">
                        <h4 className="text-lg font-bold text-slate-800 flex items-center gap-2"><Target className="text-blue-600"/> Goal Achievement (70%)</h4>
                        <span className="text-2xl font-bold text-blue-600">{goalScoreNormalized.toFixed(1)}%</span>
                     </div>
                     <div className="grid grid-cols-1 gap-4">
                        {goals.map(goal => (
                           <div key={goal.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex justify-between items-center">
                              <div className="flex-1">
                                 <div className="flex items-center gap-2 mb-1">
                                    <span className="text-xs font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded">{goal.weight}% Weight</span>
                                    <h5 className="font-bold text-slate-700 text-sm">{goal.title}</h5>
                                 </div>
                                 <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-2 max-w-md">
                                    <div className={`h-full ${goal.progress >= 100 ? 'bg-green-500' : 'bg-blue-500'}`} style={{width: `${goal.progress}%`}}></div>
                                 </div>
                              </div>
                              <div className="text-right pl-4">
                                 <div className="text-lg font-bold text-slate-800">{goal.progress}%</div>
                                 <div className="text-xs text-slate-400">Achieved</div>
                              </div>
                           </div>
                        ))}
                        {goals.length === 0 && <div className="text-center text-slate-400 py-8">No approved goals found for this cycle.</div>}
                     </div>
                  </div>
               )}
               {activeStep === 2 && (
                  <div className="space-y-6 animate-fade-in">
                     <div className="flex justify-between items-center mb-4">
                        <h4 className="text-lg font-bold text-slate-800 flex items-center gap-2"><Users className="text-purple-600"/> Core Competencies (30%)</h4>
                        <span className="text-2xl font-bold text-purple-600">{competencyScore.toFixed(1)}%</span>
                     </div>
                     <div className="space-y-4">
                        {competencies.map((comp, idx) => (
                           <div key={idx} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                              <div className="flex justify-between items-start mb-3">
                                 <h5 className="font-bold text-slate-700">{comp.name}</h5>
                                 <div className="flex gap-1">
                                    {[1, 2, 3, 4, 5].map(star => (
                                       <button key={star} onClick={() => handleRatingChange(idx, star)} className={`transition-transform hover:scale-110 ${star <= comp.rating ? 'text-amber-400' : 'text-slate-200'}`}><Star size={24} fill="currentColor" /></button>
                                    ))}
                                 </div>
                              </div>
                              <textarea className="w-full bg-slate-50 border border-slate-200 rounded-lg p-3 text-sm focus:outline-none focus:ring-1 focus:ring-purple-500 resize-none h-20" placeholder={`Comments on ${comp.name}...`} value={comp.comment} onChange={(e) => { const newComps = [...competencies]; newComps[idx].comment = e.target.value; setCompetencies(newComps); }}></textarea>
                           </div>
                        ))}
                     </div>
                  </div>
               )}
               {activeStep === 3 && (
                  <div className="space-y-8 animate-fade-in">
                     <div className="text-center">
                        <div className={`w-24 h-24 rounded-full flex items-center justify-center text-4xl font-bold mx-auto mb-4 border-4 shadow-lg ${getGrade(finalScore) === 'A' ? 'bg-green-100 text-green-700 border-green-200' : getGrade(finalScore) === 'B' ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-amber-100 text-amber-700 border-amber-200'}`}>{getGrade(finalScore)}</div>
                        <h4 className="text-2xl font-bold text-slate-800">Final Score: {finalScore.toFixed(1)}%</h4>
                        <p className="text-slate-500">Based on Goals (70%) and Competencies (30%)</p>
                     </div>
                     <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm grid grid-cols-2 gap-8">
                        <div><p className="text-xs font-bold text-slate-400 uppercase">Goal Score</p><div className="text-xl font-bold text-blue-600">{goalScoreNormalized.toFixed(1)}%</div><div className="w-full h-1.5 bg-slate-100 rounded-full mt-2"><div className="h-full bg-blue-600 rounded-full" style={{width: `${goalScoreNormalized}%`}}></div></div></div>
                        <div><p className="text-xs font-bold text-slate-400 uppercase">Competency Score</p><div className="text-xl font-bold text-purple-600">{competencyScore.toFixed(1)}%</div><div className="w-full h-1.5 bg-slate-100 rounded-full mt-2"><div className="h-full bg-purple-600 rounded-full" style={{width: `${competencyScore}%`}}></div></div></div>
                     </div>
                     <div><label className="block text-sm font-bold text-slate-700 mb-2">Final Feedback / Summary</label><textarea className="w-full border border-slate-300 rounded-xl p-4 h-32 focus:ring-2 focus:ring-brand-500 outline-none text-sm leading-relaxed" placeholder="Overall performance summary..." value={finalFeedback} onChange={(e) => setFinalFeedback(e.target.value)}></textarea></div>
                  </div>
               )}
            </div>
            <div className="p-6 border-t border-slate-100 bg-white flex justify-between items-center">
               <button onClick={onClose} className="px-6 py-2.5 text-slate-500 font-bold hover:bg-slate-50 rounded-xl transition-colors">Cancel</button>
               <div className="flex gap-3">
                  {activeStep > 1 && (<button onClick={() => setActiveStep(prev => prev - 1)} className="px-6 py-2.5 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200 transition-colors">Back</button>)}
                  {activeStep < 3 ? (<button onClick={() => setActiveStep(prev => prev + 1)} className="px-8 py-2.5 bg-brand-600 text-white font-bold rounded-xl hover:bg-brand-700 shadow-lg shadow-brand-200 transition-colors">Next Step</button>) : (<button onClick={handleSubmit} className="px-8 py-2.5 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 shadow-lg shadow-emerald-200 transition-colors flex items-center gap-2"><CheckCircle2 size={18} /> Submit Review</button>)}
               </div>
            </div>
         </div>
      </div>
   );
};

export const Performance: React.FC<PerformanceProps> = ({ 
  employees, goals, reviews, onAddGoal, onUpdateGoal, onGoalApproval, currentUser 
}) => {
  const [activeTab, setActiveTab] = useState<'company' | 'division' | 'department' | 'myGoals' | 'teamReviews'>('company');
  const [showGoalModal, setShowGoalModal] = useState(false);
  
  // Review Modal State
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [reviewTarget, setReviewTarget] = useState<Employee | null>(null);

  const [newGoal, setNewGoal] = useState<Partial<Goal>>({
    type: GoalType.KPI,
    scope: GoalScope.INDIVIDUAL,
    approvalStatus: GoalApprovalStatus.DRAFT,
    status: GoalStatus.NOT_STARTED,
    progress: 0,
    currentValue: 0,
    targetValue: 100,
    weight: 0
  });

  const isCEO = currentUser.role === Role.CEO;
  const isManager = [Role.CEO, Role.HR_MANAGER, Role.MANAGER, Role.SUPER_ADMIN].includes(currentUser.role);
  const isAdmin = [Role.CEO, Role.HR_MANAGER, Role.SUPER_ADMIN].includes(currentUser.role);

  // --- Filtering ---
  const companyGoals = goals.filter(g => g.scope === GoalScope.COMPANY);
  const divisionGoals = isAdmin || isCEO ? goals.filter(g => g.scope === GoalScope.DIVISION) : goals.filter(g => g.scope === GoalScope.DIVISION && g.divisionName === currentUser.division);
  const deptGoals = isAdmin ? goals.filter(g => g.scope === GoalScope.DEPARTMENT) : goals.filter(g => g.scope === GoalScope.DEPARTMENT && g.departmentId === currentUser.department);
  const myGoals = goals.filter(g => g.scope === GoalScope.INDIVIDUAL && g.employeeId === currentUser.id);
  
  const overallProgress = myGoals.length > 0 ? Math.round(myGoals.reduce((sum, g) => sum + g.progress, 0) / myGoals.length) : 0;

  // --- Permission Handlers ---
  const canCreateCompany = isCEO || isAdmin;
  const canCreateDivision = isManager; 
  const canCreateDept = isManager;
  
  const openModal = () => {
    let defaultScope = GoalScope.INDIVIDUAL;
    if (activeTab === 'company' && canCreateCompany) defaultScope = GoalScope.COMPANY;
    if (activeTab === 'division' && canCreateDivision) defaultScope = GoalScope.DIVISION;
    if (activeTab === 'department' && canCreateDept) defaultScope = GoalScope.DEPARTMENT;
    setNewGoal(prev => ({ ...prev, scope: defaultScope }));
    setShowGoalModal(true);
  };

  const openReviewModal = (employee: Employee) => {
     setReviewTarget(employee);
     setShowReviewModal(true);
  };

  const handleSaveReview = (reviewData: Partial<PerformanceReview>) => {
     // In a real app, dispatch to parent handler
     setShowReviewModal(false);
     setReviewTarget(null);
     alert(`Performance review for ${reviewTarget?.firstName} submitted successfully! Grade: ${reviewData.grade}`);
  };

  const handleSaveGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (newGoal.title && newGoal.metric) {
      const endDateVal = newGoal.endDate || new Date(new Date().getFullYear(), 11, 31).toISOString().split('T')[0];
      const goal: Goal = {
        id: `G${Date.now()}`,
        orgId: currentUser.orgId,
        // Allow assigning goal to others if manager
        employeeId: newGoal.employeeId || (newGoal.scope === GoalScope.INDIVIDUAL ? currentUser.id : undefined),
        departmentId: newGoal.scope === GoalScope.DEPARTMENT ? currentUser.department : undefined,
        divisionName: newGoal.scope === GoalScope.DIVISION ? currentUser.division : undefined,
        parentId: newGoal.parentId || undefined,
        title: newGoal.title!,
        description: newGoal.description || '',
        type: newGoal.type as GoalType,
        scope: newGoal.scope as GoalScope,
        metric: newGoal.metric!,
        targetValue: Number(newGoal.targetValue),
        currentValue: Number(newGoal.currentValue),
        unit: newGoal.unit || 'Units',
        startDate: newGoal.startDate || new Date().toISOString().split('T')[0],
        endDate: endDateVal,
        dueDate: endDateVal,
        status: newGoal.status as GoalStatus,
        approvalStatus: GoalApprovalStatus.DRAFT,
        progress: Number(newGoal.targetValue) > 0 ? Math.min(100, Math.round((Number(newGoal.currentValue) / Number(newGoal.targetValue)) * 100)) : 0,
        weight: Number(newGoal.weight)
      };
      onAddGoal(goal);
      setShowGoalModal(false);
      // Reset
      setNewGoal({ type: GoalType.KPI, scope: GoalScope.INDIVIDUAL, status: GoalStatus.NOT_STARTED, progress: 0, currentValue: 0, targetValue: 100, weight: 0 });
    }
  };

  // --- RECURSIVE UPDATE LOGIC ---
  const updateProgressUpwards = (changedGoal: Goal) => {
     // Only proceed if it has a parent
     if (!changedGoal.parentId) return;

     // 1. Find Parent
     const parentGoal = goals.find(g => g.id === changedGoal.parentId);
     if (!parentGoal) return;

     // 2. Find all children of this parent (siblings + self)
     const siblings = goals.filter(g => g.parentId === parentGoal.id);
     
     // 3. Calculate Weighted Average Progress
     let totalWeight = 0;
     let weightedProgressSum = 0;

     siblings.forEach(child => {
        // Use updated value for the specific child that changed (if strictly needed, but here we updated local state first in handleVerifyProgress so 'goals' prop might be stale? 
        // NOTE: In this simulated frontend, 'goals' prop isn't updated instantly inside handleVerifyProgress unless we pass it.
        // For simplicity: We will assume 'changedGoal' is the fresh version, and others are from 'goals' prop.)
        
        const effectiveChild = child.id === changedGoal.id ? changedGoal : child;
        const weight = effectiveChild.weight || 1; // Prevent div by zero, assume equal weight if 0? Or just 0.
        
        totalWeight += weight;
        weightedProgressSum += (effectiveChild.progress * weight);
     });

     const newParentProgress = totalWeight > 0 ? Math.round(weightedProgressSum / totalWeight) : 0;

     // 4. Update Parent Goal
     const updatedParent = {
        ...parentGoal,
        progress: newParentProgress,
        currentValue: newParentProgress, // For OKRs that track %, value = progress
        status: newParentProgress === 100 ? GoalStatus.COMPLETED : GoalStatus.IN_PROGRESS
     };

     // 5. Commit Parent Update
     onUpdateGoal(updatedParent);

     // 6. Recurse Upwards
     updateProgressUpwards(updatedParent);
  };

  // --- UPDATED: Progress Verification Flow ---
  const handleRequestProgressUpdate = (goal: Goal, newValue: number, note?: string) => {
    // If I'm the owner but not the approver/manager, I request an update
    // If I'm the manager updating my own goal, it goes through directly (simplification)
    // Or if I'm a manager updating someone else's goal (intervention)
    
    // For this requirement: "Employee updates -> sends for verification"
    if (isManager && goal.employeeId !== currentUser.id) {
       // Manager editing someone else's goal -> Direct Update
       handleVerifyProgress(goal, true, newValue);
    } else {
       // Regular update request (Employee self-update)
       onUpdateGoal({ 
          ...goal, 
          pendingCurrentValue: newValue, // Staging value
          pendingUpdateNote: note, // Store note
          lastUpdatedBy: currentUser.id
       });
    }
  };

  const handleVerifyProgress = (goal: Goal, approved: boolean, overrideValue?: number) => {
     if (approved) {
        const finalValue = overrideValue !== undefined ? overrideValue : (goal.pendingCurrentValue ?? goal.currentValue);
        const target = goal.targetValue || 1;
        const progress = Math.min(100, Math.round((finalValue / target) * 100));
        let status = goal.status;
        if (progress === 100) status = GoalStatus.COMPLETED;
        else if (progress > 0) status = GoalStatus.IN_PROGRESS;

        const updatedGoal = { 
           ...goal, 
           currentValue: finalValue, 
           progress, 
           status,
           pendingCurrentValue: undefined, // Clear pending
           pendingUpdateNote: undefined 
        };

        // 1. Update the goal itself
        onUpdateGoal(updatedGoal);

        // 2. Trigger Recursive Update
        updateProgressUpwards(updatedGoal);

     } else {
        // Rejected - Clear pending
        onUpdateGoal({ 
           ...goal, 
           pendingCurrentValue: undefined,
           pendingUpdateNote: undefined
        });
     }
  };

  // --- Filtering Parent Goals for Alignment ---
  const possibleParentGoals = goals.filter(g => {
     // If creating Individual Goal -> Can link to Dept or Division or Company
     if (newGoal.scope === GoalScope.INDIVIDUAL) return g.scope !== GoalScope.INDIVIDUAL;
     // If creating Dept Goal -> Can link to Division or Company
     if (newGoal.scope === GoalScope.DEPARTMENT) return g.scope === GoalScope.DIVISION || g.scope === GoalScope.COMPANY;
     // If creating Division -> Can link to Company
     if (newGoal.scope === GoalScope.DIVISION) return g.scope === GoalScope.COMPANY;
     return false;
  });

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      
      {/* Header */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-end gap-6">
        <div>
           <div className="flex items-center gap-2 text-brand-600 text-sm font-bold mb-2 uppercase tracking-widest">
             <Target size={16} /> Performance Management
           </div>
           <h2 className="text-4xl font-bold text-slate-800 font-sans">ประเมินผลงาน (Goals & Reviews)</h2>
           <p className="text-slate-500 mt-2 font-light">
             ติดตามเป้าหมายแบบลำดับชั้น: <span className="font-bold text-slate-700">องค์กร</span> -> <span className="font-bold text-orange-600">ฝ่าย</span> -> <span className="font-bold text-indigo-600">แผนก</span> -> <span className="font-bold text-brand-600">รายบุคคล</span>
           </p>
        </div>

        <div className="flex bg-white p-1 rounded-xl shadow-sm border border-slate-200 overflow-x-auto max-w-full">
           <button onClick={() => setActiveTab('company')} className={`px-5 py-2.5 rounded-lg text-sm font-bold flex items-center gap-2 transition-all whitespace-nowrap ${activeTab === 'company' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}><Globe size={18} /> องค์กร (Org)</button>
           <button onClick={() => setActiveTab('division')} className={`px-5 py-2.5 rounded-lg text-sm font-bold flex items-center gap-2 transition-all whitespace-nowrap ${activeTab === 'division' ? 'bg-orange-500 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}><Layers size={18} /> ฝ่าย (Div)</button>
           <button onClick={() => setActiveTab('department')} className={`px-5 py-2.5 rounded-lg text-sm font-bold flex items-center gap-2 transition-all whitespace-nowrap ${activeTab === 'department' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}><Briefcase size={18} /> แผนก (Dept)</button>
           <button onClick={() => setActiveTab('myGoals')} className={`px-5 py-2.5 rounded-lg text-sm font-bold flex items-center gap-2 transition-all whitespace-nowrap ${activeTab === 'myGoals' ? 'bg-brand-50 text-brand-700 shadow-sm border border-brand-100' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}><User size={18} /> รายบุคคล (Personal)</button>
           {isManager && (<button onClick={() => setActiveTab('teamReviews')} className={`px-5 py-2.5 rounded-lg text-sm font-bold flex items-center gap-2 transition-all whitespace-nowrap ${activeTab === 'teamReviews' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}><Award size={18} /> ทีม (Reviews)</button>)}
        </div>
      </div>

      {/* --- COMPANY GOALS TAB --- */}
      {activeTab === 'company' && (
        <>
            <div className="bg-slate-900 rounded-3xl p-8 text-white relative overflow-hidden mb-8 shadow-lg">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-16 -mt-16 blur-3xl"></div>
                <h3 className="text-2xl font-bold mb-2 flex items-center gap-3"><Globe className="text-blue-400" /> เป้าหมายระดับองค์กร (Company Goals)</h3>
                <p className="text-slate-400 max-w-2xl">ทิศทางหลักของบริษัท (ระดับสูงสุด)</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {companyGoals.map(goal => <GoalCard key={goal.id} goal={goal} allGoals={goals} onUpdate={handleRequestProgressUpdate} onVerify={handleVerifyProgress} onApprovalAction={onGoalApproval} currentUser={currentUser} />)}
                {canCreateCompany && (<div className="bg-slate-50 rounded-2xl p-6 border-2 border-dashed border-slate-300 flex flex-col items-center justify-center min-h-[300px] cursor-pointer hover:bg-white hover:border-slate-800 transition-colors group" onClick={openModal}><Plus size={40} className="text-slate-300 group-hover:text-slate-800 mb-4 transition-colors" /><p className="font-bold text-slate-500 group-hover:text-slate-800">สร้างเป้าหมายองค์กร</p></div>)}
            </div>
        </>
      )}

      {/* --- DIVISION GOALS TAB --- */}
      {activeTab === 'division' && (
         <>
            <div className="bg-orange-600 rounded-3xl p-8 text-white relative overflow-hidden mb-8 shadow-lg">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-16 -mt-16 blur-3xl"></div>
                <h3 className="text-2xl font-bold mb-2 flex items-center gap-3"><Layers className="text-orange-200" /> เป้าหมายระดับฝ่าย (Division Goals)</h3>
                <p className="text-orange-100 max-w-2xl">เป้าหมายหลักของฝ่ายงาน {currentUser.division} (เชื่อมโยงกับเป้าหมายองค์กร)</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {divisionGoals.map(goal => <GoalCard key={goal.id} goal={goal} allGoals={goals} onUpdate={handleRequestProgressUpdate} onVerify={handleVerifyProgress} onApprovalAction={onGoalApproval} currentUser={currentUser} />)}
                {canCreateDivision && (<div className="bg-slate-50 rounded-2xl p-6 border-2 border-dashed border-slate-300 flex flex-col items-center justify-center min-h-[300px] cursor-pointer hover:bg-white hover:border-orange-500 transition-colors group" onClick={openModal}><Plus size={40} className="text-slate-300 group-hover:text-orange-500 mb-4 transition-colors" /><p className="font-bold text-slate-500 group-hover:text-orange-500">สร้างเป้าหมายฝ่าย</p></div>)}
            </div>
         </>
      )}

      {/* --- DEPARTMENT GOALS TAB --- */}
      {activeTab === 'department' && (
         <>
            <div className="bg-indigo-900 rounded-3xl p-8 text-white relative overflow-hidden mb-8 shadow-lg">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-16 -mt-16 blur-3xl"></div>
                <h3 className="text-2xl font-bold mb-2 flex items-center gap-3"><Briefcase className="text-indigo-300" /> เป้าหมายแผนก {currentUser.department}</h3>
                <p className="text-indigo-200 max-w-2xl">ตัวชี้วัดความสำเร็จของทีม (เชื่อมโยงกับเป้าหมายฝ่าย)</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {deptGoals.map(goal => <GoalCard key={goal.id} goal={goal} allGoals={goals} onUpdate={handleRequestProgressUpdate} onVerify={handleVerifyProgress} onApprovalAction={onGoalApproval} currentUser={currentUser} />)}
                {canCreateDept && (<div className="bg-slate-50 rounded-2xl p-6 border-2 border-dashed border-slate-300 flex flex-col items-center justify-center min-h-[300px] cursor-pointer hover:bg-white hover:border-indigo-600 transition-colors group" onClick={openModal}><Plus size={40} className="text-slate-300 group-hover:text-indigo-600 mb-4 transition-colors" /><p className="font-bold text-slate-500 group-hover:text-indigo-600">สร้างเป้าหมายแผนก</p></div>)}
            </div>
         </>
      )}

      {/* --- MY GOALS TAB --- */}
      {activeTab === 'myGoals' && (
         <>
            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
               <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-soft relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-brand-50 rounded-full -mr-8 -mt-8 group-hover:scale-110 transition-transform duration-700"></div>
                  <h4 className="text-slate-500 font-bold uppercase tracking-widest text-xs mb-2">ความสำเร็จรวม</h4>
                  <div className="flex items-end gap-4 mb-4"><span className="text-6xl font-bold tracking-tighter text-slate-900">{overallProgress}%</span><span className="text-sm font-bold text-slate-400 mb-3 bg-slate-50 px-2 py-0.5 rounded">Average</span></div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden"><div className="h-full bg-brand-500 rounded-full" style={{ width: `${overallProgress}%` }}></div></div>
               </div>
               <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-soft flex flex-col justify-center relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-transparent"></div>
                  <div className="flex items-center gap-3 mb-3"><div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg"><CheckCircle2 size={24} /></div><span className="text-slate-400 text-sm font-bold uppercase tracking-wider">Completed</span></div>
                  <span className="text-4xl font-bold text-slate-800">{myGoals.filter(g => g.status === GoalStatus.COMPLETED).length} <span className="text-sm font-normal text-slate-400">/ {myGoals.length} เป้าหมาย</span></span>
               </div>
               <div className="bg-slate-50 rounded-3xl p-8 border border-dashed border-slate-300 shadow-sm flex flex-col justify-center cursor-pointer hover:bg-white hover:border-brand-500 hover:shadow-md transition-all group" onClick={openModal}>
                  <div className="flex items-center justify-center h-full gap-4 text-slate-400 group-hover:text-brand-600"><div className="p-4 bg-white rounded-full shadow-sm group-hover:scale-110 transition-transform"><Plus size={28} /></div><span className="font-bold text-lg">สร้างเป้าหมายใหม่</span></div>
               </div>
            </div>
            <div>
               <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-3"><TrendingUp className="text-brand-600" /> เป้าหมายของฉัน</h3>
               {myGoals.length > 0 ? (<div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">{myGoals.map(goal => <GoalCard key={goal.id} goal={goal} allGoals={goals} onUpdate={handleRequestProgressUpdate} onVerify={handleVerifyProgress} onApprovalAction={onGoalApproval} currentUser={currentUser} />)}</div>) : (<div className="text-center py-16 bg-slate-50 rounded-3xl border border-slate-200 border-dashed"><Target size={56} className="mx-auto text-slate-300 mb-4" /><p className="text-slate-500 font-medium text-lg">ยังไม่มีเป้าหมายส่วนบุคคล</p><button onClick={openModal} className="mt-6 text-brand-600 font-bold hover:text-brand-700 transition-colors underline decoration-brand-200 hover:decoration-brand-600">เริ่มต้นตั้งเป้าหมายแรกของคุณ</button></div>)}
            </div>
         </>
      )}

      {/* Team Reviews View (Manager Only) */}
      {activeTab === 'teamReviews' && isManager && (
         <div className="bg-white rounded-3xl shadow-soft border border-slate-200 overflow-hidden">
            <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
               <div>
                 <h3 className="font-bold text-slate-800 text-xl">ประเมินผลงานทีม (Team Evaluation)</h3>
                 <p className="text-xs text-slate-400 uppercase tracking-widest mt-1">รอบการประเมิน: <span className="text-emerald-600 font-bold">Q4 2025</span></p>
               </div>
               <div className="flex gap-2">
                  <div className="px-3 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded uppercase flex items-center gap-1"><Clock size={12}/> Cycle Active</div>
               </div>
            </div>
            <table className="w-full text-left">
               <thead className="bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider">
                  <tr>
                     <th className="px-8 py-5">พนักงาน</th>
                     <th className="px-8 py-5">Goal Achievement (70%)</th>
                     <th className="px-8 py-5">Review Status</th>
                     <th className="px-8 py-5 text-right">Action</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-100 text-sm">
                  {employees.filter(e => e.department === currentUser.department && e.id !== currentUser.id).map(emp => {
                     const empGoals = goals.filter(g => g.employeeId === emp.id && g.scope === GoalScope.INDIVIDUAL);
                     const totalWeight = empGoals.reduce((sum, g) => sum + g.weight, 0);
                     const weightedScore = empGoals.reduce((sum, g) => sum + (Math.min(g.progress, 100) * g.weight / 100), 0);
                     const score = totalWeight > 0 ? (weightedScore / totalWeight) * 100 : 0;
                     
                     // Mock status
                     const isReviewed = false; 

                     return (
                        <tr key={emp.id} className="hover:bg-slate-50 transition-colors group">
                           <td className="px-8 py-5">
                              <div className="flex items-center gap-4">
                                 <img src={emp.avatarUrl} className="w-10 h-10 rounded-full object-cover border border-slate-200" />
                                 <div>
                                    <div className="font-bold text-slate-800 group-hover:text-brand-600 transition-colors">{emp.firstName} {emp.lastName}</div>
                                    <div className="text-xs text-slate-500">{emp.position}</div>
                                 </div>
                              </div>
                           </td>
                           <td className="px-8 py-5">
                              <div className="flex items-center gap-3">
                                 <div className="w-24 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                                    <div className={`h-full ${score >= 80 ? 'bg-emerald-500' : 'bg-brand-500'}`} style={{width: `${score}%`}}></div>
                                 </div>
                                 <span className="text-xs font-bold text-slate-700">{score.toFixed(0)}%</span>
                              </div>
                           </td>
                           <td className="px-8 py-5">
                              {isReviewed ? (
                                 <span className="text-green-600 font-bold flex items-center gap-1 bg-green-50 px-2 py-1 rounded w-fit"><CheckCircle2 size={14}/> Completed</span>
                              ) : (
                                 <span className="text-slate-400 font-medium flex items-center gap-1 bg-slate-100 px-2 py-1 rounded w-fit"><Clock size={14}/> Pending</span>
                              )}
                           </td>
                           <td className="px-8 py-5 text-right">
                              <button 
                                 onClick={() => openReviewModal(emp)}
                                 className="bg-brand-600 text-white hover:bg-brand-700 px-4 py-2 rounded-lg font-bold text-xs transition-colors uppercase tracking-wider shadow-sm"
                              >
                                 Evaluate
                              </button>
                           </td>
                        </tr>
                     );
                  })}
               </tbody>
            </table>
         </div>
      )}

      {/* Add Goal Modal */}
      {showGoalModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
           <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg p-8 animate-fade-in-up border border-slate-100 relative overflow-hidden">
              <div className="flex justify-between items-center mb-6">
                 <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-3">
                    <div className="p-2 bg-brand-100 text-brand-700 rounded-lg"><Target size={20} /></div>สร้างเป้าหมายใหม่ (Draft)
                 </h3>
                 <button onClick={() => setShowGoalModal(false)} className="text-slate-400 hover:text-slate-600 transition-colors"><X size={28} /></button>
              </div>
              <form onSubmit={handleSaveGoal} className="space-y-6">
                 <div>
                    <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-wide">ระดับเป้าหมาย (Level)</label>
                    <div className="flex gap-2 bg-slate-50 p-1 rounded-xl overflow-x-auto">
                       {canCreateCompany && (<button type="button" onClick={() => setNewGoal({...newGoal, scope: GoalScope.COMPANY})} className={`flex-1 py-2 px-2 text-xs font-bold rounded-lg transition-all whitespace-nowrap ${newGoal.scope === GoalScope.COMPANY ? 'bg-slate-800 text-white shadow' : 'text-slate-500 hover:bg-slate-200'}`}>Company</button>)}
                       {canCreateDivision && (<button type="button" onClick={() => setNewGoal({...newGoal, scope: GoalScope.DIVISION})} className={`flex-1 py-2 px-2 text-xs font-bold rounded-lg transition-all whitespace-nowrap ${newGoal.scope === GoalScope.DIVISION ? 'bg-orange-500 text-white shadow' : 'text-slate-500 hover:bg-slate-200'}`}>Division</button>)}
                       {canCreateDept && (<button type="button" onClick={() => setNewGoal({...newGoal, scope: GoalScope.DEPARTMENT})} className={`flex-1 py-2 px-2 text-xs font-bold rounded-lg transition-all whitespace-nowrap ${newGoal.scope === GoalScope.DEPARTMENT ? 'bg-indigo-600 text-white shadow' : 'text-slate-500 hover:bg-slate-200'}`}>Dept</button>)}
                       <button type="button" onClick={() => setNewGoal({...newGoal, scope: GoalScope.INDIVIDUAL})} className={`flex-1 py-2 px-2 text-xs font-bold rounded-lg transition-all whitespace-nowrap ${newGoal.scope === GoalScope.INDIVIDUAL ? 'bg-brand-600 text-white shadow' : 'text-slate-500 hover:bg-slate-200'}`}>Personal</button>
                    </div>
                 </div>

                 {/* Alignment Selection (Parent Goal) */}
                 {possibleParentGoals.length > 0 && (
                    <div>
                       <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-wide">ความสอดคล้อง (Alignment)</label>
                       <select 
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-sm text-slate-800 focus:outline-none"
                          value={newGoal.parentId || ''}
                          onChange={e => setNewGoal({...newGoal, parentId: e.target.value || undefined})}
                       >
                          <option value="">-- ไม่ระบุ (No Parent Goal) --</option>
                          {possibleParentGoals.map(pg => (
                             <option key={pg.id} value={pg.id}>
                                {pg.title} ({pg.scope})
                             </option>
                          ))}
                       </select>
                    </div>
                 )}

                 {/* Assignment (Manager creates for Employee) */}
                 {isManager && newGoal.scope === GoalScope.INDIVIDUAL && (
                    <div>
                       <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-wide">มอบหมายให้ (Assign To)</label>
                       <select 
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-sm text-slate-800 focus:outline-none"
                          value={newGoal.employeeId || ''}
                          onChange={e => setNewGoal({...newGoal, employeeId: e.target.value || undefined})}
                       >
                          <option value={currentUser.id}>ตนเอง (Myself)</option>
                          {employees.filter(e => e.department === currentUser.department && e.id !== currentUser.id).map(emp => (
                             <option key={emp.id} value={emp.id}>{emp.firstName} {emp.lastName}</option>
                          ))}
                       </select>
                    </div>
                 )}

                 <div><label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-wide">หัวข้อเป้าหมาย</label><input required type="text" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-brand-500 placeholder:text-slate-400" placeholder="e.g. เพิ่มยอดขายไตรมาส 3" value={newGoal.title} onChange={e => setNewGoal({...newGoal, title: e.target.value})} /></div>
                 <div className="grid grid-cols-2 gap-6"><div><label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-wide">ประเภท</label><select className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-sm text-slate-800 focus:outline-none" value={newGoal.type} onChange={e => setNewGoal({...newGoal, type: e.target.value as GoalType})}><option value={GoalType.KPI}>KPI</option><option value={GoalType.OKR}>OKR</option></select></div><div><label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-wide">น้ำหนัก (%)</label><input type="number" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-brand-500 placeholder:text-slate-400" placeholder="e.g. 20" value={newGoal.weight} onChange={e => setNewGoal({...newGoal, weight: Number(e.target.value)})} /></div></div>
                 <div className="grid grid-cols-3 gap-6"><div className="col-span-1"><label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-wide">เป้าหมาย (ตัวเลข)</label><input required type="number" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-brand-500 placeholder:text-slate-400" placeholder="100" value={newGoal.targetValue} onChange={e => setNewGoal({...newGoal, targetValue: Number(e.target.value)})} /></div><div className="col-span-2"><label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-wide">หน่วยวัด</label><input required type="text" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-brand-500 placeholder:text-slate-400" placeholder="e.g. ล้านบาท" value={newGoal.unit} onChange={e => setNewGoal({...newGoal, unit: e.target.value})} /></div></div>
                 <div><label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-wide">รายละเอียดตัวชี้วัด</label><textarea className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-brand-500 placeholder:text-slate-400 h-24 resize-none" placeholder="อธิบายวิธีการวัดผล..." value={newGoal.metric} onChange={e => setNewGoal({...newGoal, metric: e.target.value})}></textarea></div>
                 <div className="flex justify-end gap-3 pt-6 border-t border-slate-100"><button type="button" onClick={() => setShowGoalModal(false)} className="px-6 py-3 text-slate-500 hover:bg-slate-50 rounded-xl font-bold text-sm transition-colors">ยกเลิก</button><button type="submit" className="px-8 py-3 bg-brand-600 hover:bg-brand-700 text-white rounded-xl font-bold text-sm shadow-md transition-all uppercase tracking-wide">บันทึกแบบร่าง (Draft)</button></div>
              </form>
           </div>
        </div>
      )}

      {/* Review Modal */}
      {showReviewModal && reviewTarget && (
         <ReviewModal 
            employee={reviewTarget}
            goals={goals.filter(g => g.employeeId === reviewTarget.id && g.scope === GoalScope.INDIVIDUAL)}
            onClose={() => setShowReviewModal(false)}
            onSave={handleSaveReview}
         />
      )}
    </div>
  );
};
