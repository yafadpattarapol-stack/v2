
import React, { useMemo, useState, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, AreaChart, Area
} from 'recharts';
import { Employee, AttendanceRecord, LeaveRequest, LeaveStatus, Post, Role, Tab, LeaveType } from '../types';
import { 
  Users, Clock, Calendar, Briefcase, ChevronRight, Bell, Zap, 
  ArrowUpRight, AlertCircle, Sun, Cloud, CloudRain, CheckCircle2, Coffee, FileText,
  Star, X, MapPin, Shield, Wallet, Activity
} from 'lucide-react';

interface DashboardProps {
  employees: Employee[];
  attendance: AttendanceRecord[];
  leaves: LeaveRequest[];
  posts: Post[];
  currentUser: Employee;
  onNavigate: (tab: Tab) => void;
  onNavigateToExpense?: () => void;
}

const COLORS = {
  brand: '#C8A97E',
  brandDark: '#A68A60',
  secondary: '#392C45',
  success: '#10b981',
  warning: '#f59e0b',
  danger: '#ef4444',
  purple: '#6d5284',
  slate: '#64748b',
  white: '#ffffff',
  surface: '#ffffff',
  bg: '#F8FAFC'
};

type StatCategory = 'present' | 'late' | 'leave' | 'absent' | null;

export const Dashboard: React.FC<DashboardProps> = ({ employees, attendance, leaves, posts, currentUser, onNavigate, onNavigateToExpense }) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedCategory, setSelectedCategory] = useState<StatCategory>(null);
  
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const todayStr = new Date().toISOString().split('T')[0];

  // --- VISIBILITY LOGIC ---
  const visibleEmployees = useMemo(() => {
    if (currentUser.role === Role.SUPER_ADMIN || currentUser.role === Role.CEO || currentUser.role === Role.HR_MANAGER || currentUser.role === Role.HR_STAFF) {
      return employees;
    } 
    if (currentUser.role === Role.MANAGER) {
      return employees.filter(e => e.department === currentUser.department);
    }
    return employees.filter(e => e.id === currentUser.id);
  }, [employees, currentUser]);

  // --- STATS CALCULATION ---
  const dailyStats = useMemo(() => {
    const todaysRecords = attendance.filter(a => a.date === todayStr);
    const todaysLeaves = leaves.filter(l => l.status === LeaveStatus.APPROVED && l.startDate <= todayStr && l.endDate >= todayStr);

    const presentList: { emp: Employee, record: AttendanceRecord }[] = [];
    const lateList: { emp: Employee, record: AttendanceRecord }[] = [];
    const leaveList: { emp: Employee, req: LeaveRequest }[] = [];
    const absentList: Employee[] = [];

    visibleEmployees.forEach(emp => {
      const record = todaysRecords.find(r => r.employeeId === emp.id);
      const leave = todaysLeaves.find(l => l.employeeId === emp.id);

      if (record) {
        if (record.status === 'Late') lateList.push({ emp, record });
        else presentList.push({ emp, record });
      } else if (leave) {
        leaveList.push({ emp, req: leave });
      } else {
        absentList.push(emp);
      }
    });

    const pendingReqs = leaves.filter(l => l.status === LeaveStatus.PENDING && visibleEmployees.some(e => e.id === l.employeeId)).length;
    const myLeaves = leaves.filter(l => l.employeeId === currentUser.id && l.status === LeaveStatus.APPROVED);
    
    return { totalEmp: visibleEmployees.length, presentList, lateList, leaveList, absentList, pendingReqs, myLeaves };
  }, [visibleEmployees, attendance, leaves, todayStr, currentUser]);

  // --- PAYROLL PULSE (New: End-to-End Status) ---
  const payrollHealth = useMemo(() => {
     const currentMonthStr = todayStr.substring(0, 7);
     const myLateCount = attendance.filter(a => a.employeeId === currentUser.id && a.date.startsWith(currentMonthStr) && a.status === 'Late').length;
     
     return { late: myLateCount, status: myLateCount > 2 ? 'At Risk' : 'Good' };
  }, [attendance, currentUser.id, todayStr]);

  const greeting = useMemo(() => {
    const hour = currentTime.getHours();
    if (hour < 12) return { text: 'สวัสดีตอนเช้า', icon: Sun };
    if (hour < 18) return { text: 'สวัสดีตอนบ่าย', icon: Cloud };
    return { text: 'สวัสดีตอนเย็น', icon: CloudRain };
  }, [currentTime]);

  const GreetingIcon = greeting.icon;

  const attendanceTrend = [
    { name: 'จันทร์', rate: 95 }, { name: 'อังคาร', rate: 92 }, { name: 'พุธ', rate: 98 },
    { name: 'พฤหัส', rate: 94 }, { name: 'ศุกร์', rate: Math.round(((dailyStats.presentList.length + dailyStats.lateList.length) / (dailyStats.totalEmp || 1)) * 100) || 0 }
  ];

  return (
    <div className="space-y-6 md:space-y-8 animate-fade-in font-sans pb-12 relative">
      
      {/* === MOBILE-FIRST HERO SECTION === */}
      <div className="block md:hidden">
         <div className="bg-brand-900 text-white rounded-3xl p-6 shadow-lg mb-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -mr-10 -mt-10"></div>
            <div className="relative z-10">
               <div className="flex justify-between items-start mb-4">
                  <div>
                     <p className="text-brand-200 text-xs font-bold uppercase tracking-wider">{currentTime.toLocaleDateString('th-TH', { weekday: 'long', day: 'numeric', month: 'short' })}</p>
                     <h1 className="text-2xl font-bold mt-1">สวัสดี, {currentUser.firstName}</h1>
                  </div>
                  <div className="text-right">
                     <div className="text-3xl font-bold tracking-tight">{currentTime.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })}</div>
                  </div>
               </div>
               
               <button onClick={() => onNavigate(Tab.ATTENDANCE)} className="w-full bg-white text-brand-900 py-4 rounded-2xl font-bold shadow-lg flex items-center justify-center gap-2 active:scale-95 transition-transform">
                  <Clock size={20} /> ลงเวลาเข้างาน (Check-in)
               </button>
            </div>
         </div>

         {/* Mobile Quick Actions */}
         <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="bg-white p-3 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-center items-center active:bg-slate-50 transition-colors" onClick={() => onNavigate(Tab.LEAVE)}>
               <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mb-2">
                  <Briefcase size={20} />
               </div>
               <span className="font-bold text-slate-700 text-xs">ขอลาหยุด</span>
            </div>
            <div className="bg-white p-3 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-center items-center active:bg-slate-50 transition-colors" onClick={() => onNavigate(Tab.SHIFT)}>
               <div className="w-10 h-10 bg-purple-50 text-purple-600 rounded-full flex items-center justify-center mb-2">
                  <Calendar size={20} />
               </div>
               <span className="font-bold text-slate-700 text-xs">ดูตารางงาน</span>
            </div>
            <div className="bg-white p-3 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-center items-center active:bg-slate-50 transition-colors" onClick={onNavigateToExpense}>
               <div className="w-10 h-10 bg-orange-50 text-orange-600 rounded-full flex items-center justify-center mb-2">
                  <Wallet size={20} />
               </div>
               <span className="font-bold text-slate-700 text-xs">เบิกค่าใช้จ่าย</span>
            </div>
         </div>
         
         <h3 className="font-bold text-slate-800 text-lg mb-3">ภาพรวมวันนี้</h3>
         <div className="grid grid-cols-2 gap-3">
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm"><div className="text-xs text-slate-400 font-bold uppercase">มาทำงาน</div><div className="text-2xl font-bold text-emerald-600">{dailyStats.presentList.length}</div></div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm"><div className="text-xs text-slate-400 font-bold uppercase">มาสาย</div><div className="text-2xl font-bold text-amber-500">{dailyStats.lateList.length}</div></div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm"><div className="text-xs text-slate-400 font-bold uppercase">ลางาน</div><div className="text-2xl font-bold text-blue-600">{dailyStats.leaveList.length}</div></div>
            <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm"><div className="text-xs text-slate-400 font-bold uppercase">รออนุมัติ</div><div className="text-2xl font-bold text-slate-700">{dailyStats.pendingReqs}</div></div>
         </div>
      </div>

      {/* --- DESKTOP HERO SECTION (Hidden on Mobile) --- */}
      <div className="hidden md:grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl p-8 text-slate-800 relative overflow-hidden shadow-soft border border-slate-200 group">
           <div className="absolute top-0 right-0 w-64 h-64 bg-brand-50/50 rounded-full -translate-y-1/2 translate-x-1/4 blur-3xl"></div>
           
           <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
              <div>
                 <div className="flex items-center gap-2 text-slate-500 mb-2 font-medium tracking-wide text-sm uppercase">
                    <GreetingIcon size={16} className="text-amber-500" />
                    <span>{currentTime.toLocaleDateString('th-TH', { weekday: 'long', day: 'numeric', month: 'long' })}</span>
                 </div>
                 <h1 className="text-3xl md:text-5xl font-bold font-sans mb-3 leading-tight tracking-tight text-slate-900">
                    {greeting.text}, <span className="text-brand-700">{currentUser.firstName}</span>
                 </h1>
                 
                 <div className="flex items-center gap-2 mt-2">
                    <span className="px-2 py-1 bg-slate-100 text-slate-600 text-xs font-bold rounded uppercase border border-slate-200">{currentUser.role}</span>
                    {currentUser.role === Role.MANAGER && <span className="text-xs text-slate-400">แผนก: {currentUser.department}</span>}
                 </div>

                 <p className="text-slate-600 max-w-md text-sm leading-relaxed mt-4">
                    คุณมีรายการรออนุมัติ <span className="font-bold text-brand-600 bg-brand-50 px-1 rounded">{dailyStats.pendingReqs} รายการ</span> ในขอบเขตความรับผิดชอบของคุณ
                 </p>
                 
                 <div className="flex gap-4 mt-8">
                    <button onClick={() => onNavigate(Tab.ATTENDANCE)} className="bg-brand-700 text-white px-6 py-3 rounded-xl font-bold text-sm shadow-md hover:bg-brand-800 transition-all flex items-center gap-2 transform hover:-translate-y-0.5">
                       <Clock size={18} /> ลงเวลาเข้างาน
                    </button>
                    <button onClick={() => onNavigate(Tab.LEAVE)} className="bg-white text-slate-700 border border-slate-200 px-6 py-3 rounded-xl font-bold text-sm hover:bg-slate-50 hover:border-brand-500 hover:text-brand-700 transition-all flex items-center gap-2">
                       <Briefcase size={18} /> ขอลาหยุด
                    </button>
                    <button onClick={onNavigateToExpense} className="bg-white text-slate-700 border border-slate-200 px-6 py-3 rounded-xl font-bold text-sm hover:bg-slate-50 hover:border-brand-500 hover:text-brand-700 transition-all flex items-center gap-2">
                       <Wallet size={18} /> เบิกค่าใช้จ่าย
                    </button>
                 </div>
              </div>
              
              <div className="bg-slate-50 border border-slate-100 p-5 rounded-2xl text-center min-w-[160px] shadow-sm">
                 <p className="text-[10px] text-slate-400 uppercase tracking-[0.25em] font-bold mb-2">Bangkok</p>
                 <div className="text-4xl font-bold font-sans tabular-nums tracking-wider text-slate-800">
                    {currentTime.toLocaleTimeString('th-TH', { hour12: false, hour: '2-digit', minute: '2-digit' })}
                 </div>
                 <div className="text-xs font-medium text-slate-500 mt-2 flex justify-center items-center gap-1.5">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div> Live
                 </div>
              </div>
           </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-soft border border-slate-200 flex flex-col justify-between relative overflow-hidden">
           {/* Payroll Pulse Widget */}
           <div className="flex justify-between items-start z-10">
              <div>
                 <h3 className="font-bold text-slate-800 text-lg flex items-center gap-2"><Activity size={18} className="text-brand-600"/> สถานะเงินเดือน (Payroll Pulse)</h3>
                 <p className="text-xs text-slate-400 uppercase tracking-wider mt-1">สถานะรอบปัจจุบัน</p>
              </div>
           </div>
           
           <div className="flex-1 flex flex-col justify-center gap-4 mt-2">
              <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl border border-slate-100">
                 <span className="text-xs font-bold text-slate-500">มาสาย (Late)</span>
                 <span className={`text-sm font-bold ${payrollHealth.late > 0 ? 'text-amber-600' : 'text-green-600'}`}>
                    {payrollHealth.late} ครั้ง
                 </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl border border-slate-100">
                 <span className="text-xs font-bold text-slate-500">คาดการณ์ (Projection)</span>
                 <span className={`text-sm font-bold ${payrollHealth.status === 'At Risk' ? 'text-red-500' : 'text-green-600'}`}>
                    {payrollHealth.status === 'At Risk' ? 'เสี่ยงถูกหักเงิน (Deduction Risk)' : 'ปกติ (Normal)'}
                 </span>
              </div>
              <button 
                onClick={() => onNavigate(Tab.PAYROLL)} 
                className="w-full py-2 bg-brand-100 text-brand-700 rounded-lg text-xs font-bold hover:bg-brand-200 transition-colors"
              >
                 ตรวจสอบรายละเอียด
              </button>
           </div>
        </div>
      </div>

      {/* ... (Keep existing Desktop Section 2 & 3 & Drill Down Modal) ... */}
      <div className="hidden md:block">
         <div className="flex items-center justify-between mb-6 px-2">
            <h2 className="text-2xl font-bold text-slate-800 font-sans flex items-center gap-3">
               <div className="p-2 bg-brand-100 text-brand-700 rounded-lg"><Briefcase size={20} /></div>
               ภาพรวมวันนี้ (Real-time Status)
            </h2>
            <div className="flex gap-2">
               <span className="text-xs font-bold text-slate-600 bg-white border border-slate-200 px-4 py-2 rounded-full shadow-sm">
                  ขอบเขต (Scope): <span className="text-slate-900 ml-1">
                     {currentUser.role === Role.STAFF ? 'ส่วนตัว (My Status)' : `${visibleEmployees.length} พนักงาน`}
                  </span>
               </span>
            </div>
         </div>

         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard title="มาทำงาน" value={dailyStats.presentList.length} subtext="เข้างานทันเวลา" icon={CheckCircle2} theme="success" onClick={() => setSelectedCategory('present')} isAction />
            <StatCard title="มาสาย" value={dailyStats.lateList.length} subtext="จากเวลาเข้างาน" icon={Clock} theme="warning" onClick={() => setSelectedCategory('late')} isAction />
            <StatCard title="ลางาน" value={dailyStats.leaveList.length} subtext="ลาป่วย / ลากิจ / พักร้อน" icon={Coffee} theme="brand" onClick={() => setSelectedCategory('leave')} isAction />
             <StatCard title="ขาดงาน/ยังไม่เข้า" value={dailyStats.absentList.length} subtext="ยังไม่มีบันทึกเวลา" icon={AlertCircle} theme="danger" isAction onClick={() => setSelectedCategory('absent')} />
         </div>
      </div>

      <div className="hidden md:grid grid-cols-1 xl:grid-cols-3 gap-6">
         <div className="xl:col-span-2 bg-white rounded-2xl p-8 shadow-soft border border-slate-200">
            <div className="flex justify-between items-center mb-8">
               <div>
                  <h3 className="font-bold text-slate-800 text-lg">สถิติการลงเวลา (Analytics)</h3>
                  <p className="text-xs text-slate-500 mt-1">ประสิทธิภาพการเข้างานรายสัปดาห์</p>
               </div>
               <select className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 outline-none text-slate-700 font-medium cursor-pointer">
                  <option>สัปดาห์นี้ (This Week)</option>
                  <option>เดือนนี้ (This Month)</option>
               </select>
            </div>
            <div className="h-[300px] w-full">
               <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={attendanceTrend}>
                     {/* ... (Existing chart config) ... */}
                     <defs>
                        <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
                           <stop offset="5%" stopColor={COLORS.brand} stopOpacity={0.3}/>
                           <stop offset="95%" stopColor={COLORS.brand} stopOpacity={0}/>
                        </linearGradient>
                     </defs>
                     <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                     <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748B', fontSize: 12}} dy={15} />
                     <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748B', fontSize: 12}} />
                     <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #E2E8F0' }} />
                     <Area type="monotone" dataKey="rate" stroke={COLORS.brand} strokeWidth={3} fillOpacity={1} fill="url(#colorRate)" />
                  </AreaChart>
               </ResponsiveContainer>
            </div>
         </div>

         {/* Right Column: Absences List Preview */}
         <div className="bg-white rounded-2xl p-6 shadow-soft border border-slate-200 flex flex-col">
            <h3 className="font-bold text-slate-800 text-lg mb-6 flex items-center justify-between">
               <span>วันนี้ใครลาบ้าง?</span>
               <span className="text-[10px] font-bold text-brand-700 bg-brand-100 px-2.5 py-1 rounded-full">{dailyStats.leaveList.length}</span>
            </h3>
            
            <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-4 max-h-[350px] xl:max-h-none">
               {dailyStats.leaveList.map(({emp, req}) => (
                  <div key={req.id} className="flex items-center gap-4 p-4 rounded-xl bg-slate-50 border border-slate-100 hover:bg-slate-100 transition-colors cursor-pointer group">
                     <div className="relative">
                        <img src={emp.avatarUrl} className="w-12 h-12 rounded-full object-cover border border-white shadow-sm" />
                        <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white flex items-center justify-center ${req.type === LeaveType.SICK ? 'bg-red-500' : 'bg-blue-500'}`}>
                           <span className="w-1.5 h-1.5 bg-white rounded-full"></span>
                        </div>
                     </div>
                     <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-slate-800 truncate group-hover:text-brand-600 transition-colors">{emp.firstName} {emp.lastName}</p>
                        <p className="text-xs text-slate-500 font-medium">{req.type}</p>
                     </div>
                  </div>
               ))}
               {dailyStats.leaveList.length === 0 && (
                  <div className="h-full flex flex-col items-center justify-center text-slate-400 text-center py-10 opacity-70">
                     <Sun size={48} className="mb-3 text-amber-400" />
                     <p className="text-sm font-medium">วันนี้ทุกคนมาทำงานครับ!</p>
                  </div>
               )}
            </div>
         </div>
      </div>

      {/* --- DRILL DOWN MODAL --- */}
      {selectedCategory && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setSelectedCategory(null)}>
           <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[80vh] flex flex-col animate-fade-in-up" onClick={e => e.stopPropagation()}>
              
              {/* Modal Header */}
              <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50 rounded-t-2xl">
                 <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-xl ${
                       selectedCategory === 'present' ? 'bg-emerald-100 text-emerald-600' :
                       selectedCategory === 'late' ? 'bg-amber-100 text-amber-600' :
                       selectedCategory === 'leave' ? 'bg-brand-100 text-brand-600' :
                       'bg-red-100 text-red-600'
                    }`}>
                       {selectedCategory === 'present' && <CheckCircle2 size={24} />}
                       {selectedCategory === 'late' && <Clock size={24} />}
                       {selectedCategory === 'leave' && <Coffee size={24} />}
                       {selectedCategory === 'absent' && <AlertCircle size={24} />}
                    </div>
                    <div>
                       <h3 className="text-xl font-bold text-slate-800">
                          {selectedCategory === 'present' && 'พนักงานที่มาทำงาน'}
                          {selectedCategory === 'late' && 'พนักงานที่มาสาย'}
                          {selectedCategory === 'leave' && 'พนักงานที่ลางาน'}
                          {selectedCategory === 'absent' && 'ขาดงาน / ยังไม่เข้า'}
                       </h3>
                       <p className="text-sm text-slate-500">ประจำวันที่ {new Date().toLocaleDateString('th-TH', {dateStyle: 'long'})}</p>
                    </div>
                 </div>
                 <button onClick={() => setSelectedCategory(null)} className="p-2 hover:bg-slate-200 rounded-full text-slate-400 hover:text-slate-600 transition-colors">
                    <X size={24} />
                 </button>
              </div>

              {/* Modal List Content */}
              <div className="flex-1 overflow-y-auto p-2">
                 <div className="space-y-1">
                    {/* PRESENT LIST */}
                    {selectedCategory === 'present' && dailyStats.presentList.map(({emp, record}) => (
                       <div key={emp.id} className="flex items-center gap-4 p-4 hover:bg-slate-50 rounded-xl transition-colors border-b border-slate-50 last:border-0">
                          <img src={emp.avatarUrl} className="w-10 h-10 rounded-full border border-slate-200" />
                          <div className="flex-1">
                             <h4 className="font-bold text-slate-700 text-sm">{emp.firstName} {emp.lastName}</h4>
                             <p className="text-xs text-slate-500">{emp.position}</p>
                          </div>
                          <div className="text-right">
                             <p className="text-sm font-bold text-emerald-600 font-mono">
                                {record.checkIn ? new Date(record.checkIn).toLocaleTimeString('th-TH', {hour:'2-digit', minute:'2-digit'}) : '-'}
                             </p>
                             <div className="flex items-center gap-1 text-[10px] text-slate-400 justify-end">
                                <MapPin size={10} /> ในพื้นที่
                             </div>
                          </div>
                       </div>
                    ))}

                    {/* LATE LIST */}
                    {selectedCategory === 'late' && dailyStats.lateList.map(({emp, record}) => (
                       <div key={emp.id} className="flex items-center gap-4 p-4 hover:bg-slate-50 rounded-xl transition-colors border-b border-slate-50 last:border-0">
                          <img src={emp.avatarUrl} className="w-10 h-10 rounded-full border border-slate-200" />
                          <div className="flex-1">
                             <h4 className="font-bold text-slate-700 text-sm">{emp.firstName} {emp.lastName}</h4>
                             <p className="text-xs text-slate-500">{emp.department}</p>
                          </div>
                          <div className="text-right">
                             <p className="text-sm font-bold text-amber-600 font-mono">
                                {record.checkIn ? new Date(record.checkIn).toLocaleTimeString('th-TH', {hour:'2-digit', minute:'2-digit'}) : '-'}
                             </p>
                             <div className="text-[10px] text-red-500 font-bold">สาย (Late)</div>
                          </div>
                       </div>
                    ))}

                    {/* LEAVE LIST */}
                    {selectedCategory === 'leave' && dailyStats.leaveList.map(({emp, req}) => (
                       <div key={emp.id} className="flex items-center gap-4 p-4 hover:bg-slate-50 rounded-xl transition-colors border-b border-slate-50 last:border-0">
                          <img src={emp.avatarUrl} className="w-10 h-10 rounded-full border border-slate-200" />
                          <div className="flex-1">
                             <h4 className="font-bold text-slate-700 text-sm">{emp.firstName} {emp.lastName}</h4>
                             <p className="text-xs text-slate-500">{emp.department}</p>
                          </div>
                          <div className="text-right">
                             <span className="px-2 py-1 rounded bg-brand-50 text-brand-700 text-xs font-bold border border-brand-100">
                                {req.type}
                             </span>
                          </div>
                       </div>
                    ))}

                    {/* ABSENT LIST */}
                    {selectedCategory === 'absent' && dailyStats.absentList.map((emp) => (
                       <div key={emp.id} className="flex items-center gap-4 p-4 hover:bg-slate-50 rounded-xl transition-colors border-b border-slate-50 last:border-0">
                          <img src={emp.avatarUrl} className="w-10 h-10 rounded-full border border-slate-200 grayscale opacity-80" />
                          <div className="flex-1">
                             <h4 className="font-bold text-slate-700 text-sm">{emp.firstName} {emp.lastName}</h4>
                             <div className="flex gap-2 text-xs text-slate-500">
                                <span>{emp.department}</span>
                                <span>•</span>
                                <span>{emp.phone || '-'}</span>
                             </div>
                          </div>
                          <div className="text-right">
                             <span className="px-2 py-1 rounded bg-red-50 text-red-600 text-xs font-bold border border-red-100">
                                ยังไม่ลงเวลา
                             </span>
                          </div>
                       </div>
                    ))}

                    {/* EMPTY STATES */}
                    {selectedCategory === 'present' && dailyStats.presentList.length === 0 && <EmptyState msg="ไม่มีพนักงานมาทำงาน (หรือยังไม่ถึงเวลา)" />}
                    {selectedCategory === 'late' && dailyStats.lateList.length === 0 && <EmptyState msg="ไม่มีพนักงานมาสาย ยอดเยี่ยม!" icon={CheckCircle2} />}
                    {selectedCategory === 'leave' && dailyStats.leaveList.length === 0 && <EmptyState msg="ไม่มีพนักงานลางานวันนี้" />}
                    {selectedCategory === 'absent' && dailyStats.absentList.length === 0 && <EmptyState msg="ครบองค์ประชุม! ไม่มีใครขาดงาน" icon={CheckCircle2} />}

                 </div>
              </div>
           </div>
        </div>
      )}

    </div>
  );
};

// --- Helper Components ---
const EmptyState = ({ msg, icon: Icon = AlertCircle }: { msg: string, icon?: any }) => (
   <div className="flex flex-col items-center justify-center py-12 text-slate-400">
      <Icon size={48} className="mb-3 opacity-20" />
      <p className="text-sm font-medium">{msg}</p>
   </div>
);

interface StatCardProps {
   title: string;
   value: number | string;
   subtext: string;
   icon: any;
   theme: 'brand' | 'success' | 'warning' | 'purple' | 'danger' | 'accent';
   trend?: string;
   isAction?: boolean;
   onClick?: () => void;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, subtext, icon: Icon, theme, trend, isAction, onClick }) => {
   const themes = {
      brand: { bg: 'bg-white', text: 'text-brand-600', iconColor: 'text-brand-700', iconBg: 'bg-brand-100', border: 'hover:border-brand-300' },
      success: { bg: 'bg-white', text: 'text-emerald-600', iconColor: 'text-emerald-700', iconBg: 'bg-emerald-100', border: 'hover:border-emerald-300' },
      warning: { bg: 'bg-white', text: 'text-amber-600', iconColor: 'text-amber-700', iconBg: 'bg-amber-100', border: 'hover:border-amber-300' },
      purple: { bg: 'bg-white', text: 'text-purple-600', iconColor: 'text-purple-700', iconBg: 'bg-purple-100', border: 'hover:border-purple-300' },
      danger: { bg: 'bg-white', text: 'text-red-600', iconColor: 'text-red-700', iconBg: 'bg-red-100', border: 'hover:border-red-300' },
      accent: { bg: 'bg-white', text: 'text-slate-800', iconColor: 'text-white', iconBg: 'bg-slate-900', border: 'hover:border-slate-400' },
   };
   
   const t = themes[theme];

   return (
      <div 
         onClick={onClick}
         className={`
            bg-white p-6 rounded-2xl border border-slate-200 shadow-soft transition-all duration-300 group
            ${isAction ? `cursor-pointer hover:-translate-y-1 hover:shadow-lg ${t.border}` : 'hover:border-slate-300'}
         `}
      >
         <div className="flex justify-between items-start mb-4">
            <div className={`w-12 h-12 rounded-xl ${t.iconBg} ${t.iconColor} flex items-center justify-center shadow-sm transform group-hover:scale-110 transition-transform duration-300`}>
               <Icon size={24} />
            </div>
            {isAction && (
               <div className="p-1 rounded-full text-slate-300 group-hover:bg-slate-50 group-hover:text-slate-500 transition-colors">
                  <ChevronRight size={18} />
               </div>
            )}
         </div>
         <div>
            <h4 className="text-4xl font-bold text-slate-800 font-sans tabular-nums mb-1 tracking-tight">{value}</h4>
            <p className="text-sm text-slate-500 font-medium uppercase tracking-wide">{title}</p>
            <p className="text-xs text-slate-400 mt-2 font-medium">{subtext}</p>
         </div>
      </div>
   );
};
