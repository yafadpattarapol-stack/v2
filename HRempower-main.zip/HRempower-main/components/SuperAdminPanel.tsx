
import React, { useState } from 'react';
import { Organization, CompanySettings, Employee, Role, Department, EmployeeStatus, EmploymentType } from '../types';
import { MOCK_COMPANY_SETTINGS, SUPER_ADMIN_ORG_ID } from '../constants';
import { Building, Plus, Users, Calendar, CheckCircle2, XCircle, Search, MoreHorizontal, Edit2, Shield, Copy, Check, Upload, Mail, User, ShieldAlert, Activity, Lock, UserPlus, FileText, AlertTriangle, Trash2, X, Pencil } from 'lucide-react';

interface SuperAdminPanelProps {
  organizations: Organization[];
  onAddOrganization: (org: Organization, owner: Employee) => void;
  onUpdateOrganization: (org: Organization) => void;
  onSwitchOrganization: (orgId: string) => void;
}

// Mock Internal Team Data (Initial State)
const INITIAL_ADMIN_TEAM = [
   { id: 'ADM01', name: 'Yafad System Admin', email: 'yafad', role: 'Owner (Super Admin)', status: 'Active', lastLogin: 'Now' },
   { id: 'ADM02', name: 'Dev Support', email: 'dev@empowerhr.com', role: 'Support', status: 'Active', lastLogin: '2h ago' },
];

const MOCK_INTERNAL_LOGS = [
   { id: 1, action: 'LOGIN_SUCCESS', actor: 'Yafad Admin', target: 'System', time: '2023-10-26 09:00:00', ip: '192.168.1.1' },
   { id: 2, action: 'CREATE_ORG', actor: 'Yafad Admin', target: 'Tech Startup B', time: '2023-10-26 10:30:00', ip: '192.168.1.1' },
   { id: 3, action: 'VIEW_PAYROLL', actor: 'Support Staff', target: 'EmpowerHR Demo', time: '2023-10-26 14:15:00', ip: '10.0.0.5' },
   { id: 4, action: 'RESET_PASSWORD', actor: 'Yafad Admin', target: 'CEO (Tech B)', time: '2023-10-27 09:45:00', ip: '192.168.1.1' },
];

export const SuperAdminPanel: React.FC<SuperAdminPanelProps> = ({ 
  organizations, onAddOrganization, onUpdateOrganization, onSwitchOrganization 
}) => {
  const [activeTab, setActiveTab] = useState<'orgs' | 'team' | 'logs'>('orgs');
  
  // Organization Modal State
  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Team Management State
  const [adminTeam, setAdminTeam] = useState(INITIAL_ADMIN_TEAM);
  const [showTeamModal, setShowTeamModal] = useState(false);
  const [teamModalMode, setTeamModalMode] = useState<'create' | 'edit'>('create');
  const [editingTeamId, setEditingTeamId] = useState<string | null>(null);
  const [teamFormData, setTeamFormData] = useState({ name: '', email: '', role: 'Support' });

  // Org Form Data
  const [orgId, setOrgId] = useState('');
  const [orgName, setOrgName] = useState('');
  const [orgLogo, setOrgLogo] = useState('');
  
  // Owner Form Data
  const [ownerFirstName, setOwnerFirstName] = useState('');
  const [ownerLastName, setOwnerLastName] = useState('');
  const [ownerEmail, setOwnerEmail] = useState('');

  // Credentials
  const [credentialModal, setCredentialModal] = useState<{email: string, password: string} | null>(null);
  const [copied, setCopied] = useState(false);

  const filteredOrgs = organizations.filter(org => 
    org.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    org.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // --- Handlers ---
  const handleOpenCreate = () => { setModalMode('create'); setOrgName(''); setOrgLogo(''); setOwnerFirstName(''); setOwnerLastName(''); setOwnerEmail(''); setShowModal(true); };
  const handleOpenEdit = (org: Organization) => { setModalMode('edit'); setOrgId(org.id); setOrgName(org.name); setOrgLogo(org.settings.logoUrl || ''); setShowModal(true); };
  
  const handleCreate = (e: React.FormEvent) => { 
      e.preventDefault(); 
      if (!orgName || !ownerEmail) return; 
      const newOrgId = `ORG${Date.now()}`; 
      const defaultSettings: CompanySettings = JSON.parse(JSON.stringify(MOCK_COMPANY_SETTINGS)); 
      defaultSettings.name = orgName; 
      defaultSettings.nameEn = orgName; 
      if(orgLogo) defaultSettings.logoUrl = orgLogo; 
      
      const newOrg: Organization = { id: newOrgId, name: orgName, settings: defaultSettings, createdAt: new Date().toISOString().split('T')[0], isActive: true }; 
      const randomPassword = Math.random().toString(36).slice(-8); 
      const newOwner: Employee = { 
          id: `CEO-${Date.now()}`, orgId: newOrgId, firstName: ownerFirstName, lastName: ownerLastName, email: ownerEmail, phone: '', 
          password: randomPassword, forcePasswordChange: true, role: Role.CEO, position: 'CEO / Owner', department: Department.EXECUTIVE, 
          status: EmployeeStatus.PERMANENT, employmentType: EmploymentType.MONTHLY, joinDate: new Date().toISOString().split('T')[0], 
          salary: 0, avatarUrl: `https://ui-avatars.com/api/?name=${ownerFirstName}+${ownerLastName}&background=random` 
      }; 
      onAddOrganization(newOrg, newOwner); 
      setShowModal(false); 
      setCredentialModal({ email: ownerEmail, password: randomPassword }); 
  };

  const handleUpdate = (e: React.FormEvent) => { 
      e.preventDefault(); 
      const org = organizations.find(o => o.id === orgId); 
      if (org) { 
          const updatedOrg = { ...org, name: orgName, settings: { ...org.settings, name: orgName, logoUrl: orgLogo || org.settings.logoUrl } }; 
          onUpdateOrganization(updatedOrg); 
          setShowModal(false); 
      } 
  };

  // --- Team Member Handlers ---
  const handleOpenAddTeam = () => {
      setTeamModalMode('create');
      setTeamFormData({ name: '', email: '', role: 'Support' });
      setShowTeamModal(true);
  };

  const handleOpenEditTeam = (member: typeof INITIAL_ADMIN_TEAM[0]) => {
      setTeamModalMode('edit');
      setEditingTeamId(member.id);
      setTeamFormData({ name: member.name, email: member.email, role: member.role });
      setShowTeamModal(true);
  };

  const handleSaveTeamMember = (e: React.FormEvent) => {
      e.preventDefault();
      if (!teamFormData.name || !teamFormData.email) return;

      if (teamModalMode === 'create') {
          const newAdmin = {
              id: `ADM-${Date.now()}`,
              name: teamFormData.name,
              email: teamFormData.email,
              role: teamFormData.role,
              status: 'Active',
              lastLogin: 'Never'
          };
          setAdminTeam([...adminTeam, newAdmin]);
      } else if (teamModalMode === 'edit' && editingTeamId) {
          setAdminTeam(prev => prev.map(m => m.id === editingTeamId ? { ...m, ...teamFormData } : m));
      }
      setShowTeamModal(false);
  };

  const handleDeleteTeamMember = (id: string) => {
      if (confirm('Are you sure you want to remove this team member? This action cannot be undone.')) {
          setAdminTeam(adminTeam.filter(m => m.id !== id));
      }
  };

  const copyCredentials = () => { if (credentialModal) { const text = `EmpowerHR Credentials\nEmail: ${credentialModal.email}\nPassword: ${credentialModal.password}`; navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); } };

  // --- Render Functions ---

  const renderOrgs = () => (
    <div className="space-y-6">
       {/* Search & Action Bar */}
       <div className="flex flex-col md:flex-row justify-between gap-4">
          <div className="relative max-w-md w-full">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
             <input 
               type="text" 
               placeholder="Search organizations..." 
               className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
             />
          </div>
          <button 
             onClick={handleOpenCreate}
             className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-indigo-200 flex items-center gap-2 transition-transform active:scale-95 whitespace-nowrap"
          >
             <Plus size={18} /> New Organization
          </button>
       </div>

       {/* Grid */}
       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredOrgs.map(org => (
             <div key={org.id} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all group relative overflow-hidden flex flex-col">
                <div className={`absolute top-0 right-0 w-20 h-20 bg-gradient-to-br ${org.isActive ? 'from-emerald-500/20 to-transparent' : 'from-slate-200 to-transparent'} rounded-bl-full -mr-10 -mt-10`}></div>
                <div className="flex justify-between items-start mb-4 relative z-10">
                   <div className="w-16 h-16 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-center p-2">
                      {org.settings.logoUrl && !org.settings.logoUrl.includes('ui-avatars') ? (
                         <img src={org.settings.logoUrl} className="w-full h-full object-contain" />
                      ) : (
                         <Building size={28} className="text-indigo-600" />
                      )}
                   </div>
                   <button onClick={() => handleOpenEdit(org)} className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded-lg transition-colors">
                      <Edit2 size={18} />
                   </button>
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-1 line-clamp-1">{org.name}</h3>
                <p className="text-xs text-slate-400 font-mono mb-6">ID: {org.id}</p>
                <div className="space-y-3 mb-6 flex-1">
                   <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Calendar size={14} className="text-slate-400" />
                      <span>Created: {new Date(org.createdAt).toLocaleDateString()}</span>
                   </div>
                   <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Shield size={14} className="text-slate-400" />
                      <span>Admin Access</span>
                   </div>
                </div>
                <button 
                  onClick={() => onSwitchOrganization(org.id)}
                  className="w-full py-3 bg-slate-800 text-white rounded-xl font-bold text-sm hover:bg-slate-700 transition-colors shadow-lg shadow-slate-200"
                >
                   Access Dashboard
                </button>
             </div>
          ))}
       </div>
    </div>
  );

  const renderTeam = () => (
     <div className="space-y-6">
        <div className="flex justify-between items-center bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
           <div>
              <h3 className="text-xl font-bold text-indigo-900">Platform Team Management</h3>
              <p className="text-indigo-700 text-sm mt-1">Manage your internal staff who have access to the Super Admin panel.</p>
           </div>
           <button 
              onClick={handleOpenAddTeam}
              className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-md hover:bg-indigo-700 transition-all flex items-center gap-2"
           >
              <UserPlus size={18} /> Add Team Member
           </button>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
           <table className="w-full text-left">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase">
                 <tr>
                    <th className="px-6 py-4">Admin Name</th>
                    <th className="px-6 py-4">Role</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Last Login</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                 </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                 {adminTeam.map(admin => (
                    <tr key={admin.id} className="hover:bg-slate-50 transition-colors">
                       <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                             <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-bold text-xs">{admin.name.charAt(0)}</div>
                             <div>
                                <p className="font-bold text-slate-800">{admin.name}</p>
                                <p className="text-xs text-slate-500">{admin.email}</p>
                             </div>
                          </div>
                       </td>
                       <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded text-xs font-bold ${admin.role.includes('Owner') ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-600'}`}>
                             {admin.role}
                          </span>
                       </td>
                       <td className="px-6 py-4">
                          <span className="flex items-center gap-1.5 text-green-600 font-bold text-xs">
                             <span className="w-2 h-2 rounded-full bg-green-500"></span> Active
                          </span>
                       </td>
                       <td className="px-6 py-4 text-slate-500">{admin.lastLogin}</td>
                       <td className="px-6 py-4 text-right">
                          <div className="flex justify-end gap-1">
                             <button onClick={() => handleOpenEditTeam(admin)} className="text-slate-400 hover:text-blue-600 transition-colors p-2 hover:bg-blue-50 rounded-lg">
                                <Pencil size={18}/>
                             </button>
                             <button onClick={() => handleDeleteTeamMember(admin.id)} className="text-slate-400 hover:text-red-600 transition-colors p-2 hover:bg-red-50 rounded-lg">
                                <Trash2 size={18}/>
                             </button>
                          </div>
                       </td>
                    </tr>
                 ))}
              </tbody>
           </table>
        </div>
     </div>
  );

  const renderLogs = () => (
     <div className="space-y-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-start gap-4">
           <div className="p-3 bg-amber-50 rounded-xl text-amber-600"><ShieldAlert size={24} /></div>
           <div>
              <h3 className="text-lg font-bold text-slate-800">Security Audit Logs</h3>
              <p className="text-sm text-slate-500 mt-1">
                 Track sensitive actions performed by Platform Admins across all tenant organizations.
                 This is critical for security compliance and troubleshooting.
              </p>
           </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
           <table className="w-full text-left">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase">
                 <tr>
                    <th className="px-6 py-4">Timestamp</th>
                    <th className="px-6 py-4">Action</th>
                    <th className="px-6 py-4">Actor (Admin)</th>
                    <th className="px-6 py-4">Target Tenant</th>
                    <th className="px-6 py-4">IP Address</th>
                 </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                 {MOCK_INTERNAL_LOGS.map(log => (
                    <tr key={log.id} className="hover:bg-slate-50 transition-colors font-mono text-xs">
                       <td className="px-6 py-4 text-slate-500">{log.time}</td>
                       <td className="px-6 py-4">
                          <span className={`font-bold ${log.action.includes('LOGIN') ? 'text-green-600' : log.action.includes('RESET') ? 'text-red-600' : 'text-blue-600'}`}>
                             {log.action}
                          </span>
                       </td>
                       <td className="px-6 py-4 font-bold text-slate-700">{log.actor}</td>
                       <td className="px-6 py-4 text-slate-600">{log.target}</td>
                       <td className="px-6 py-4 text-slate-400">{log.ip}</td>
                    </tr>
                 ))}
              </tbody>
           </table>
        </div>
     </div>
  );

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-800">Platform Command Center</h2>
          <p className="text-slate-500 mt-1">Centralized management for SaaS Tenants and Platform Team</p>
        </div>
        
        {/* Navigation Tabs */}
        <div className="flex bg-white p-1 rounded-xl border border-slate-200 shadow-sm">
           <button onClick={() => setActiveTab('orgs')} className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${activeTab === 'orgs' ? 'bg-slate-800 text-white shadow' : 'text-slate-500 hover:bg-slate-50'}`}>
              <Building size={16}/> Organizations
           </button>
           <button onClick={() => setActiveTab('team')} className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${activeTab === 'team' ? 'bg-indigo-600 text-white shadow' : 'text-slate-500 hover:bg-slate-50'}`}>
              <Users size={16}/> Platform Team
           </button>
           <button onClick={() => setActiveTab('logs')} className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${activeTab === 'logs' ? 'bg-amber-600 text-white shadow' : 'text-slate-500 hover:bg-slate-50'}`}>
              <Activity size={16}/> Audit Logs
           </button>
        </div>
      </div>

      {activeTab === 'orgs' && renderOrgs()}
      {activeTab === 'team' && renderTeam()}
      {activeTab === 'logs' && renderLogs()}

      {/* Team Member Modal */}
      {showTeamModal && (
         <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 animate-fade-in-up">
               <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                     {teamModalMode === 'create' ? <UserPlus size={20} className="text-indigo-600" /> : <Pencil size={20} className="text-indigo-600" />}
                     {teamModalMode === 'create' ? 'Add Team Member' : 'Edit Team Member'}
                  </h3>
                  <button onClick={() => setShowTeamModal(false)} className="text-slate-400 hover:text-slate-600"><X size={20}/></button>
               </div>
               
               <form onSubmit={handleSaveTeamMember} className="space-y-4">
                  <div>
                     <label className="block text-xs font-bold text-slate-500 mb-1">Full Name</label>
                     <input 
                        type="text" required 
                        className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
                        placeholder="e.g. John Doe"
                        value={teamFormData.name}
                        onChange={e => setTeamFormData({...teamFormData, name: e.target.value})}
                     />
                  </div>
                  <div>
                     <label className="block text-xs font-bold text-slate-500 mb-1">Email Address</label>
                     <input 
                        type="email" required 
                        className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
                        placeholder="john@empowerhr.com"
                        value={teamFormData.email}
                        onChange={e => setTeamFormData({...teamFormData, email: e.target.value})}
                     />
                  </div>
                  <div>
                     <label className="block text-xs font-bold text-slate-500 mb-1">Role</label>
                     <select 
                        className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
                        value={teamFormData.role}
                        onChange={e => setTeamFormData({...teamFormData, role: e.target.value})}
                     >
                        <option value="Support">Support (View Only)</option>
                        <option value="Admin">Admin (Full Access)</option>
                        <option value="Developer">Developer</option>
                        <option value="Owner (Super Admin)">Owner (Super Admin)</option>
                     </select>
                  </div>
                  
                  <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                     <button type="button" onClick={() => setShowTeamModal(false)} className="px-5 py-2 text-slate-500 hover:bg-slate-100 rounded-xl font-bold text-sm transition-colors">Cancel</button>
                     <button type="submit" className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 shadow-md transition-colors">
                        {teamModalMode === 'create' ? 'Add Member' : 'Save Changes'}
                     </button>
                  </div>
               </form>
            </div>
         </div>
      )}

      {/* Create/Edit Org Modal */}
      {showModal && (
         <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl p-8 animate-fade-in-up">
               <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-3">
                     <Building size={24} className="text-indigo-600" />
                     {modalMode === 'create' ? 'Create Organization' : 'Edit Organization'}
                  </h3>
                  <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600"><XCircle size={24}/></button>
               </div>
               
               <form onSubmit={modalMode === 'create' ? handleCreate : handleUpdate} className="space-y-6">
                  {/* Organization Section */}
                  <div className="space-y-4">
                     <h4 className="text-sm font-bold text-slate-500 uppercase tracking-wide border-b border-slate-100 pb-2">Organization Details</h4>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="md:col-span-2">
                           <label className="block text-sm font-medium text-slate-700 mb-1">Company Name</label>
                           <input 
                              type="text" required
                              className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                              placeholder="e.g. Acme Corp"
                              value={orgName}
                              onChange={e => setOrgName(e.target.value)}
                           />
                        </div>
                        <div className="md:col-span-2">
                           <label className="block text-sm font-medium text-slate-700 mb-1">Logo URL (Optional)</label>
                           <div className="flex gap-2">
                              <input 
                                 type="text" 
                                 className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none font-mono text-xs"
                                 placeholder="https://..."
                                 value={orgLogo}
                                 onChange={e => setOrgLogo(e.target.value)}
                              />
                              <div className="w-12 h-12 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-center shrink-0">
                                 {orgLogo ? <img src={orgLogo} className="w-full h-full object-contain p-1" /> : <Upload size={20} className="text-slate-300"/>}
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>

                  {/* Owner Section (Create Only) */}
                  {modalMode === 'create' && (
                     <div className="space-y-4 pt-2">
                        <h4 className="text-sm font-bold text-slate-500 uppercase tracking-wide border-b border-slate-100 pb-2">Owner Account (First Admin)</h4>
                        <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 flex items-start gap-3 mb-2">
                           <Shield className="text-blue-600 shrink-0 mt-0.5" size={18} />
                           <p className="text-xs text-blue-800">
                              A new CEO account will be created. The system will generate a temporary password which you can share with the client. They will be forced to change it upon first login.
                           </p>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                           <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">First Name</label>
                              <input 
                                 type="text" required
                                 className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                                 value={ownerFirstName}
                                 onChange={e => setOwnerFirstName(e.target.value)}
                              />
                           </div>
                           <div>
                              <label className="block text-sm font-medium text-slate-700 mb-1">Last Name</label>
                              <input 
                                 type="text" required
                                 className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                                 value={ownerLastName}
                                 onChange={e => setOwnerLastName(e.target.value)}
                              />
                           </div>
                           <div className="col-span-2">
                              <label className="block text-sm font-medium text-slate-700 mb-1">Email (Login Username)</label>
                              <div className="relative">
                                 <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                                 <input 
                                    type="email" required
                                    className="w-full pl-10 border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
                                    placeholder="client@company.com"
                                    value={ownerEmail}
                                    onChange={e => setOwnerEmail(e.target.value)}
                                 />
                              </div>
                           </div>
                        </div>
                     </div>
                  )}
                  
                  <div className="flex justify-end gap-3 pt-6 border-t border-slate-100">
                     <button type="button" onClick={() => setShowModal(false)} className="px-6 py-3 text-slate-500 hover:bg-slate-50 rounded-xl font-bold transition-colors">Cancel</button>
                     <button type="submit" className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 shadow-lg transition-colors">
                        {modalMode === 'create' ? 'Create Organization' : 'Save Changes'}
                     </button>
                  </div>
               </form>
            </div>
         </div>
      )}

      {/* Credential Success Modal */}
      {credentialModal && (
         <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60] animate-fade-in">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8 animate-fade-in-up text-center border-t-4 border-emerald-500">
               <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 size={32} className="text-emerald-600" />
               </div>
               <h3 className="text-2xl font-bold text-slate-800 mb-2">Organization Created!</h3>
               <p className="text-slate-500 mb-6 text-sm">
                  Please copy the credentials below and send them to the client. <br/>
                  <span className="text-red-500 font-bold">This password will not be shown again.</span>
               </p>

               <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-left space-y-3 mb-6 relative group">
                  <div>
                     <span className="text-xs font-bold text-slate-400 uppercase">Login Email</span>
                     <p className="font-mono text-slate-800 font-bold">{credentialModal.email}</p>
                  </div>
                  <div>
                     <span className="text-xs font-bold text-slate-400 uppercase">Temporary Password</span>
                     <p className="font-mono text-slate-800 font-bold text-lg tracking-wider">{credentialModal.password}</p>
                  </div>
                  <button 
                     onClick={copyCredentials}
                     className="absolute top-2 right-2 p-2 hover:bg-white rounded-lg text-slate-400 hover:text-indigo-600 transition-colors"
                     title="Copy"
                  >
                     {copied ? <Check size={18} className="text-green-500"/> : <Copy size={18}/>}
                  </button>
               </div>

               <button 
                  onClick={() => setCredentialModal(null)}
                  className="w-full py-3 bg-slate-800 text-white rounded-xl font-bold shadow-lg hover:bg-slate-700 transition-colors"
               >
                  Close & Continue
               </button>
            </div>
         </div>
      )}
    </div>
  );
};
