
import React, { useState, useMemo } from 'react';
import { Employee, LeaveRequest, TimeRequest, ExpenseRequest, LeaveStatus, TimeRequestStatus, ExpenseStatus, Role, LeaveType, ExpenseType, CompanySettings } from '../types';
import { Permissions } from '../utils/permissions';
import { CheckCircle, XCircle, Calendar, Clock, Lock, Info, CheckSquare, Square, AlertTriangle, Search, Filter, Mail, ChevronDown, DollarSign, Receipt, Users, ArrowRight, ShieldCheck } from 'lucide-react';

interface ApprovalWorkflowProps {
  employees: Employee[];
  leaves: LeaveRequest[];
  timeRequests: TimeRequest[];
  expenses: ExpenseRequest[];
  onLeaveAction: (id: string, status: LeaveStatus) => void;
  onTimeAction: (id: string, status: TimeRequestStatus) => void;
  onExpenseAction: (id: string, status: ExpenseStatus) => void;
  currentUser: Employee;
  companySettings?: CompanySettings; // New prop for RBAC
}

export const ApprovalWorkflow: React.FC<ApprovalWorkflowProps> = ({ 
  employees, leaves, timeRequests, expenses, onLeaveAction, onTimeAction, onExpenseAction, currentUser, companySettings 
}) => {
  const [activeTab, setActiveTab] = useState<'pending' | 'history'>('pending');
  const [filterType, setFilterType] = useState<'all' | 'leave' | 'ot' | 'expense'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Helper: Get Employee Details
  const getEmployee = (id: string) => employees.find(e => e.id === id);

  // Helper: Find Subordinates (Recursive Hierarchy)
  // This ensures Manager sees Direct Reports AND Indirect Reports
  const getSubordinateIds = (managerId: string): string[] => {
    const directReports = employees.filter(e => e.managerId === managerId);
    let allIds = directReports.map(e => e.id);
    
    directReports.forEach(report => {
      allIds = [...allIds, ...getSubordinateIds(report.id)];
    });
    
    return allIds;
  };

  // Permission Logic (Who can see what?)
  const canApprove = Permissions.canApproveRequests(currentUser.role, companySettings?.rolePermissions);
  const canViewAll = Permissions.canViewAllData(currentUser.role, companySettings?.rolePermissions);

  const visibleEmployeeIds = useMemo(() => {
     if (canViewAll) {
        return employees.map(e => e.id); // See All
     }
     if (currentUser.role === Role.MANAGER) {
        return getSubordinateIds(currentUser.id); // See Subordinates Only
     }
     return []; // Staff sees nothing here unless granted specific permissions
  }, [currentUser, employees, canViewAll]);

  // Combine Data into a unified "RequestItem" structure
  const allRequests = [
    ...leaves.map(l => ({ ...l, itemType: 'leave' as const, sortDate: l.startDate, reqStatus: l.status, requestTimestamp: l.startDate })),
    ...timeRequests.map(t => ({ ...t, itemType: 'ot' as const, sortDate: t.date, reqStatus: t.status, requestTimestamp: t.date })),
    ...expenses.map(e => ({ ...e, itemType: 'expense' as const, sortDate: e.date, reqStatus: e.status, requestTimestamp: e.date }))
  ].filter(item => visibleEmployeeIds.includes(item.employeeId));

  // Filtering Logic
  const filteredRequests = useMemo(() => {
    return allRequests.filter(item => {
      // Tab Filter
      const isPending = item.reqStatus === LeaveStatus.PENDING || item.reqStatus === TimeRequestStatus.PENDING || item.reqStatus === ExpenseStatus.PENDING;
      if (activeTab === 'pending' && !isPending) return false;
      if (activeTab === 'history' && isPending) return false;

      // Type Filter
      if (filterType !== 'all') {
        if (filterType === 'leave' && item.itemType !== 'leave') return false;
        if (filterType === 'ot' && item.itemType !== 'ot') return false;
        if (filterType === 'expense' && item.itemType !== 'expense') return false;
      }

      // Search Filter
      if (searchTerm) {
        const emp = getEmployee(item.employeeId);
        const fullName = `${emp?.firstName} ${emp?.lastName}`.toLowerCase();
        if (!fullName.includes(searchTerm.toLowerCase())) return false;
      }

      return true;
    }).sort((a, b) => new Date(b.sortDate).getTime() - new Date(a.sortDate).getTime());
  }, [allRequests, activeTab, filterType, searchTerm, employees]);

  // --- Bulk Action Logic ---
  const toggleSelection = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const handleSelectAll = () => {
    if (selectedIds.length === filteredRequests.length && filteredRequests.length > 0) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredRequests.map(r => r.id));
    }
  };

  const handleBulkAction = (action: 'approve' | 'reject') => {
    selectedIds.forEach(id => {
      const item = allRequests.find(r => r.id === id);
      if (item) {
        if (item.itemType === 'leave') {
           onLeaveAction(id, action === 'approve' ? LeaveStatus.APPROVED : LeaveStatus.REJECTED);
        } else if (item.itemType === 'ot') {
           onTimeAction(id, action === 'approve' ? TimeRequestStatus.APPROVED : TimeRequestStatus.REJECTED);
        } else if (item.itemType === 'expense') {
           onExpenseAction(id, action === 'approve' ? ExpenseStatus.APPROVED : ExpenseStatus.REJECTED);
        }
      }
    });
    setSelectedIds([]);
  };

  // --- Smart Context Helpers ---
  const getLeaveQuota = (type: string) => {
    // In a real app, this comes from settings or employee record
    if (type.includes('Sick')) return { used: 2, total: 30 };
    if (type.includes('Vacation')) return { used: 4, total: 10 };
    if (type.includes('Personal')) return { used: 1, total: 6 };
    return { used: 0, total: 0 };
  };

  const getConflictingLeaves = (startDate: string, endDate: string, currentEmpId: string) => {
    const conflicts = leaves.filter(l => 
      l.status === LeaveStatus.APPROVED && 
      l.startDate <= endDate && l.endDate >= startDate && // Overlap Check
      l.employeeId !== currentEmpId
    );
    return conflicts.map(c => {
        const e = getEmployee(c.employeeId);
        return { name: e ? e.firstName : 'Unknown', type: c.type };
    });
  };

  const getMonthlyOTHours = (empId: string) => {
      // Mock calculation based on approved time requests
      const seed = empId.charCodeAt(empId.length - 1);
      return (seed % 25) + 5; 
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB' }).format(amount);
  };

  const stats = {
    pending: allRequests.filter(i => i.reqStatus === LeaveStatus.PENDING || i.reqStatus === TimeRequestStatus.PENDING || i.reqStatus === ExpenseStatus.PENDING).length,
    approvedToday: allRequests.filter(i => i.reqStatus === LeaveStatus.APPROVED && i.sortDate === new Date().toISOString().split('T')[0]).length,
  };

  // Access Control Guard
  if (!canApprove) {
    return (
       <div className="flex flex-col items-center justify-center h-[60vh] text-slate-400 bg-white rounded-2xl shadow-sm border border-slate-100 p-8 text-center animate-fade-in">
         <div className="bg-slate-50 p-6 rounded-full mb-4">
            <Lock size={48} className="text-slate-300"/>
         </div>
         <h2 className="text-xl font-bold text-slate-700">Access Restricted</h2>
         <p className="text-sm mt-2 max-w-md text-slate-500">
            คุณไม่มีสิทธิ์เข้าถึงหน้านี้ (No Permission: Approve Requests)
            <br/>กรุณาติดต่อผู้ดูแลระบบหากต้องการสิทธิ์
         </p>
       </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in pb-24 font-sans relative">
      
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
           <div className="flex items-center gap-2 text-blue-600 text-sm font-bold mb-1 uppercase tracking-wider">
             <ShieldCheck size={16} /> Approval Center
           </div>
           <h2 className="text-3xl font-bold text-slate-800">รายการรออนุมัติ</h2>
           <p className="text-slate-500 mt-1">
             คุณมี <span className="font-bold text-amber-500">{stats.pending}</span> รายการที่ต้องตรวจสอบ (Context-Aware)
           </p>
        </div>
      </div>

      {/* Control Bar: Tabs, Search, Filters */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-sm sticky top-0 z-20 space-y-3 md:space-y-0 md:flex md:items-center md:justify-between gap-4">
         {/* Left: View Tabs */}
         <div className="flex bg-slate-100 rounded-xl p-1 shrink-0">
            <button 
              onClick={() => setActiveTab('pending')}
              className={`px-4 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'pending' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              รออนุมัติ {activeTab === 'pending' && <span className="bg-amber-500 text-white text-[10px] px-1.5 rounded-full">{stats.pending}</span>}
            </button>
            <button 
              onClick={() => setActiveTab('history')}
              className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'history' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              ประวัติย้อนหลัง
            </button>
         </div>

         {/* Right: Search & Filter */}
         <div className="flex items-center gap-2 flex-1 md:justify-end overflow-x-auto">
             <div className="relative group">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500" size={16} />
                <input 
                  type="text" 
                  placeholder="ค้นหาชื่อพนักงาน..." 
                  className="pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-[180px] focus:w-[240px] transition-all"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
               />
             </div>
             
             <div className="flex items-center bg-white border border-slate-200 rounded-xl p-1 h-[42px]">
                <button onClick={() => setFilterType('all')} className={`px-3 h-full rounded-lg text-xs font-bold transition-colors ${filterType === 'all' ? 'bg-slate-800 text-white' : 'text-slate-500 hover:bg-slate-50'}`}>All</button>
                <div className="w-px h-4 bg-slate-200 mx-1"></div>
                <button onClick={() => setFilterType('leave')} className={`px-3 h-full rounded-lg text-xs font-bold transition-colors ${filterType === 'leave' ? 'bg-purple-100 text-purple-700' : 'text-slate-500 hover:bg-slate-50'}`}>Leave</button>
                <button onClick={() => setFilterType('ot')} className={`px-3 h-full rounded-lg text-xs font-bold transition-colors ${filterType === 'ot' ? 'bg-orange-100 text-orange-700' : 'text-slate-500 hover:bg-slate-50'}`}>OT</button>
                <button onClick={() => setFilterType('expense')} className={`px-3 h-full rounded-lg text-xs font-bold transition-colors ${filterType === 'expense' ? 'bg-blue-100 text-blue-700' : 'text-slate-500 hover:bg-slate-50'}`}>Exp</button>
             </div>
         </div>
      </div>

      {activeTab === 'pending' && filteredRequests.length > 0 && (
        <div className="flex items-center gap-3 px-2">
           <button onClick={handleSelectAll} className="flex items-center gap-2 text-sm text-slate-600 hover:text-blue-600 font-bold transition-colors">
              {selectedIds.length === filteredRequests.length 
                ? <CheckSquare size={18} className="text-blue-600" /> 
                : <Square size={18} className="text-slate-400" />
              }
              เลือกทั้งหมด ({filteredRequests.length})
           </button>
           {selectedIds.length > 0 && (
             <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-bold animate-fade-in">
               เลือกแล้ว {selectedIds.length} รายการ
             </span>
           )}
        </div>
      )}

      {activeTab === 'pending' ? (
        /* PENDING VIEW CARD GRID */
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
           {filteredRequests.map((item) => {
              const emp = getEmployee(item.employeeId);
              const isLeave = item.itemType === 'leave';
              const isOT = item.itemType === 'ot';
              const isExpense = item.itemType === 'expense';
              
              const leaveItem = isLeave ? (item as LeaveRequest) : null;
              const timeItem = isOT ? (item as TimeRequest) : null;
              const expenseItem = isExpense ? (item as ExpenseRequest) : null;
              
              const quota = isLeave ? getLeaveQuota(leaveItem!.type) : null;
              const conflictingEmps = isLeave ? getConflictingLeaves(leaveItem!.startDate, leaveItem!.endDate, item.employeeId) : [];
              const otHours = isOT ? getMonthlyOTHours(item.employeeId) : 0;
              
              // Smart Warnings
              const isHighOT = isOT && otHours > 24;
              const isConflict = isLeave && conflictingEmps.length > 0;
              const isQuotaCritical = isLeave && quota && (quota.total - quota.used) < 2;
              
              const isSelected = selectedIds.includes(item.id);

              return (
                 <div 
                   key={item.id} 
                   className={`relative bg-white rounded-2xl p-0 border transition-all hover:shadow-lg cursor-pointer group flex flex-col md:flex-row overflow-hidden ${isSelected ? 'border-blue-500 ring-1 ring-blue-500' : 'border-slate-200'}`}
                   onClick={() => toggleSelection(item.id)}
                 >
                    {/* Checkbox Overlay */}
                    <div className="absolute top-4 left-4 z-10">
                       {isSelected 
                         ? <CheckSquare className="text-blue-600 bg-white rounded" size={20} /> 
                         : <Square className="text-slate-300 group-hover:text-slate-400 bg-white rounded transition-colors" size={20} />
                       }
                    </div>

                    {/* LEFT SIDE: Request Details */}
                    <div className="p-5 pl-12 flex-1 border-b md:border-b-0 md:border-r border-slate-100">
                        <div className="flex gap-4 mb-4">
                           <img src={emp?.avatarUrl} className="w-12 h-12 rounded-full object-cover border-2 border-slate-100" />
                           <div>
                              <h4 className="font-bold text-slate-800 text-base">{emp?.firstName} {emp?.lastName}</h4>
                              <p className="text-xs text-slate-500">{emp?.position} • {emp?.department}</p>
                           </div>
                        </div>

                        <div className="space-y-3">
                           {/* Type & Date */}
                           <div>
                              <div className={`text-sm font-bold flex items-center gap-2 ${isLeave ? 'text-purple-600' : isOT ? 'text-orange-600' : 'text-blue-600'}`}>
                                 {isLeave && <Calendar size={16}/>}
                                 {isOT && <Clock size={16}/>}
                                 {isExpense && <DollarSign size={16}/>}
                                 {isLeave ? leaveItem?.type : isOT ? timeItem?.type : expenseItem?.type}
                              </div>
                              <div className="text-xs font-medium text-slate-500 mt-1 pl-6">
                                 {isLeave 
                                    ? `${new Date(leaveItem!.startDate).toLocaleDateString('th-TH')} - ${new Date(leaveItem!.endDate).toLocaleDateString('th-TH')}`
                                    : new Date(item.sortDate).toLocaleDateString('th-TH')
                                 }
                                 {isOT && ` (${timeItem?.startTime} - ${timeItem?.endTime})`}
                              </div>
                           </div>

                           {/* Amount (Expense) */}
                           {isExpense && (
                              <div className="text-xl font-bold text-slate-800 font-mono pl-6">
                                 {formatCurrency(expenseItem?.amount || 0)}
                              </div>
                           )}

                           {/* Reason */}
                           <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 text-sm text-slate-600 italic">
                              "{isExpense ? expenseItem?.description : item.reason || 'No description provided'}"
                           </div>
                        </div>
                    </div>

                    {/* RIGHT SIDE: Smart Context & Actions */}
                    <div className="w-full md:w-64 bg-slate-50 p-5 flex flex-col justify-between">
                        
                        {/* Context Area */}
                        <div className="space-y-3 mb-4">
                           <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Smart Context</div>
                           
                           {isLeave && quota && (
                              <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                                 <div className="flex justify-between text-xs mb-1">
                                    <span className="text-slate-500">Quota Used</span>
                                    <span className="font-bold text-slate-700">{quota.used} / {quota.total}</span>
                                 </div>
                                 <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                    <div className={`h-full rounded-full ${isQuotaCritical ? 'bg-red-500' : 'bg-green-500'}`} style={{width: `${(quota.used/quota.total)*100}%`}}></div>
                                 </div>
                              </div>
                           )}

                           {isConflict && (
                              <div className="bg-red-50 p-3 rounded-xl border border-red-100 text-xs text-red-700">
                                 <div className="font-bold flex items-center gap-1 mb-1"><Users size={12}/> Team Conflict</div>
                                 {conflictingEmps.map((c, i) => (
                                    <div key={i} className="truncate">- {c.name} ({c.type})</div>
                                 ))}
                              </div>
                           )}

                           {isHighOT && (
                              <div className="bg-amber-50 p-3 rounded-xl border border-amber-100 text-xs text-amber-700">
                                 <div className="font-bold flex items-center gap-1 mb-1"><AlertTriangle size={12}/> High OT Alert</div>
                                 Accumulated: {otHours} hrs
                              </div>
                           )}

                           {isExpense && (
                              <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm text-center">
                                 {expenseItem?.receiptUrl ? (
                                    <a href={expenseItem.receiptUrl} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()} className="flex flex-col items-center gap-1 text-blue-600 hover:underline">
                                       <Receipt size={24} />
                                       <span className="text-xs font-bold">View Receipt</span>
                                    </a>
                                 ) : (
                                    <span className="text-xs text-slate-400 italic">No receipt attached</span>
                                 )}
                              </div>
                           )}

                           {!isConflict && !isHighOT && (isLeave || isOT) && (
                              <div className="flex items-center gap-1 text-[10px] text-green-600 bg-green-50 px-2 py-1 rounded border border-green-100">
                                 <CheckCircle size={10} /> Ready to Approve
                              </div>
                           )}
                        </div>

                        {/* Action Buttons */}
                        <div className="flex gap-2 mt-auto pt-4 border-t border-slate-100">
                           <button 
                              onClick={(e) => { e.stopPropagation(); if(isLeave) onLeaveAction(item.id, LeaveStatus.REJECTED); else if(isOT) onTimeAction(item.id, TimeRequestStatus.REJECTED); else onExpenseAction(item.id, ExpenseStatus.REJECTED); }}
                              className="flex-1 py-2 bg-white border border-slate-200 text-slate-500 rounded-lg text-xs font-bold hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-colors"
                           >
                              Reject
                           </button>
                           <button 
                              onClick={(e) => { e.stopPropagation(); if(isLeave) onLeaveAction(item.id, LeaveStatus.APPROVED); else if(isOT) onTimeAction(item.id, TimeRequestStatus.APPROVED); else onExpenseAction(item.id, ExpenseStatus.APPROVED); }}
                              className="flex-1 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700 shadow-md transition-colors"
                           >
                              Approve
                           </button>
                        </div>
                    </div>
                 </div>
              );
           })}
           
           {filteredRequests.length === 0 && (
              <div className="col-span-full flex flex-col items-center justify-center py-20 text-slate-400 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                 <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mb-4 shadow-sm">
                    <CheckSquare size={32} className="opacity-20" />
                 </div>
                 <p className="text-sm font-medium">ไม่พบรายการรออนุมัติ</p>
                 <p className="text-xs mt-1">รายการที่ดำเนินการแล้วจะอยู่ในประวัติย้อนหลัง</p>
              </div>
           )}
        </div>
      ) : (
        /* HISTORY TAB */
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
           <div className="overflow-x-auto">
              <table className="w-full text-left">
                 <thead className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase">
                    <tr>
                       <th className="px-6 py-4">Request Date</th>
                       <th className="px-6 py-4">Employee</th>
                       <th className="px-6 py-4">Type</th>
                       <th className="px-6 py-4">Details</th>
                       <th className="px-6 py-4 text-center">Status</th>
                    </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-100 text-sm">
                    {filteredRequests.map((item) => {
                       const emp = getEmployee(item.employeeId);
                       const isExpense = item.itemType === 'expense';
                       return (
                          <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                             <td className="px-6 py-4 text-slate-500">
                                {new Date(item.requestTimestamp).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: '2-digit' })}
                             </td>
                             <td className="px-6 py-4 font-bold text-slate-700">
                                {emp?.firstName} {emp?.lastName}
                             </td>
                             <td className="px-6 py-4">
                                <span className={`text-xs font-bold px-2 py-1 rounded border ${
                                   item.itemType === 'leave' ? 'bg-purple-50 text-purple-700 border-purple-100' :
                                   item.itemType === 'ot' ? 'bg-orange-50 text-orange-700 border-orange-100' :
                                   'bg-blue-50 text-blue-700 border-blue-100'
                                }`}>
                                   {item.itemType === 'leave' ? (item as LeaveRequest).type : item.itemType === 'ot' ? (item as TimeRequest).type : (item as ExpenseRequest).type}
                                </span>
                             </td>
                             <td className="px-6 py-4 text-slate-600 max-w-xs truncate">
                                {isExpense ? `${formatCurrency((item as ExpenseRequest).amount)} - ` : ''}
                                {item.reason || (item as ExpenseRequest).description}
                             </td>
                             <td className="px-6 py-4 text-center">
                                <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-bold ${
                                   item.reqStatus.includes('Approve') || item.reqStatus === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                                }`}>
                                   {item.reqStatus.includes('Approve') || item.reqStatus === 'Paid' ? <CheckCircle size={12}/> : <XCircle size={12}/>}
                                   {item.reqStatus}
                                </span>
                             </td>
                          </tr>
                       );
                    })}
                    {filteredRequests.length === 0 && (
                       <tr>
                          <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                             ไม่พบประวัติรายการ
                          </td>
                       </tr>
                    )}
                 </tbody>
              </table>
           </div>
        </div>
      )}
    </div>
  );
};
