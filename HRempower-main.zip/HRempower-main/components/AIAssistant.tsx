
import React, { useState, useRef, useEffect } from 'react';
import { generateHRContent } from '../services/geminiService';
import { ChatMessage, KnowledgeItem, Employee, Role, CompanySettings } from '../types';
import { Send, Bot, User, Sparkles, Copy, Check, RotateCcw, Lightbulb, FileText, Scale, MessageSquare, Info, BookOpen, Plus, Search, Edit3, Trash2 } from 'lucide-react';

interface AIAssistantProps {
  knowledgeBase?: KnowledgeItem[];
  companySettings?: CompanySettings;
  onAddKnowledge?: (item: KnowledgeItem) => void;
  onUpdateKnowledge?: (item: KnowledgeItem) => void;
  onDeleteKnowledge?: (id: string) => void;
  currentUser?: Employee;
}

export const AIAssistant: React.FC<AIAssistantProps> = ({ knowledgeBase = [], companySettings, onAddKnowledge, onUpdateKnowledge, onDeleteKnowledge, currentUser }) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'knowledge'>('chat');
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: 'สวัสดีครับ ผมคือ EmpowerHR AI ผู้ช่วยอัจฉริยะประจำองค์กร \n\nสอบถามเรื่องสวัสดิการ, โบนัส, วันลา หรือให้ผมช่วยร่างเอกสารได้เลยครับ',
      timestamp: new Date()
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Knowledge Base State
  const [kbSearch, setKbSearch] = useState('');
  const [showKbModal, setShowKbModal] = useState(false);
  const [modalMode, setModalMode] = useState<'add' | 'edit'>('add');
  const [editingItem, setEditingItem] = useState<Partial<KnowledgeItem>>({ category: 'General' });

  // Update permission: Include SUPER_ADMIN
  const isHR = currentUser?.role === Role.HR_MANAGER || currentUser?.role === Role.HR_STAFF || currentUser?.role === Role.CEO || currentUser?.role === Role.SUPER_ADMIN;

  // Suggestions based on Role
  const staffSuggestions = [
     { label: "สิทธิรักษาพยาบาล", icon: <Scale size={14}/>, prompt: "ขอทราบรายละเอียดสวัสดิการค่ารักษาพยาบาลของบริษัทครับ วงเงินเท่าไหร่?" },
     { label: "เงื่อนไขโบนัส", icon: <Sparkles size={14}/>, prompt: "บริษัทมีเกณฑ์การจ่ายโบนัสประจำปีอย่างไรบ้าง?" },
     { label: "ระเบียบการลากิจ", icon: <FileText size={14}/>, prompt: "ถ้าจะลากิจต้องแจ้งล่วงหน้ากี่วัน และใช้สิทธิได้ปีละกี่วัน?" },
     { label: "เวลาเข้างาน", icon: <ClockIcon size={14}/>, prompt: "เวลาเข้างานปกติคือช่วงกี่โมง และสายได้กี่นาทีครับ?" },
  ];

  const hrSuggestions = [
    { label: "ร่างสัญญาจ้าง", icon: <FileText size={14}/>, prompt: "ช่วยร่างสัญญาจ้างงานสำหรับตำแหน่ง Marketing Manager แบบสัญญาปีต่อปี" },
    { label: "กฎหมายเลิกจ้าง", icon: <Scale size={14}/>, prompt: "สรุปกฎหมายแรงงานเรื่องการเลิกจ้างและการจ่ายค่าชดเชยกรณีต่างๆ" },
    { label: "ประกาศวันหยุด", icon: <CalendarIcon size={14}/>, prompt: "ร่างประกาศวันหยุดประจำปีของบริษัท ให้ดูเป็นทางการ" },
  ];

  const suggestions = isHR ? hrSuggestions : staffSuggestions;

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // --- Context Builder ---
  const buildContext = () => {
     let context = ``;

     // 1. Company Policies (From Real Settings)
     if (companySettings) {
        context += `[ข้อมูลพื้นฐานบริษัท]\n`;
        context += `- ชื่อบริษัท: ${companySettings.name} (${companySettings.nameEn || ''})\n`;
        context += `- เวลาทำงานปกติ: ${companySettings.workStartTime} ถึง ${companySettings.workEndTime}\n`;
        context += `- วันทำงาน: ${companySettings.workDays.join(', ')}\n`;
        context += `- การอนุโลมสาย (Late Threshold): สายได้ไม่เกิน ${companySettings.lateThresholdMinutes} นาที\n`;
        
        context += `\n[วันหยุดประจำปี (Holidays)]\n`;
        context += companySettings.publicHolidays.map(h => `- ${h.name} (${new Date(h.date).toLocaleDateString('th-TH')})`).join('\n') + '\n';

        context += `\n[สิทธิ์วันลา (Leave Quotas)]\n`;
        context += companySettings.leaveQuotas.map(q => `- ${q.type}: ${q.quota} วัน/ปี`).join('\n') + '\n';
     }

     // 2. Knowledge Base
     context += `\n[ฐานข้อมูลความรู้ (Knowledge Base)]\n`;
     context += knowledgeBase.map(k => `[หัวข้อ: ${k.title}] (${k.category}): ${k.content}`).join('\n\n') + '\n';

     // 3. Security Guardrails (Based on Role)
     const isAuthorizedForPayroll = [Role.SUPER_ADMIN, Role.CEO, Role.HR_MANAGER].includes(currentUser?.role || Role.STAFF);
     
     context += `\n[คำสั่งความปลอดภัย (Security Instruction)]\n`;
     if (isAuthorizedForPayroll) {
        context += `- ผู้ใช้งานนี้คือ "ผู้บริหาร/HR" (Authorized Role: ${currentUser?.role}).\n`;
        context += `- คุณสามารถตอบคำถามเกี่ยวกับโครงสร้างเงินเดือน, นโยบายการบริหารค่าตอบแทน, หรือข้อมูลสรุปภาพรวมได้ หากข้อมูลมีอยู่ใน Context.\n`;
        context += `- อย่างไรก็ตาม ห้ามเปิดเผยเงินเดือนของพนักงานรายบุคคลแบบเจาะจง (Specific Salary) หากไม่ได้ถูกถามเพื่อการคำนวณ.\n`;
     } else {
        context += `- ผู้ใช้งานนี้คือ "พนักงานทั่วไป" (General Staff/Manager).\n`;
        context += `- ห้าม! (FORBIDDEN): เปิดเผยข้อมูลเงินเดือน, โบนัสที่เป็นตัวเลขเจาะจงของผู้อื่น, หรือข้อมูล Payroll ของบริษัทเด็ดขาด.\n`;
        context += `- หากถูกถามเรื่องเงินเดือนของตนเอง ให้แนะนำอย่างสุภาพว่า "กรุณาตรวจสอบรายละเอียดในเมนู Payroll (เงินเดือน) เพื่อความถูกต้องและความเป็นส่วนตัวครับ"\n`;
        context += `- ตอบเฉพาะเรื่องนโยบายทั่วไป, สวัสดิการ, วันลา, และกฎระเบียบเท่านั้น.\n`;
     }

     return context;
  };

  const handleSend = async (textOverride?: string) => {
    const textToSend = textOverride || input;
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: textToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);
    
    if (textareaRef.current) textareaRef.current.style.height = 'auto';

    try {
      // Build Dynamic Context
      const contextString = buildContext();
      
      const aiResponseText = await generateHRContent(textToSend, contextString);
      
      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: aiResponseText,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMsg]);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const autoResize = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    e.target.style.height = 'auto';
    e.target.style.height = e.target.scrollHeight + 'px';
    setInput(e.target.value);
  };

  const handleOpenAddModal = () => {
    setModalMode('add');
    setEditingItem({ category: 'General', title: '', content: '' });
    setShowKbModal(true);
  };

  const handleOpenEditModal = (item: KnowledgeItem) => {
    setModalMode('edit');
    setEditingItem({ ...item });
    setShowKbModal(true);
  };

  const handleDeleteItem = (id: string) => {
    if (confirm('คุณต้องการลบข้อมูลนี้ใช่หรือไม่?')) {
      if(onDeleteKnowledge) onDeleteKnowledge(id);
    }
  };

  const handleSaveKb = (e: React.FormEvent) => {
     e.preventDefault();
     if(editingItem.title && editingItem.content) {
        if (modalMode === 'add' && onAddKnowledge) {
            onAddKnowledge({
               id: `KB${Date.now()}`,
               title: editingItem.title,
               content: editingItem.content,
               category: editingItem.category as any || 'General',
               lastUpdated: new Date().toISOString().split('T')[0],
               orgId: currentUser?.orgId || ''
            });
        } else if (modalMode === 'edit' && onUpdateKnowledge && editingItem.id) {
            onUpdateKnowledge({
               ...editingItem as KnowledgeItem,
               lastUpdated: new Date().toISOString().split('T')[0]
            });
        }
        setShowKbModal(false);
     }
  };

  return (
    <div className="h-[calc(100vh-140px)] flex flex-col gap-4 animate-fade-in">
       
       {/* Top Bar for HR to Switch Modes */}
       {isHR && (
         <div className="flex bg-white p-1 rounded-xl shadow-sm border border-slate-200 self-start">
            <button 
               onClick={() => setActiveTab('chat')} 
               className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-colors ${activeTab === 'chat' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:bg-slate-50'}`}
            >
               <MessageSquare size={16} /> แชท (Chat)
            </button>
            <button 
               onClick={() => setActiveTab('knowledge')} 
               className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-colors ${activeTab === 'knowledge' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:bg-slate-50'}`}
            >
               <BookOpen size={16} /> ฐานข้อมูล (Knowledge Base)
            </button>
         </div>
       )}

      {/* Main Content Area */}
      {activeTab === 'chat' ? (
         <div className="flex-1 flex flex-col bg-white rounded-3xl shadow-soft border border-slate-100 overflow-hidden relative">
            {/* Header */}
            <div className="p-5 border-b border-slate-100 bg-white/80 backdrop-blur-md sticky top-0 z-10 flex items-center justify-between">
               <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
                     <Bot size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-lg leading-tight">EmpowerHR AI <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full ml-1 align-middle">Beta</span></h3>
                    <p className="text-xs text-slate-500">ตอบคำถามจากฐานข้อมูลบริษัท & กฎหมายแรงงาน</p>
                  </div>
               </div>
               <button 
                 onClick={() => setMessages([messages[0]])} 
                 className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-full transition-colors"
                 title="เริ่มบทสนทนาใหม่"
               >
                 <RotateCcw size={20} />
               </button>
            </div>

            {/* Chat Content */}
            <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 bg-slate-50/50 scroll-smooth">
              {messages.map((msg, index) => (
                <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'} group`}>
                  <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center shadow-sm mt-1 ${
                    msg.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-white text-indigo-600 border border-indigo-100'
                  }`}>
                    {msg.role === 'user' ? <User size={16} /> : <Sparkles size={16} />}
                  </div>

                  <div className={`relative max-w-[85%] md:max-w-[75%] rounded-2xl px-5 py-4 shadow-sm text-sm leading-7 ${
                    msg.role === 'user' 
                      ? 'bg-indigo-600 text-white rounded-tr-none' 
                      : 'bg-white text-slate-700 border border-slate-200 rounded-tl-none'
                  }`}>
                    <div className="whitespace-pre-wrap font-medium">{msg.text}</div>
                    
                    <div className={`flex items-center gap-2 mt-2 text-[10px] ${msg.role === 'user' ? 'text-indigo-200 justify-end' : 'text-slate-400'}`}>
                      <span>{msg.timestamp.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })}</span>
                      {msg.role === 'model' && (
                        <button 
                          onClick={() => copyToClipboard(msg.text, msg.id)}
                          className="ml-2 flex items-center gap-1 hover:text-indigo-600 transition-colors opacity-0 group-hover:opacity-100"
                        >
                          {copiedId === msg.id ? <Check size={12}/> : <Copy size={12}/>}
                          {copiedId === msg.id ? 'Copied' : 'Copy'}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}

              {isLoading && (
                 <div className="flex gap-4">
                   <div className="w-8 h-8 rounded-full bg-white text-indigo-600 border border-indigo-100 flex items-center justify-center mt-1">
                     <Sparkles size={16} />
                   </div>
                   <div className="bg-white px-5 py-4 rounded-2xl rounded-tl-none border border-slate-200 shadow-sm flex items-center gap-2">
                     <span className="text-sm text-slate-500 font-medium">กำลังค้นหาข้อมูล...</span>
                     <div className="flex gap-1">
                        <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce"></div>
                        <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce delay-75"></div>
                        <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce delay-150"></div>
                     </div>
                   </div>
                 </div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* Input Area */}
            <div className="p-5 bg-white border-t border-slate-100">
              {messages.length === 1 && (
                 <div className="mb-4 flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
                    {suggestions.map((s, idx) => (
                       <button 
                         key={idx}
                         onClick={() => handleSend(s.prompt)}
                         className="flex-shrink-0 flex items-center gap-2 px-3 py-2 bg-slate-50 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-200 rounded-lg text-xs font-bold text-slate-600 hover:text-indigo-700 transition-all whitespace-nowrap"
                       >
                          {s.icon} {s.label}
                       </button>
                    ))}
                 </div>
              )}
              
              <div className="relative flex items-end gap-2 bg-slate-50 p-2 rounded-2xl border border-slate-200 focus-within:ring-2 focus-within:ring-indigo-500 focus-within:border-transparent transition-all shadow-inner">
                <textarea
                  ref={textareaRef}
                  rows={1}
                  value={input}
                  onChange={autoResize}
                  onKeyDown={handleKeyDown}
                  placeholder={isHR ? "ถามคำถามหรือสั่งร่างเอกสาร HR..." : "ถามเกี่ยวกับสวัสดิการ โบนัส หรือกฎระเบียบ..."}
                  className="w-full bg-transparent border-none focus:ring-0 text-slate-700 text-sm py-3 px-2 resize-none max-h-32"
                />
                <button 
                  onClick={() => handleSend()}
                  disabled={!input.trim() || isLoading}
                  className="p-3 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-md active:scale-95 mb-0.5"
                >
                  <Send size={18} />
                </button>
              </div>
              <p className="text-center text-[10px] text-slate-400 mt-3 flex items-center justify-center gap-1">
                 <Info size={10} /> AI ตอบคำถามโดยอ้างอิงจากฐานข้อมูลบริษัท (Knowledge Base) และนโยบายปัจจุบัน
              </p>
            </div>
         </div>
      ) : (
         // Knowledge Base View (HR Only)
         <div className="flex-1 bg-white rounded-3xl shadow-soft border border-slate-100 p-6 overflow-hidden flex flex-col">
            <div className="flex justify-between items-center mb-6">
               <div>
                  <h3 className="text-xl font-bold text-slate-800">ฐานข้อมูลความรู้ (Knowledge Base)</h3>
                  <p className="text-sm text-slate-500">เพิ่มข้อมูลกฎระเบียบ นโยบาย เพื่อให้ AI ตอบคำถามพนักงานได้ถูกต้อง</p>
               </div>
               <button 
                  onClick={handleOpenAddModal}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-lg shadow-indigo-200 flex items-center gap-2"
               >
                  <Plus size={18} /> เพิ่มข้อมูล
               </button>
            </div>

            {/* Search KB */}
            <div className="relative mb-6">
               <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
               <input 
                  type="text" 
                  placeholder="ค้นหานโยบาย หรือกฎระเบียบ..." 
                  value={kbSearch}
                  onChange={e => setKbSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
               />
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto space-y-4 custom-scrollbar">
               {knowledgeBase
                  .filter(k => k.title.toLowerCase().includes(kbSearch.toLowerCase()) || k.content.toLowerCase().includes(kbSearch.toLowerCase()))
                  .map(item => (
                  <div key={item.id} className="bg-slate-50 border border-slate-200 rounded-xl p-5 hover:border-indigo-300 transition-colors group">
                     <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                           <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wide border ${
                              item.category === 'Benefit' ? 'bg-green-100 text-green-700 border-green-200' :
                              item.category === 'Bonus' ? 'bg-amber-100 text-amber-700 border-amber-200' :
                              'bg-slate-200 text-slate-600 border-slate-300'
                           }`}>
                              {item.category}
                           </span>
                           <h4 className="font-bold text-slate-800">{item.title}</h4>
                        </div>
                        <div className="flex gap-2">
                           <button onClick={() => handleOpenEditModal(item)} className="p-1.5 text-slate-400 hover:text-indigo-600 bg-white rounded-lg shadow-sm border border-slate-200"><Edit3 size={14} /></button>
                           <button onClick={() => handleDeleteItem(item.id)} className="p-1.5 text-slate-400 hover:text-red-600 bg-white rounded-lg shadow-sm border border-slate-200"><Trash2 size={14} /></button>
                        </div>
                     </div>
                     <p className="text-sm text-slate-600 leading-relaxed mb-3">{item.content}</p>
                     <p className="text-[10px] text-slate-400 flex items-center gap-1">
                        <ClockIcon size={10} /> อัปเดตล่าสุด: {new Date(item.lastUpdated).toLocaleDateString('th-TH')}
                     </p>
                  </div>
               ))}
               {knowledgeBase.length === 0 && (
                  <div className="text-center py-10 text-slate-400">
                     <BookOpen size={48} className="mx-auto mb-2 opacity-20" />
                     <p>ยังไม่มีข้อมูลในฐานความรู้</p>
                  </div>
               )}
            </div>
         </div>
      )}

      {/* Add/Edit Knowledge Modal */}
      {showKbModal && (
         <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-6 animate-fade-in-up">
               <h3 className="text-xl font-bold mb-4">{modalMode === 'add' ? 'เพิ่มข้อมูลใหม่' : 'แก้ไขข้อมูล'}</h3>
               <form onSubmit={handleSaveKb} className="space-y-4">
                  <div>
                     <label className="block text-xs font-bold text-slate-500 mb-1">หัวข้อ (Title)</label>
                     <input required type="text" className="w-full border rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="เช่น นโยบายโบนัส 2024" value={editingItem.title || ''} onChange={e => setEditingItem({...editingItem, title: e.target.value})} />
                  </div>
                  <div>
                     <label className="block text-xs font-bold text-slate-500 mb-1">หมวดหมู่</label>
                     <select className="w-full border rounded-xl p-3 text-sm" value={editingItem.category} onChange={e => setEditingItem({...editingItem, category: e.target.value as any})}>
                        <option value="Policy">นโยบาย (Policy)</option>
                        <option value="Benefit">สวัสดิการ (Benefit)</option>
                        <option value="Bonus">โบนัส/เงินเดือน (Bonus/Salary)</option>
                        <option value="General">ทั่วไป (General)</option>
                     </select>
                  </div>
                  <div>
                     <label className="block text-xs font-bold text-slate-500 mb-1">เนื้อหา (Content)</label>
                     <textarea required className="w-full border rounded-xl p-3 text-sm h-32 focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="ระบุรายละเอียด..." value={editingItem.content || ''} onChange={e => setEditingItem({...editingItem, content: e.target.value})}></textarea>
                     <p className="text-[10px] text-slate-400 mt-1">* ข้อมูลนี้จะถูกนำไปใช้เป็น Context ให้ AI ตอบคำถามพนักงาน</p>
                  </div>
                  <div className="flex justify-end gap-3 mt-6">
                     <button type="button" onClick={() => setShowKbModal(false)} className="px-4 py-2 text-slate-500 hover:bg-slate-50 rounded-xl font-bold text-sm">ยกเลิก</button>
                     <button type="submit" className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 shadow-lg">บันทึกข้อมูล</button>
                  </div>
               </form>
            </div>
         </div>
      )}
    </div>
  );
};

// Simple Icon Wrappers
const TrendingUpIcon = ({size}: {size: number}) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>;
const CalendarIcon = ({size}: {size: number}) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>;
const ClockIcon = ({size}: {size: number}) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>;
