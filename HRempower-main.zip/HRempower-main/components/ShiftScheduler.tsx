
import React, { useState, useEffect } from 'react';
import { Employee, Shift, ShiftAssignment, Department, LeaveRequest, LeaveStatus, AttendanceRecord, CompanySettings } from '../types';
import { ChevronLeft, ChevronRight, Calendar, Filter, Wand2, Eraser, AlertCircle, Check, X, MousePointer2, Plus, Clock, Monitor, LayoutGrid, Trash2, Settings, Save } from 'lucide-react';

interface ShiftSchedulerProps {
  employees: Employee[];
  shifts: Shift[];
  assignments: ShiftAssignment[];
  leaves?: LeaveRequest[];
  attendance?: AttendanceRecord[];
  companySettings?: CompanySettings;
  onAssignShift: (employeeId: string, date: string, shiftId: string) => void;
  onAddShift?: (shift: Shift) => void;
  onDeleteShift?: (shiftId: string) => void;
}

export const ShiftScheduler: React.FC<ShiftSchedulerProps> = ({ 
  employees, shifts, assignments, leaves = [], attendance = [], companySettings, onAssignShift, onAddShift, onDeleteShift
}) => {
  const [activeTab, setActiveTab] = useState<'scheduler' | 'live'>('scheduler');
  const [viewMode, setViewMode] = useState<'week' | 'month'>('week');
  
  // Date State
  const [focusDate, setFocusDate] = useState(new Date()); // Current focus for nav
  
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [selectedTool, setSelectedTool] = useState<string>('pointer');
  
  // Pattern Modal State
  const [showPatternModal, setShowPatternModal] = useState(false);
  const [patternSequence, setPatternSequence] = useState<string[]>([]);
  
  // Shift Management Modal State
  const [showShiftModal, setShowShiftModal] = useState(false);
  const [newShift, setNewShift] = useState<Partial<Shift>>({ name: '', code: '', startTime: '09:00', endTime: '18:00', colorClass: 'bg-blue-100 text-blue-800 border-blue-200' });

  // Real-time ticking for Live Monitor
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 60000); // Update every minute
    return () => clearInterval(timer);
  }, []);

  // --- Date Logic ---
  const handleDateChange = (direction: 'prev' | 'next') => {
    const newDate = new Date(focusDate);
    if (viewMode === 'week') {
       newDate.setDate(newDate.getDate() + (direction === 'next' ? 7 : -7));
    } else {
       newDate.setMonth(newDate.getMonth() + (direction === 'next' ? 1 : -1));
    }
    setFocusDate(newDate);
  };

  const handleYearChange = (year: number) => {
     const newDate = new Date(focusDate);
     newDate.setFullYear(year);
     setFocusDate(newDate);
  };

  const handleMonthChange = (monthIndex: number) => {
     const newDate = new Date(focusDate);
     newDate.setMonth(monthIndex);
     setFocusDate(newDate);
  };

  const getDaysToRender = () => {
    const days = [];
    if (viewMode === 'week') {
       // Start of week (Monday)
       const d = new Date(focusDate);
       const day = d.getDay();
       const diff = d.getDate() - day + (day === 0 ? -6 : 1);
       const startOfWeek = new Date(d.setDate(diff));
       
       for (let i = 0; i < 7; i++) {
          const temp = new Date(startOfWeek);
          temp.setDate(temp.getDate() + i);
          days.push(temp);
       }
    } else {
       // All days in Month
       const year = focusDate.getFullYear();
       const month = focusDate.getMonth();
       const date = new Date(year, month, 1);
       while (date.getMonth() === month) {
          days.push(new Date(date));
          date.setDate(date.getDate() + 1);
       }
    }
    return days;
  };

  const daysToRender = getDaysToRender();

  // --- Shift Helpers ---
  const getShiftForEmployee = (employeeId: string, date: string) => {
    return assignments.find(a => a.employeeId === employeeId && a.date === date);
  };

  const getShiftDetails = (shiftId: string) => {
    return shifts.find(s => s.id === shiftId) || shifts.find(s => s.id === 'OFF');
  };

  // --- Create/Delete Shift Handlers ---
  const handleSaveNewShift = () => {
     if (newShift.name && newShift.code && onAddShift) {
        onAddShift({
           id: `S${Date.now()}`,
           name: newShift.name,
           code: newShift.code,
           startTime: newShift.startTime || '00:00',
           endTime: newShift.endTime || '00:00',
           colorClass: newShift.colorClass || 'bg-slate-100'
        });
        setNewShift({ name: '', code: '', startTime: '09:00', endTime: '18:00', colorClass: 'bg-blue-100 text-blue-800 border-blue-200' });
        setShowShiftModal(false);
     }
  };

  // --- Time Engine Logic (Same as before) ---
  const calculateTimeStatus = (empId: string, shift: Shift | undefined, dateStr: string) => {
    const record = attendance.find(a => a.employeeId === empId && a.date === dateStr);
    const isToday = dateStr === now.toISOString().split('T')[0];
    let status: 'Normal' | 'Late' | 'Absent' | 'EarlyLeave' | 'OT' | 'NoShow' | 'Pending' = 'Pending';
    let detail = '';
    let color = 'bg-slate-100 text-slate-500';

    if (!shift || shift.code === 'OFF') return { status: 'Normal', detail: 'Off Day', color: 'bg-slate-50 text-slate-400' };

    if (!record) {
      if (isToday) {
        const [shH, shM] = shift.startTime.split(':').map(Number);
        const shiftStart = new Date(now); shiftStart.setHours(shH, shM, 0, 0);
        if (now.getTime() > shiftStart.getTime() + (60 * 60 * 1000)) return { status: 'NoShow', detail: 'Missing Check-in', color: 'bg-red-100 text-red-700 border-red-200' };
        return { status: 'Pending', detail: 'Waiting...', color: 'bg-slate-100 text-slate-500' };
      }
      return { status: 'Absent', detail: 'Absent', color: 'bg-red-100 text-red-700' };
    }

    if (record.checkIn) {
      const checkInTime = new Date(record.checkIn);
      const [shH, shM] = shift.startTime.split(':').map(Number);
      const shiftStart = new Date(checkInTime); shiftStart.setHours(shH, shM, 0, 0);
      const thresholdMinutes = companySettings?.lateThresholdMinutes || 0;
      const lateLimit = new Date(shiftStart.getTime() + thresholdMinutes * 60000);

      if (checkInTime > lateLimit) {
        const diffMs = checkInTime.getTime() - shiftStart.getTime();
        const diffMins = Math.floor(diffMs / 60000);
        status = 'Late'; detail = `Late ${diffMins}m`; color = diffMins > 30 ? 'bg-red-100 text-red-700 border-red-200' : 'bg-amber-100 text-amber-700 border-amber-200';
      } else {
        status = 'Normal'; detail = 'On Time'; color = 'bg-green-100 text-green-700 border-green-200';
      }
    }
    return { status, detail, color };
  };

  const getConflict = (employeeId: string, date: string) => {
    const approvedLeave = leaves.find(l => l.employeeId === employeeId && l.status === LeaveStatus.APPROVED && l.startDate <= date && l.endDate >= date);
    if (approvedLeave) return { type: 'leave', message: `On Leave: ${approvedLeave.type}` };
    return null;
  };

  const handleCellClick = (employeeId: string, date: string, currentShiftId?: string) => {
    if (selectedTool === 'pointer') {
      const shiftIds = shifts.map(s => s.id);
      const currentIndex = currentShiftId ? shiftIds.indexOf(currentShiftId) : -1;
      const nextIndex = (currentIndex + 1) % shiftIds.length;
      onAssignShift(employeeId, date, shiftIds[nextIndex]);
    } else if (selectedTool === 'eraser') {
      onAssignShift(employeeId, date, 'CLEAR'); // CHANGED: Send CLEAR instead of OFF
    } else {
      onAssignShift(employeeId, date, selectedTool);
    }
  };

  // --- Pattern Logic ---
  const handleAddToPattern = (shiftId: string) => setPatternSequence(prev => [...prev, shiftId]);
  const handleApplyPattern = () => {
    if (patternSequence.length === 0) return;
    filteredEmployees.forEach(emp => {
      daysToRender.forEach((day, index) => {
        const patternIndex = index % patternSequence.length;
        onAssignShift(emp.id, day.toISOString().split('T')[0], patternSequence[patternIndex]);
      });
    });
    setShowPatternModal(false); setPatternSequence([]);
  };

  const filteredEmployees = selectedDept === 'All' ? employees : employees.filter(e => e.department === selectedDept);

  // --- Live Monitor Logic (Same as before) ---
  const todayStr = now.toISOString().split('T')[0];
  const liveStats = { totalScheduled: 0, present: 0, late: 0, absent: 0 };
  const liveData = filteredEmployees.map(emp => {
    const assign = getShiftForEmployee(emp.id, todayStr);
    const shift = assign ? getShiftDetails(assign.shiftId) : null;
    const { status, detail, color } = calculateTimeStatus(emp.id, shift, todayStr);
    const record = attendance.find(a => a.employeeId === emp.id && a.date === todayStr);
    if (shift && shift.code !== 'OFF') {
      liveStats.totalScheduled++;
      if (status === 'Normal') liveStats.present++;
      if (status === 'Late') liveStats.late++;
      if (status === 'NoShow' || status === 'Absent') liveStats.absent++;
    }
    return { emp, shift, status, detail, color, record };
  }).filter(item => item.shift && item.shift.code !== 'OFF');

  return (
    <div className="space-y-6 animate-fade-in relative pb-10">
      
      {/* Header & Controls */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-end gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Smart Workforce Management</h2>
          <p className="text-slate-500">บริหารจัดการกะงานและติดตามเวลาแบบ Real-time</p>
        </div>
        
        {/* Module Toggle */}
        <div className="bg-slate-100 p-1 rounded-xl flex shadow-inner">
           <button onClick={() => setActiveTab('scheduler')} className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${activeTab === 'scheduler' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
             <Calendar size={16} /> Scheduler
           </button>
           <button onClick={() => setActiveTab('live')} className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${activeTab === 'live' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
             <Monitor size={16} /> Live Monitor
           </button>
        </div>
      </div>

      {activeTab === 'scheduler' ? (
        /* ============ SCHEDULER VIEW ============ */
        <>
          <div className="flex flex-col lg:flex-row justify-between items-center gap-4 bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
            {/* Left: View & Date Controls */}
            <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
               {/* View Mode */}
               <div className="flex bg-slate-100 rounded-lg p-1">
                  <button onClick={() => setViewMode('week')} className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors ${viewMode === 'week' ? 'bg-white shadow text-indigo-600' : 'text-slate-500'}`}>Weekly</button>
                  <button onClick={() => setViewMode('month')} className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors ${viewMode === 'month' ? 'bg-white shadow text-indigo-600' : 'text-slate-500'}`}>Monthly</button>
               </div>

               {/* Year & Month Selection */}
               <div className="flex items-center gap-2">
                  <select 
                     value={focusDate.getFullYear()} 
                     onChange={(e) => handleYearChange(Number(e.target.value))}
                     className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-sm font-bold text-slate-700 outline-none cursor-pointer hover:bg-slate-100"
                  >
                     {Array.from({length: 5}, (_, i) => new Date().getFullYear() - 2 + i).map(y => (
                        <option key={y} value={y}>{y}</option>
                     ))}
                  </select>
                  
                  {viewMode === 'month' && (
                     <select 
                        value={focusDate.getMonth()}
                        onChange={(e) => handleMonthChange(Number(e.target.value))}
                        className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-sm font-bold text-slate-700 outline-none cursor-pointer hover:bg-slate-100"
                     >
                        {['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'].map((m, i) => (
                           <option key={i} value={i}>{m}</option>
                        ))}
                     </select>
                  )}
               </div>

               <div className="w-px h-6 bg-slate-200 mx-1 hidden lg:block"></div>

               {/* Navigation */}
               <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg p-0.5">
                  <button onClick={() => handleDateChange('prev')} className="p-1.5 hover:bg-white rounded-md text-slate-500 transition-colors"><ChevronLeft size={18}/></button>
                  <span className="px-3 text-xs font-bold text-slate-600 min-w-[100px] text-center">
                     {viewMode === 'week' 
                        ? `${daysToRender[0]?.getDate()} - ${daysToRender[6]?.getDate()} ${daysToRender[6]?.toLocaleDateString('en-US', {month: 'short'})}`
                        : focusDate.toLocaleDateString('en-US', {month: 'long', year: 'numeric'})
                     }
                  </span>
                  <button onClick={() => handleDateChange('next')} className="p-1.5 hover:bg-white rounded-md text-slate-500 transition-colors"><ChevronRight size={18}/></button>
               </div>
            </div>

            {/* Right: Actions */}
            <div className="flex items-center gap-3 w-full lg:w-auto justify-end">
               <div className="relative group">
                  <select 
                     className="pl-8 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm font-medium text-slate-700 outline-none cursor-pointer appearance-none hover:bg-slate-100 transition-colors"
                     value={selectedDept}
                     onChange={(e) => setSelectedDept(e.target.value)}
                  >
                     <option value="All">All Depts</option>
                     {Object.values(Department).map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                  <Filter size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
               </div>
               
               <button onClick={() => setShowPatternModal(true)} className="bg-indigo-600 text-white px-3 py-2 rounded-lg font-bold text-xs flex items-center gap-2 hover:bg-indigo-700 transition-colors shadow-sm">
                  <Wand2 size={14} /> Pattern
               </button>
            </div>
          </div>

          {/* --- Toolbar (Paintbrush Mode) --- */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-wrap gap-3 items-center">
            <div className="flex items-center gap-2 mr-2">
               <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Tools:</span>
               <button 
                  onClick={() => setSelectedTool('pointer')}
                  className={`p-2 rounded-lg transition-all ${selectedTool === 'pointer' ? 'bg-slate-800 text-white shadow' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}
                  title="Cycle Mode"
               >
                  <MousePointer2 size={16} />
               </button>
               <button 
                  onClick={() => setSelectedTool('eraser')}
                  className={`p-2 rounded-lg transition-all ${selectedTool === 'eraser' ? 'bg-red-100 text-red-600 shadow' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}
                  title="Clear"
               >
                  <Eraser size={16} />
               </button>
            </div>

            <div className="w-px h-6 bg-slate-200 mx-1"></div>

            {/* Shift Palette */}
            <div className="flex flex-wrap gap-2 flex-1">
               {shifts.map(shift => (
               <button
                  key={shift.id}
                  onClick={() => setSelectedTool(shift.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                     selectedTool === shift.id 
                     ? 'ring-2 ring-offset-1 ring-blue-500 border-transparent shadow-md scale-105' 
                     : 'border-transparent bg-slate-50 text-slate-600 hover:bg-slate-100'
                  }`}
                  style={{ backgroundColor: selectedTool === shift.id ? '#eff6ff' : '' }}
               >
                  <span className={`w-2 h-2 rounded-full ${shift.colorClass.split(' ')[0]}`}></span>
                  {shift.name} ({shift.startTime}-{shift.endTime})
               </button>
               ))}
               
               {/* Add Shift Button */}
               <button 
                  onClick={() => setShowShiftModal(true)} 
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold border border-dashed border-slate-300 text-slate-400 hover:text-blue-600 hover:border-blue-400 hover:bg-blue-50 transition-all"
               >
                  <Settings size={12} /> Manage Shifts
               </button>
            </div>
          </div>

          {/* Scheduler Grid */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden relative flex flex-col">
            <div className="overflow-x-auto pb-4 custom-scrollbar">
              <table className="w-full border-collapse">
                <thead>
                  <tr>
                    <th className="p-4 text-left border-b border-r border-slate-200 bg-slate-50 min-w-[200px] sticky left-0 z-20 shadow-[2px_0_5px_rgba(0,0,0,0.02)]">
                      <span className="text-xs font-bold text-slate-500 uppercase">Employee</span>
                    </th>
                    {daysToRender.map((day, index) => (
                      <th key={index} className={`p-2 text-center border-b border-slate-200 bg-slate-50 ${viewMode === 'month' ? 'min-w-[40px]' : 'min-w-[120px]'} ${
                        day.getDay() === 0 || day.getDay() === 6 ? 'bg-slate-50/80' : ''
                      }`}>
                        <div className="flex flex-col items-center">
                          <span className={`text-[9px] uppercase font-bold ${day.toDateString() === new Date().toDateString() ? 'text-blue-600' : 'text-slate-400'}`}>
                            {day.toLocaleDateString('en-US', { weekday: 'short' }).charAt(0)}
                          </span>
                          <span className={`text-sm font-bold ${day.toDateString() === new Date().toDateString() ? 'text-blue-600' : 'text-slate-700'}`}>
                            {day.getDate()}
                          </span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredEmployees.map(emp => (
                    <tr key={emp.id} className="hover:bg-slate-50 transition-colors group">
                      <td className="p-3 border-b border-r border-slate-100 bg-white sticky left-0 z-10">
                        <div className="flex items-center gap-3">
                          <img src={emp.avatarUrl} className="w-8 h-8 rounded-full border border-slate-200" alt="" />
                          <div className="min-w-0">
                            <div className="font-bold text-slate-700 text-xs truncate max-w-[120px] group-hover:text-blue-600 transition-colors">{emp.firstName}</div>
                            <div className="text-[9px] text-slate-400 uppercase truncate max-w-[120px]">{emp.position}</div>
                          </div>
                        </div>
                      </td>
                      {daysToRender.map((day, index) => {
                        const dateStr = day.toISOString().split('T')[0];
                        const assignment = getShiftForEmployee(emp.id, dateStr);
                        const shiftId = assignment ? assignment.shiftId : null;
                        const shift = shiftId ? getShiftDetails(shiftId) : null;
                        const conflict = getConflict(emp.id, dateStr);
                        
                        // Visuals
                        const isOff = shift?.code === 'OFF' || !shift;
                        
                        return (
                          <td 
                            key={`${emp.id}-${index}`} 
                            className={`p-1 border-b border-slate-100 text-center cursor-pointer relative border-r border-dashed border-slate-50 ${isOff ? 'bg-slate-50/30' : ''}`}
                            onClick={() => handleCellClick(emp.id, dateStr, shiftId || undefined)}
                          >
                            <div className={`
                              mx-auto w-full rounded-md border transition-all flex flex-col items-center justify-center relative overflow-hidden
                              ${viewMode === 'month' ? 'h-8' : 'h-12 max-w-[100px]'}
                              ${shift?.colorClass || 'border-slate-200 text-slate-300 hover:border-slate-300'}
                              ${selectedTool !== 'pointer' ? 'hover:scale-95' : ''}
                            `}>
                                {conflict && (
                                  <div className="absolute inset-0 bg-red-50/90 backdrop-blur-[1px] flex items-center justify-center z-10" title={conflict.message}>
                                      {viewMode === 'month' ? <div className="w-1.5 h-1.5 rounded-full bg-red-500"></div> : <span className="text-[9px] font-bold text-red-700">L</span>}
                                  </div>
                                )}

                                {shift ? (
                                  shift.code === 'OFF' ? (
                                    viewMode === 'month' ? <span className="text-[9px] font-bold text-slate-500">OFF</span> :
                                    <>
                                      <span className="text-xs font-bold text-slate-500">วันหยุด</span>
                                      <span className="text-[8px] uppercase tracking-wider opacity-60">OFF</span>
                                    </>
                                  ) : (
                                    viewMode === 'month' ? (
                                       <span className="text-[9px] font-bold truncate px-1">{shift.code}</span>
                                    ) : (
                                       <>
                                          <span className="text-xs font-bold">{shift.code}</span>
                                          <span className="text-[9px] opacity-80">{shift.startTime}</span>
                                       </>
                                    )
                                  )
                                ) : (
                                  <span className="text-[10px] opacity-50 font-medium">-</span>
                                )}
                            </div>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        /* ... LIVE MONITOR VIEW (UNCHANGED) ... */
        /* ============ LIVE MONITOR VIEW ============ */
        <div className="space-y-6">
           {/* Live Stats */}
           <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex items-center justify-between">
                 <div>
                    <p className="text-xs font-bold text-slate-400 uppercase">Total Scheduled</p>
                    <p className="text-2xl font-bold text-slate-800">{liveStats.totalScheduled}</p>
                 </div>
                 <div className="p-3 bg-blue-50 text-blue-600 rounded-lg"><LayoutGrid size={20} /></div>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex items-center justify-between">
                 <div>
                    <p className="text-xs font-bold text-slate-400 uppercase">On Time</p>
                    <p className="text-2xl font-bold text-green-600">{liveStats.present}</p>
                 </div>
                 <div className="p-3 bg-green-50 text-green-600 rounded-lg"><Check size={20} /></div>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex items-center justify-between">
                 <div>
                    <p className="text-xs font-bold text-slate-400 uppercase">Late Arrivals</p>
                    <p className="text-2xl font-bold text-amber-500">{liveStats.late}</p>
                 </div>
                 <div className="p-3 bg-amber-50 text-amber-500 rounded-lg"><Clock size={20} /></div>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex items-center justify-between">
                 <div>
                    <p className="text-xs font-bold text-slate-400 uppercase">No Show / Absent</p>
                    <p className="text-2xl font-bold text-red-500">{liveStats.absent}</p>
                 </div>
                 <div className="p-3 bg-red-50 text-red-500 rounded-lg"><AlertCircle size={20} /></div>
              </div>
           </div>

           {/* Today's Roster List */}
           <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                 <h3 className="font-bold text-slate-800 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                    Live Roster ({todayStr})
                 </h3>
                 <p className="text-xs text-slate-500 font-mono">Current Time: {now.toLocaleTimeString('th-TH')}</p>
              </div>
              
              <div className="divide-y divide-slate-100">
                 {liveData.map(({ emp, shift, status, detail, color, record }) => {
                    // Calculate visual bar percentage
                    const startH = parseInt(shift?.startTime.split(':')[0] || '0');
                    const endH = parseInt(shift?.endTime.split(':')[0] || '0');
                    const totalH = 24;
                    const shiftWidth = ((endH - startH) / totalH) * 100;
                    const shiftLeft = (startH / totalH) * 100;

                    const checkInH = record?.checkIn ? new Date(record.checkIn).getHours() : 0;
                    const checkInLeft = (checkInH / totalH) * 100;

                    return (
                       <div key={emp.id} className="p-4 hover:bg-slate-50 transition-colors flex flex-col md:flex-row gap-4 items-center">
                          {/* Employee Info */}
                          <div className="flex items-center gap-3 w-full md:w-64">
                             <img src={emp.avatarUrl} className="w-10 h-10 rounded-full border border-slate-100" />
                             <div>
                                <h4 className="font-bold text-slate-800 text-sm">{emp.firstName} {emp.lastName}</h4>
                                <p className="text-xs text-slate-400">{emp.position}</p>
                             </div>
                          </div>

                          {/* Status Badge */}
                          <div className="w-full md:w-40 flex flex-col gap-1">
                             <div className={`px-3 py-1 rounded-full text-xs font-bold border text-center ${color}`}>
                                {detail}
                             </div>
                             <div className="text-[10px] text-slate-400 text-center font-mono">
                                Shift: {shift?.startTime} - {shift?.endTime}
                             </div>
                          </div>

                          {/* Visual Timeline Bar */}
                          <div className="flex-1 w-full h-8 bg-slate-100 rounded-lg relative overflow-hidden border border-slate-200">
                             {/* Hour Markers */}
                             <div className="absolute inset-0 flex justify-between px-1">
                                {[0,6,12,18,24].map(h => (
                                   <div key={h} className="h-full w-px bg-slate-200 relative">
                                      <span className="absolute bottom-0 text-[8px] text-slate-400 -ml-1">{h}</span>
                                   </div>
                                ))}
                             </div>

                             {/* Shift Bar (Gray) */}
                             {shift && (
                               <div 
                                 className="absolute top-1 bottom-4 bg-slate-300 opacity-30 rounded-sm"
                                 style={{ left: `${shiftLeft}%`, width: `${shiftWidth}%` }}
                                 title="Scheduled Shift"
                               ></div>
                             )}

                             {/* Actual Work Bar (Green/Red) */}
                             {record?.checkIn && (
                                <div 
                                  className={`absolute top-2 bottom-3 rounded-full shadow-sm ${status === 'Late' ? 'bg-amber-400' : 'bg-green-500'}`}
                                  style={{ 
                                    left: `${checkInLeft}%`, 
                                    width: record.checkOut 
                                       ? `${((new Date(record.checkOut).getHours() - checkInH) / 24) * 100}%` 
                                       : '2px' // Just a dot if currently working
                                  }}
                                >
                                   {!record.checkOut && (
                                      <div className="absolute -right-1 -top-1 w-2 h-2 bg-green-400 rounded-full animate-ping"></div>
                                   )}
                                </div>
                             )}
                          </div>
                          
                          {/* Actual Time Text */}
                          <div className="w-full md:w-32 text-right text-xs font-mono text-slate-600">
                             <div>In: {record?.checkIn ? new Date(record.checkIn).toLocaleTimeString('th-TH', {hour:'2-digit', minute:'2-digit'}) : '--:--'}</div>
                             <div>Out: {record?.checkOut ? new Date(record.checkOut).toLocaleTimeString('th-TH', {hour:'2-digit', minute:'2-digit'}) : '--:--'}</div>
                          </div>
                       </div>
                    );
                 })}
                 {liveData.length === 0 && (
                    <div className="p-12 text-center text-slate-400">
                       <p>No shifts scheduled for today.</p>
                    </div>
                 )}
              </div>
           </div>
        </div>
      )}
      
      {/* --- Auto-Pattern Modal (Existing) --- */}
      {showPatternModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
           <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden animate-fade-in-up">
              <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                 <div>
                    <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                       <Wand2 className="text-purple-600" /> Auto-Pattern Wizard
                    </h3>
                    <p className="text-sm text-slate-500">สร้างแพทเทิร์นการเข้ากะแล้วเทลงในตาราง (Magic Fill)</p>
                 </div>
                 <button onClick={() => setShowPatternModal(false)} className="p-2 hover:bg-slate-200 rounded-full text-slate-400">
                    <X size={20} />
                 </button>
              </div>

              <div className="p-8">
                 {/* Step 1: Build Pattern */}
                 <div className="mb-8">
                    <h4 className="text-sm font-bold text-slate-700 uppercase mb-3">1. Create Sequence (คลิกเพื่อเพิ่ม)</h4>
                    <div className="flex flex-wrap gap-3 mb-4">
                       {shifts.map(shift => (
                          <button 
                            key={shift.id}
                            onClick={() => handleAddToPattern(shift.id)}
                            className={`px-4 py-2 rounded-lg border text-sm font-bold hover:shadow-md transition-all flex items-center gap-2 ${shift.colorClass}`}
                          >
                             <Plus size={14} /> {shift.name}
                          </button>
                       ))}
                    </div>

                    {/* Sequence Preview */}
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 min-h-[80px] flex flex-wrap gap-2 items-center">
                       {patternSequence.length === 0 && (
                          <span className="text-slate-400 text-sm italic w-full text-center">-- ยังไม่มีแพทเทิร์น (เลือกกะด้านบน) --</span>
                       )}
                       {patternSequence.map((sid, idx) => {
                          const s = getShiftDetails(sid);
                          return (
                             <div key={idx} className="flex items-center">
                                <div className={`px-3 py-1.5 rounded-md text-xs font-bold border ${s?.colorClass}`}>
                                   {s?.code}
                                </div>
                                {idx < patternSequence.length - 1 && <div className="w-4 h-0.5 bg-slate-300 mx-1"></div>}
                             </div>
                          );
                       })}
                       {patternSequence.length > 0 && (
                          <button onClick={() => setPatternSequence([])} className="ml-auto text-xs text-red-500 hover:underline">Clear</button>
                       )}
                    </div>
                 </div>

                 {/* Step 2: Info */}
                 <div className="bg-blue-50 p-4 rounded-xl flex gap-3 text-blue-800 text-sm mb-6">
                    <AlertCircle size={20} className="shrink-0" />
                    <p>ระบบจะนำแพทเทิร์นนี้ไปใช้กับ <strong>พนักงานทั้งแผนก ({selectedDept})</strong> ในสัปดาห์ปัจจุบัน โดยวนซ้ำจนครบทุกวัน</p>
                 </div>

                 <div className="flex justify-end gap-3">
                    <button onClick={() => setShowPatternModal(false)} className="px-5 py-2.5 text-slate-600 hover:bg-slate-100 rounded-xl font-bold text-sm">Cancel</button>
                    <button 
                      onClick={handleApplyPattern}
                      disabled={patternSequence.length === 0}
                      className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700 shadow-lg shadow-indigo-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                       <Wand2 size={16} /> Apply Pattern
                    </button>
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* --- Shift Management Modal --- */}
      {showShiftModal && (
         <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-6 animate-fade-in-up">
               <div className="flex justify-between items-center mb-6 border-b border-slate-100 pb-4">
                  <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                     <Settings className="text-indigo-600" /> Manage Shifts
                  </h3>
                  <button onClick={() => setShowShiftModal(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
               </div>

               {/* New Shift Form */}
               <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mb-6">
                  <h4 className="text-sm font-bold text-slate-700 mb-3">สร้างกะใหม่ (New Shift)</h4>
                  <div className="space-y-3">
                     <div className="flex gap-2">
                        <div className="flex-1"><label className="block text-xs font-bold text-slate-500 mb-1">Name</label><input type="text" className="w-full p-2 border rounded-lg text-sm" placeholder="e.g. Night Shift" value={newShift.name} onChange={e => setNewShift({...newShift, name: e.target.value})} /></div>
                        <div className="w-20"><label className="block text-xs font-bold text-slate-500 mb-1">Code</label><input type="text" className="w-full p-2 border rounded-lg text-sm text-center font-bold" placeholder="N" value={newShift.code} onChange={e => setNewShift({...newShift, code: e.target.value})} /></div>
                     </div>
                     <div className="flex gap-2">
                        <div className="flex-1"><label className="block text-xs font-bold text-slate-500 mb-1">Start</label><input type="time" className="w-full p-2 border rounded-lg text-sm" value={newShift.startTime} onChange={e => setNewShift({...newShift, startTime: e.target.value})} /></div>
                        <div className="flex-1"><label className="block text-xs font-bold text-slate-500 mb-1">End</label><input type="time" className="w-full p-2 border rounded-lg text-sm" value={newShift.endTime} onChange={e => setNewShift({...newShift, endTime: e.target.value})} /></div>
                     </div>
                     <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1">Color Theme</label>
                        <div className="flex gap-2">
                           {['bg-blue-100 text-blue-800 border-blue-200', 'bg-green-100 text-green-800 border-green-200', 'bg-purple-100 text-purple-800 border-purple-200', 'bg-orange-100 text-orange-800 border-orange-200', 'bg-red-100 text-red-800 border-red-200'].map(cls => (
                              <button 
                                 key={cls} 
                                 className={`w-8 h-8 rounded-full border-2 ${cls} ${newShift.colorClass === cls ? 'ring-2 ring-offset-1 ring-slate-400' : ''}`}
                                 onClick={() => setNewShift({...newShift, colorClass: cls})}
                              ></button>
                           ))}
                        </div>
                     </div>
                     <button onClick={handleSaveNewShift} className="w-full bg-indigo-600 text-white font-bold text-sm py-2 rounded-lg mt-2 hover:bg-indigo-700 flex items-center justify-center gap-2"><Plus size={16}/> Add Shift</button>
                  </div>
               </div>

               {/* Existing Shifts List */}
               <div>
                  <h4 className="text-sm font-bold text-slate-700 mb-3">กะที่มีอยู่ (Existing Shifts)</h4>
                  <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar">
                     {shifts.filter(s => s.id !== 'OFF').map(s => (
                        <div key={s.id} className="flex justify-between items-center p-3 bg-white border border-slate-100 rounded-lg shadow-sm">
                           <div className="flex items-center gap-3">
                              <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold border ${s.colorClass}`}>{s.code}</span>
                              <div>
                                 <p className="text-sm font-bold text-slate-800">{s.name}</p>
                                 <p className="text-xs text-slate-500">{s.startTime} - {s.endTime}</p>
                              </div>
                           </div>
                           {onDeleteShift && (
                              <button onClick={() => onDeleteShift(s.id)} className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"><Trash2 size={16}/></button>
                           )}
                        </div>
                     ))}
                  </div>
               </div>
            </div>
         </div>
      )}
    </div>
  );
};
