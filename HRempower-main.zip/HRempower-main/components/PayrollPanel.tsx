
import React, { useState, useEffect, useMemo } from 'react';
import { Employee, PayrollRecord, ExpenseRequest, ExpenseType, ExpenseStatus, Role, AttendanceRecord, LeaveRequest, TimeRequest, TimeRequestStatus, PayrollWorkflowStatus, CompanySettings, LeaveStatus, TimeRequestType, EmploymentType, EmployeeStatus } from '../types';
import { Permissions } from '../utils/permissions';
import { DollarSign, Download, CheckCircle, FileText, Calculator, Calendar, Receipt, XCircle, Plus, Upload, Lock, Printer, Building, PlayCircle, RefreshCw, Trash2, AlertCircle, Wallet, Users, Database, History, Info, ShieldCheck, AlertTriangle, AlertOctagon, ArrowRight, Edit2, Save, MessageSquareText, Search, FileSearch, ChevronDown, ChevronUp, CheckCircle2, UserCheck, FileSignature, X, Unlock, RotateCcw, ClipboardCheck, CheckSquare, Activity, User, Clock, MapPin, Table, BookOpen, Sigma, ShieldAlert, Scale, CreditCard, HelpCircle, Zap, Send, FileSpreadsheet, Banknote, Building2, Archive, Eye, EyeOff, Globe } from 'lucide-react';

interface PayrollPanelProps {
  employees: Employee[];
  payroll: PayrollRecord[];
  expenses?: ExpenseRequest[];
  attendance?: AttendanceRecord[]; 
  leaves?: LeaveRequest[]; 
  timeRequests?: TimeRequest[]; 
  companySettings?: CompanySettings; // Added for calculation rules
  onMarkPaid: (id: string) => void;
  onGeneratePayroll: (month: string) => void;
  onPayrollAction?: (month: string, action: 'verify' | 'approve' | 'send_bank' | 'complete' | 'reject' | 'revise' | 'revert_to_draft') => void;
  onClearPayroll?: (month: string) => void;
  onAddExpense?: (expense: ExpenseRequest) => void;
  onUpdateExpenseStatus?: (id: string, status: ExpenseStatus) => void;
  onUpdatePayrollRecord?: (id: string, updates: Partial<PayrollRecord>) => void;
  currentUser: Employee;
  currentView?: 'salary' | 'expense';
  onViewChange?: (view: 'salary' | 'expense') => void;
  lastDataUpdate?: string; 
}

// ... (ManualIndicator and PayrollStepper components remain unchanged) ...
// Helper for "Manual" Badge
const ManualIndicator = ({ isManual }: { isManual?: boolean }) => {
   if (!isManual) return null;
   return (
      <sup className="text-[9px] font-bold text-orange-600 bg-orange-100 px-1 rounded ml-1" title="Edited Manually">
         M
      </sup>
   );
};

// --- PROGRESS STEPPER ---
const PayrollStepper = ({ currentStatus }: { currentStatus: PayrollWorkflowStatus }) => {
   const steps = [
      { id: PayrollWorkflowStatus.DRAFT, label: '1. Calculation', icon: Calculator },
      { id: PayrollWorkflowStatus.VERIFIED, label: '2. Check', icon: ShieldCheck },
      { id: PayrollWorkflowStatus.APPROVED, label: '3. Approval', icon: UserCheck },
      { id: PayrollWorkflowStatus.BANK_PROCESSING, label: '4. Bank', icon: Building2 },
      { id: PayrollWorkflowStatus.PAID, label: '5. Complete', icon: CheckCircle2 }
   ];

   const getStepIndex = (status: PayrollWorkflowStatus) => {
      const map: Record<PayrollWorkflowStatus, number> = {
         [PayrollWorkflowStatus.DRAFT]: 0,
         [PayrollWorkflowStatus.VERIFIED]: 1,
         [PayrollWorkflowStatus.APPROVED]: 2,
         [PayrollWorkflowStatus.BANK_PROCESSING]: 3,
         [PayrollWorkflowStatus.PAID]: 4
      };
      return map[status] ?? 0;
   };

   const currentIndex = getStepIndex(currentStatus);

   return (
      <div className="w-full bg-white rounded-xl border border-slate-200 p-4 shadow-sm mb-6">
         <div className="flex items-center justify-between relative">
            <div className="absolute top-1/2 left-0 w-full h-1 bg-slate-100 -z-10 rounded-full"></div>
            <div 
               className="absolute top-1/2 left-0 h-1 bg-blue-500 -z-10 rounded-full transition-all duration-500 ease-out" 
               style={{ width: `${(currentIndex / (steps.length - 1)) * 100}%` }}
            ></div>

            {steps.map((step, index) => {
               const isActive = index <= currentIndex;
               const isCurrent = index === currentIndex;
               return (
                  <div key={step.id} className="flex flex-col items-center gap-2 relative group">
                     <div className={`
                        w-10 h-10 rounded-full flex items-center justify-center border-4 transition-all duration-300 z-10
                        ${isActive 
                           ? (isCurrent ? 'bg-blue-600 border-blue-100 text-white shadow-lg shadow-blue-200 scale-110' : 'bg-green-500 border-white text-white') 
                           : 'bg-white border-slate-200 text-slate-300'
                        }
                     `}>
                        <step.icon size={isCurrent ? 20 : 16} strokeWidth={isCurrent ? 2.5 : 2} />
                     </div>
                     <span className={`text-[10px] font-bold uppercase tracking-wider transition-colors ${isCurrent ? 'text-blue-600' : isActive ? 'text-slate-600' : 'text-slate-300'}`}>
                        {step.label}
                     </span>
                  </div>
               );
            })}
         </div>
      </div>
   );
};

export const PayrollPanel: React.FC<PayrollPanelProps> = ({ 
  employees, payroll, expenses = [], attendance = [], leaves = [], timeRequests = [], companySettings,
  onMarkPaid, onGeneratePayroll, onPayrollAction, onClearPayroll, onAddExpense, onUpdateExpenseStatus, onUpdatePayrollRecord, currentUser,
  currentView = 'salary', onViewChange, lastDataUpdate
}) => {
  const [internalTab, setInternalTab] = useState<'salary' | 'expense'>('salary');
  const activeTab = onViewChange ? currentView : internalTab;
  const handleTabChange = (tab: 'salary' | 'expense') => {
    if (onViewChange) onViewChange(tab);
    else setInternalTab(tab);
  };

  // Default to Dec 2025 for testing
  const [selectedMonth, setSelectedMonth] = useState('2025-12'); 
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  
  // Publish/Visibility Toggle State
  const [isPayslipReleased, setIsPayslipReleased] = useState(false);

  // Sync published state with batch status (Auto-open if Paid, otherwise allow manual toggle)
  useEffect(() => {
     const batch = payroll.filter(p => p.month === selectedMonth);
     if (batch.length > 0 && batch[0].workflowStatus === PayrollWorkflowStatus.PAID) {
        setIsPayslipReleased(true);
     } else {
        // Reset to false when switching to a non-paid month, or keep user preference?
        // For safety, default to false unless explicitly Paid. 
        // In a real app, this "released" state would be stored in the DB per month.
        setIsPayslipReleased(false); 
     }
  }, [selectedMonth, payroll]);

  // Inline Editing State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValues, setEditValues] = useState<Partial<PayrollRecord>>({});

  // Payslip Modal & Bottom Widget State
  const [showPayslipModal, setShowPayslipModal] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<PayrollRecord | null>(null);
  const [showBottomPayslip, setShowBottomPayslip] = useState(false);
  
  // Drill Down State
  const [drillDownType, setDrillDownType] = useState<'SALARY' | 'OT' | 'DEDUCTION' | 'EXPENSE' | null>(null);
  const [drillRecord, setDrillRecord] = useState<PayrollRecord | null>(null);

  // Validation & Preview State
  const [showPreviewModal, setShowPreviewModal] = useState(false); 
  const [bankFileModal, setBankFileModal] = useState(false);
  const [isFileDownloaded, setIsFileDownloaded] = useState(false);

  // Permissions & Hierarchy Logic
  const isSuperAdmin = currentUser.role === Role.SUPER_ADMIN;
  // Use RBAC
  const canManagePayroll = isSuperAdmin || Permissions.canManagePayroll(currentUser.role, companySettings?.rolePermissions);
  
  // Helper: Find Subordinates (Hierarchy)
  const getSubordinateIds = (managerId: string, allEmps: Employee[]): string[] => {
    const direct = allEmps.filter(e => e.managerId === managerId).map(e => e.id);
    let all = [...direct];
    direct.forEach(id => {
      all = [...all, ...getSubordinateIds(id, allEmps)];
    });
    return all;
  };

  const visibleEmployeeIds = useMemo(() => {
     if (Permissions.canViewAllData(currentUser.role, companySettings?.rolePermissions)) {
        return employees.map(e => e.id); 
     }
     if (currentUser.role === Role.MANAGER) {
        return [currentUser.id, ...getSubordinateIds(currentUser.id, employees)]; 
     }
     return [currentUser.id]; 
  }, [currentUser, employees, companySettings?.rolePermissions]);

  
  // --- FILTERING LOGIC ---
  const filteredPayroll = payroll.filter(p => {
    if (p.month !== selectedMonth) return false;
    return visibleEmployeeIds.includes(p.employeeId);
  });

  // Find My Slip (Current User)
  const mySlip = payroll.find(p => p.employeeId === currentUser.id && p.month === selectedMonth);

  const hasRecords = filteredPayroll.length > 0;
  const currentBatchStatus = hasRecords ? filteredPayroll[0].workflowStatus : PayrollWorkflowStatus.DRAFT;
  
  // Locking Logic
  const isBatchLocked = 
      currentBatchStatus === PayrollWorkflowStatus.APPROVED || 
      currentBatchStatus === PayrollWorkflowStatus.BANK_PROCESSING || 
      currentBatchStatus === PayrollWorkflowStatus.PAID;

  const currentRevision = hasRecords ? (filteredPayroll[0].revision || 0) : 0;

  const totalNetPay = filteredPayroll.reduce((sum, p) => sum + p.netTotal, 0);
  const totalEmployees = filteredPayroll.length;

  // --- Calculate Totals for Footer ---
  const totals = useMemo(() => {
    return filteredPayroll.reduce((acc, curr) => ({
      baseSalary: acc.baseSalary + curr.baseSalary,
      ot: acc.ot + curr.ot,
      positionAllowance: acc.positionAllowance + (curr.positionAllowance || 0),
      travelAllowance: acc.travelAllowance + (curr.travelAllowance || 0),
      perDiem: acc.perDiem + (curr.perDiem || 0),
      diligenceAllowance: acc.diligenceAllowance + (curr.diligenceAllowance || 0),
      bonus: acc.bonus + (curr.bonus || 0),
      socialSecurity: acc.socialSecurity + (curr.socialSecurity || 0),
      tax: acc.tax + (curr.tax || 0),
      deductions: acc.deductions + ((curr.absentDeduction || 0) + (curr.unpaidLeaveDeduction || 0)),
      late: acc.late + (curr.lateDeduction || 0),
      other: acc.other + (curr.otherDeduction || 0),
      netTotal: acc.netTotal + curr.netTotal
    }), { 
      baseSalary: 0, ot: 0, positionAllowance: 0, travelAllowance: 0, perDiem: 0, diligenceAllowance: 0, bonus: 0, socialSecurity: 0, tax: 0, deductions: 0, late: 0, other: 0, netTotal: 0 
    });
  }, [filteredPayroll]);

  // --- History Detection ---
  const paidMonths = useMemo(() => {
     const uniqueMonths = new Set(payroll.filter(p => p.status === 'Paid').map(p => p.month));
     return Array.from(uniqueMonths).sort().reverse();
  }, [payroll]);

  const getEmployee = (id: string) => employees.find(e => e.id === id);
  const formatCurrency = (amount: number) => new Intl.NumberFormat('th-TH', { style: 'currency', currency: 'THB', maximumFractionDigits: 2 }).format(amount);

  // --- Inline Edit Handlers ---
  const handleEditClick = (record: PayrollRecord) => {
     setEditingId(record.id);
     setEditValues({
        baseSalary: record.baseSalary,
        ot: record.ot,
        positionAllowance: record.positionAllowance,
        travelAllowance: record.travelAllowance,
        perDiem: record.perDiem,
        diligenceAllowance: record.diligenceAllowance,
        bonus: record.bonus,
        socialSecurity: record.socialSecurity,
        tax: record.tax,
        otherDeduction: record.otherDeduction,
        absentDeduction: record.absentDeduction,
        lateDeduction: record.lateDeduction,
        unpaidLeaveDeduction: record.unpaidLeaveDeduction,
        manualAdjustment: record.manualAdjustment
     });
  };

  const handleInputChange = (field: keyof PayrollRecord, value: string) => {
     setEditValues(prev => ({ ...prev, [field]: Number(value) }));
  };

  const handleInlineSave = () => {
     if (editingId && onUpdatePayrollRecord) {
        const original = payroll.find(p => p.id === editingId);
        if (original) {
           const overrides = new Set(original.manuallyOverriddenFields || []);
           
           // Simple check for changes
           if (editValues.baseSalary !== original.baseSalary) overrides.add('baseSalary');
           if (editValues.ot !== original.ot) overrides.add('ot');
           // ... (other fields)

           // Recalculate Net Total for Instant Feedback
           const merged = { ...original, ...editValues };
           const totalIncome = (merged.baseSalary || 0) + (merged.ot || 0) + (merged.positionAllowance || 0) + (merged.travelAllowance || 0) + (merged.perDiem || 0) + (merged.diligenceAllowance || 0) + (merged.bonus || 0) + (merged.expenses || 0) + (merged.manualAdjustment || 0);
           const totalDeduct = (merged.socialSecurity || 0) + (merged.tax || 0) + (merged.lateDeduction || 0) + (merged.absentDeduction || 0) + (merged.unpaidLeaveDeduction || 0) + (merged.otherDeduction || 0);
           const newNet = totalIncome - totalDeduct;

           onUpdatePayrollRecord(editingId, { ...editValues, netTotal: newNet, manuallyOverriddenFields: Array.from(overrides) });
        }
     }
     setEditingId(null);
     setEditValues({});
  };

  const handleInlineCancel = () => { setEditingId(null); setEditValues({}); };
  const handleDrillDown = (type: 'SALARY' | 'OT' | 'DEDUCTION' | 'EXPENSE', record: PayrollRecord) => { setDrillDownType(type); setDrillRecord(record); };
  const handleViewPayslip = (record: PayrollRecord) => { setSelectedRecord(record); setShowPayslipModal(true); };
  
  const handleCalculateInitial = () => {
     if (employees.length === 0) { alert("ไม่พบข้อมูลพนักงาน"); return; }
     onGeneratePayroll(selectedMonth);
  };

  const handleNextStep = () => {
     if (!onPayrollAction) return;

     if (currentBatchStatus === PayrollWorkflowStatus.DRAFT) {
        setShowPreviewModal(true);
     } else if (currentBatchStatus === PayrollWorkflowStatus.VERIFIED) {
        onPayrollAction(selectedMonth, 'approve');
     } else if (currentBatchStatus === PayrollWorkflowStatus.APPROVED) {
        onPayrollAction(selectedMonth, 'send_bank');
        setIsFileDownloaded(false); // Reset download state
        setBankFileModal(true);
     } else if (currentBatchStatus === PayrollWorkflowStatus.BANK_PROCESSING) {
        // Re-open modal if they closed it but didn't finish
        setBankFileModal(true);
     }
  };

  const handleRevertStep = () => {
     if (!onPayrollAction) return;
     if (currentBatchStatus === PayrollWorkflowStatus.VERIFIED) {
        onPayrollAction(selectedMonth, 'reject');
     } else if (currentBatchStatus === PayrollWorkflowStatus.APPROVED) {
        if (confirm("คำเตือน: การย้อนกลับจากสถานะอนุมัติ (Approved) จะทำให้ลายเซ็นการอนุมัติถูกยกเลิก คุณต้องการแก้ไขข้อมูลใช่หรือไม่?")) {
           onPayrollAction(selectedMonth, 'revert_to_draft');
        }
     }
  };

  const handleConfirmVerify = () => {
     if (onPayrollAction) {
        onPayrollAction(selectedMonth, 'verify');
        setShowPreviewModal(false);
     }
  };

  // --- BANK FILE CSV LOGIC ---
  const handleDownloadBankFile = () => {
     // Headers per request: Account No, Bank Name, Name, Net Amount
     const headers = "Account Number,Bank Name,Employee Name,Net Amount,Status";
     
     const rows = filteredPayroll.map(p => {
        const emp = getEmployee(p.employeeId);
        const acc = emp?.bankAccountNumber ? `"${emp.bankAccountNumber}"` : '"-"'; // Quote to prevent scientific notation
        const bank = emp?.bankName ? `"${emp.bankName}"` : '"-"';
        const name = emp ? `"${emp.firstName} ${emp.lastName}"` : '"Unknown"';
        const amount = p.netTotal.toFixed(2);
        
        return `${acc},${bank},${name},${amount},Pending`;
     });
     
     // Add BOM for Excel UTF-8 compatibility
     const csvContent = "\uFEFF" + [headers, ...rows].join('\n');
     
     const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
     const url = URL.createObjectURL(blob);
     const link = document.createElement('a');
     link.href = url;
     link.download = `BANK_PAYROLL_${selectedMonth}_${new Date().getTime()}.csv`;
     link.click();
     
     setIsFileDownloaded(true);
  };

  const handleCompletePayroll = () => {
     if (onPayrollAction) {
        onPayrollAction(selectedMonth, 'complete');
        setBankFileModal(false);
        setShowSuccessToast(true);
        setIsPayslipReleased(true); // Auto release when Paid
        setTimeout(() => setShowSuccessToast(false), 3000);
     }
  };

  // --- Export Function (General Report) ---
  const handleExportCSV = () => {
    if (filteredPayroll.length === 0) return;
    const headers = ['Employee ID', 'Name', 'Position', 'Department', 'Base Salary', 'OT', 'Total Income', 'Social Security', 'Tax', 'Total Deduct', 'Net Total', 'Status'];
    const rows = filteredPayroll.map(record => {
      const emp = getEmployee(record.employeeId);
      const name = emp ? `"${emp.firstName} ${emp.lastName}"` : 'Unknown';
      const position = emp ? `"${emp.position}"` : '-';
      const dept = emp ? `"${emp.department}"` : '-';
      return [record.employeeId, name, position, dept, record.baseSalary, record.ot, (record.netTotal + record.deduction), record.socialSecurity, record.tax, record.deduction, record.netTotal, record.status].join(',');
    });
    const csvContent = "\uFEFF" + [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `payroll_report_${selectedMonth}.csv`;
    link.click();
  };

  const renderDrillDownContent = () => {
     if (!drillRecord || !drillDownType) return null;
     const emp = getEmployee(drillRecord.employeeId);
     if (!emp) return null;
     const rowClass = "flex justify-between items-center py-3 border-b border-slate-50 last:border-0";
     const labelClass = "text-sm text-slate-600";
     const valClass = "text-sm font-bold font-mono text-slate-800";
     return (
        <div className="space-y-6">
           <div className="flex items-center gap-4 pb-4 border-b border-slate-100">
              <div className={`p-3 rounded-full ${drillDownType === 'DEDUCTION' ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'}`}>
                 {drillDownType === 'OT' ? <Clock size={24}/> : drillDownType === 'SALARY' ? <DollarSign size={24}/> : drillDownType === 'DEDUCTION' ? <Scale size={24}/> : <Receipt size={24}/>}
              </div>
              <div><h3 className="text-lg font-bold text-slate-800">{drillDownType} Details</h3><p className="text-xs text-slate-500">{emp.firstName} {emp.lastName}</p></div>
           </div>
           <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
              {/* Simplified Drill Down Content */}
              {drillDownType === 'SALARY' && <><div className={rowClass}><span className={labelClass}>Base</span><span className={valClass}>{formatCurrency(drillRecord.baseSalary)}</span></div><div className={rowClass}><span className={labelClass}>Allowances</span><span className={valClass}>{formatCurrency((drillRecord.positionAllowance||0)+(drillRecord.travelAllowance||0))}</span></div></>}
              {drillDownType === 'OT' && <><div className={rowClass}><span className={labelClass}>Hours</span><span className={valClass}>{drillRecord.otHours} hrs</span></div><div className={rowClass}><span className={labelClass}>Amount</span><span className={valClass}>{formatCurrency(drillRecord.ot)}</span></div></>}
              {drillDownType === 'DEDUCTION' && <><div className={rowClass}><span className={labelClass}>SSO</span><span className="text-red-600 font-bold">{formatCurrency(drillRecord.socialSecurity)}</span></div><div className={rowClass}><span className={labelClass}>Tax</span><span className="text-red-600 font-bold">{formatCurrency(drillRecord.tax)}</span></div></>}
           </div>
        </div>
     );
  };

  return (
    <div className="space-y-6 animate-fade-in relative pb-20"> {/* Added bottom padding for the widget */}
      
      {/* SUCCESS TOAST */}
      {showSuccessToast && (
         <div className="absolute top-0 left-1/2 -translate-x-1/2 z-50 bg-green-600 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-2 animate-fade-in-up">
            <CheckCircle2 size={20} />
            <span className="font-bold">Payment Completed & Payslips Released!</span>
         </div>
      )}

      {/* Header Controls */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">ระบบเงินเดือน & เบิกจ่าย</h2>
          <p className="text-slate-500">จัดการเงินเดือนและเบิกจ่ายค่าใช้จ่ายพนักงาน</p>
        </div>
        <div className="flex p-1 bg-white border border-slate-200 rounded-xl shadow-sm">
          <button onClick={() => handleTabChange('salary')} className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-bold transition-colors ${activeTab === 'salary' ? 'bg-slate-800 text-white shadow' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}>
            <Calculator size={16} /> Payroll
          </button>
          <button onClick={() => handleTabChange('expense')} className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-bold transition-colors ${activeTab === 'expense' ? 'bg-blue-600 text-white shadow' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}>
            <Receipt size={16} /> Expenses
          </button>
        </div>
      </div>

      {activeTab === 'salary' ? (
        <div className="space-y-6">
          
          {hasRecords && <PayrollStepper currentStatus={currentBatchStatus} />}

          {/* Toolbar */}
          <div className="flex flex-col gap-4">
             <div className="flex flex-col md:flex-row justify-between items-center bg-white p-4 rounded-xl border border-slate-100 shadow-sm gap-4">
               <div className="flex items-center gap-4 w-full md:w-auto">
                  {/* Month Picker */}
                  <div className="relative">
                     <Calendar className="absolute left-3 top-2.5 text-slate-400" size={18} />
                     <input type="month" className="pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none font-bold text-slate-700" value={selectedMonth} onChange={(e) => setSelectedMonth(e.target.value)} />
                  </div>

                  {/* Payment History Selector */}
                  <div className="relative group">
                     <button className="flex items-center gap-2 px-3 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-bold text-slate-600 transition-colors">
                        <Archive size={16} />
                        ประวัติการจ่าย
                        <ChevronDown size={14} />
                     </button>
                     <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-100 py-1 hidden group-hover:block z-50 animate-fade-in-up">
                        <div className="px-3 py-2 border-b border-slate-50 text-[10px] font-bold text-slate-400 uppercase">Paid Months</div>
                        {paidMonths.length > 0 ? paidMonths.map(m => (
                           <button 
                              key={m} 
                              onClick={() => setSelectedMonth(m)}
                              className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 hover:text-blue-600 flex items-center justify-between"
                           >
                              {m} <CheckCircle2 size={14} className="text-green-500" />
                           </button>
                        )) : (
                           <div className="px-4 py-3 text-xs text-slate-400 italic">No history yet</div>
                        )}
                     </div>
                  </div>

                  {lastDataUpdate && <div className="hidden md:flex flex-col border-l border-slate-200 pl-4"><span className="text-[10px] text-slate-400 font-bold uppercase">Last Update</span><span className="text-xs font-medium text-slate-600">{new Date(lastDataUpdate).toLocaleString('th-TH')}</span></div>}
               </div>
               
               {/* --- MAIN ACTIONS --- */}
               <div className="flex items-center gap-3 w-full md:w-auto justify-end">
                  {canManagePayroll && (
                    <>
                       {!hasRecords ? (
                          <button 
                             onClick={handleCalculateInitial}
                             className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold shadow-lg bg-blue-600 text-white hover:bg-blue-700 transition-all active:scale-95"
                          >
                             <Calculator size={20} />
                             <span>Start Calculation</span>
                          </button>
                       ) : (
                          <>
                             {currentBatchStatus !== PayrollWorkflowStatus.DRAFT && currentBatchStatus !== PayrollWorkflowStatus.PAID && (
                                <button 
                                   onClick={handleRevertStep}
                                   className="px-4 py-2.5 rounded-xl font-bold text-slate-500 hover:bg-slate-100 border border-slate-200 text-sm"
                                >
                                   {currentBatchStatus === PayrollWorkflowStatus.APPROVED ? 'Revert' : 'Reject'}
                                </button>
                             )}

                             {/* Context-Aware Action Button */}
                             {currentBatchStatus !== PayrollWorkflowStatus.PAID && (
                                <button 
                                   onClick={handleNextStep} 
                                   className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold shadow-lg text-white transition-all
                                      ${currentBatchStatus === PayrollWorkflowStatus.DRAFT ? 'bg-indigo-600 hover:bg-indigo-700' : 
                                        currentBatchStatus === PayrollWorkflowStatus.VERIFIED ? 'bg-emerald-600 hover:bg-emerald-700' :
                                        currentBatchStatus === PayrollWorkflowStatus.APPROVED ? 'bg-slate-800 hover:bg-slate-900' :
                                        currentBatchStatus === PayrollWorkflowStatus.BANK_PROCESSING ? 'bg-blue-600 hover:bg-blue-700' :
                                        'bg-slate-600'
                                      }
                                   `}
                                >
                                   {currentBatchStatus === PayrollWorkflowStatus.DRAFT && <><ShieldCheck size={20} /> Send to Verify</>}
                                   {currentBatchStatus === PayrollWorkflowStatus.VERIFIED && <><UserCheck size={20} /> Approve Payroll</>}
                                   {currentBatchStatus === PayrollWorkflowStatus.APPROVED && <><Building2 size={20} /> Send to Bank</>}
                                   {currentBatchStatus === PayrollWorkflowStatus.BANK_PROCESSING && <><Building2 size={20} /> Bank Process</>}
                                </button>
                             )}
                          </>
                       )}
                       
                       {hasRecords && (
                          <button onClick={handleExportCSV} className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold bg-white text-slate-600 border border-slate-200 hover:bg-slate-50 transition-all shadow-sm" title="Export to CSV">
                             <FileSpreadsheet size={20} />
                             <span className="hidden sm:inline">Export</span>
                          </button>
                       )}
                    </>
                 )}
               </div>
             </div>
          </div>

          {/* Payroll Table */}
          {!hasRecords ? (
             <div className="bg-white rounded-xl shadow-sm border border-slate-200 border-dashed p-12 text-center flex flex-col items-center justify-center min-h-[400px]">
                <Calculator size={48} className="text-slate-300 mb-6" /><h3 className="text-xl font-bold text-slate-700 mb-2">ไม่มีข้อมูลเดือน {selectedMonth}</h3><p className="text-slate-500 mb-8">กดปุ่มคำนวณเพื่อเริ่มสร้างแบบร่างเงินเดือน</p>
             </div>
          ) : (
             <div className={`bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden ${isBatchLocked ? 'border-t-4 border-t-green-500' : 'border-t-4 border-t-blue-400'}`}>
                <div className="overflow-x-auto pb-4 custom-scrollbar max-h-[600px]">
                  <table className="w-full text-left whitespace-nowrap relative border-collapse">
                    <thead className="bg-slate-50 text-slate-600 font-medium border-b border-slate-200 text-xs uppercase tracking-wider sticky top-0 z-20 shadow-sm">
                      <tr>
                        <th className="px-6 py-4 sticky left-0 bg-slate-50 z-20 shadow-sm">พนักงาน (Employee)</th>
                        <th className="px-4 py-4 text-right">เงินเดือน (Base)</th>
                        <th className="px-4 py-4 text-right text-green-600">OT</th>
                        <th className="px-4 py-4 text-right text-blue-600">ค่าตำแหน่ง (Pos.)</th>
                        <th className="px-4 py-4 text-right text-blue-600">ค่าเดินทาง (Travel)</th>
                        <th className="px-4 py-4 text-right text-blue-600">เบี้ยเลี้ยง (PerDiem)</th>
                        <th className="px-4 py-4 text-right text-blue-600">เบี้ยขยัน (Diligence)</th>
                        <th className="px-4 py-4 text-right text-green-700 bg-green-50/30">โบนัส (Bonus)</th>
                        <th className="px-4 py-4 text-right text-red-600 bg-red-50/30 font-bold border-l border-red-100">ประกันสังคม (SSO)</th>
                        <th className="px-4 py-4 text-right text-red-600 bg-red-50/30 font-bold">ภาษี (Tax)</th>
                        <th className="px-4 py-4 text-right text-red-500">ขาด/ลา (Absent)</th>
                        <th className="px-4 py-4 text-right text-amber-600">สาย (Late)</th>
                        <th className="px-4 py-4 text-right text-red-500">หักอื่นๆ (Other)</th>
                        <th className="px-6 py-4 text-right font-bold text-slate-900 sticky right-[160px] bg-slate-50 z-20 shadow-sm border-l border-slate-100">สุทธิ (Net)</th>
                        <th className="px-4 py-4 text-center sticky right-0 bg-slate-50 z-20">สถานะ / Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-sm">
                      {filteredPayroll.map((record) => {
                        const emp = getEmployee(record.employeeId);
                        const isEditing = editingId === record.id;
                        const totalAbsentDeduct = (record.absentDeduction || 0) + (record.unpaidLeaveDeduction || 0);
                        const isZeroWork = record.payableDays === 0 && record.netTotal === 0;
                        
                        // Edit Mode Row
                        if (isEditing) {
                           return (
                              <tr key={record.id} className="bg-blue-50/50">
                                 <td className="px-6 py-4 sticky left-0 bg-white z-10 border-r border-slate-100 shadow-sm">
                                    <div className="font-bold text-slate-900">{emp?.firstName} {emp?.lastName}</div>
                                 </td>
                                 <td className="px-2 py-4"><input type="number" className="w-24 p-1 border rounded text-right bg-white focus:ring-2 focus:ring-blue-500" value={editValues.baseSalary} onChange={e => handleInputChange('baseSalary', e.target.value)} /></td>
                                 <td className="px-2 py-4"><input type="number" className="w-20 p-1 border rounded text-right bg-white focus:ring-2 focus:ring-blue-500" value={editValues.ot} onChange={e => handleInputChange('ot', e.target.value)} /></td>
                                 <td className="px-2 py-4"><input type="number" className="w-20 p-1 border rounded text-right bg-white focus:ring-2 focus:ring-blue-500" value={editValues.positionAllowance} onChange={e => handleInputChange('positionAllowance', e.target.value)} /></td>
                                 <td className="px-2 py-4"><input type="number" className="w-20 p-1 border rounded text-right bg-white focus:ring-2 focus:ring-blue-500" value={editValues.travelAllowance} onChange={e => handleInputChange('travelAllowance', e.target.value)} /></td>
                                 <td className="px-2 py-4"><input type="number" className="w-20 p-1 border rounded text-right bg-white focus:ring-2 focus:ring-blue-500" value={editValues.perDiem} onChange={e => handleInputChange('perDiem', e.target.value)} /></td>
                                 <td className="px-2 py-4"><input type="number" className="w-20 p-1 border rounded text-right bg-white focus:ring-2 focus:ring-blue-500" value={editValues.diligenceAllowance} onChange={e => handleInputChange('diligenceAllowance', e.target.value)} /></td>
                                 <td className="px-2 py-4"><input type="number" className="w-20 p-1 border rounded text-right bg-white focus:ring-2 focus:ring-blue-500" value={editValues.bonus} onChange={e => handleInputChange('bonus', e.target.value)} /></td>
                                 <td className="px-2 py-4"><input type="number" className="w-20 p-1 border rounded text-right bg-white text-red-600 focus:ring-2 focus:ring-red-500" value={editValues.socialSecurity} onChange={e => handleInputChange('socialSecurity', e.target.value)} /></td>
                                 <td className="px-2 py-4"><input type="number" className="w-20 p-1 border rounded text-right bg-white text-red-600 focus:ring-2 focus:ring-red-500" value={editValues.tax} onChange={e => handleInputChange('tax', e.target.value)} /></td>
                                 <td className="px-2 py-4"><input type="number" className="w-20 p-1 border rounded text-right bg-white text-red-600 focus:ring-2 focus:ring-red-500" value={editValues.absentDeduction} onChange={e => handleInputChange('absentDeduction', e.target.value)} /></td>
                                 <td className="px-2 py-4"><input type="number" className="w-20 p-1 border rounded text-right bg-white text-red-600 focus:ring-2 focus:ring-red-500" value={editValues.lateDeduction} onChange={e => handleInputChange('lateDeduction', e.target.value)} /></td>
                                 <td className="px-2 py-4"><input type="number" className="w-20 p-1 border rounded text-right bg-white text-red-600 focus:ring-2 focus:ring-red-500" value={editValues.otherDeduction} onChange={e => handleInputChange('otherDeduction', e.target.value)} /></td>
                                 <td className="px-6 py-4 text-right text-slate-400 sticky right-[160px] bg-white z-10">---</td>
                                 <td className="px-4 py-4 text-center sticky right-0 bg-white z-10 border-l border-slate-100">
                                    <div className="flex gap-2 justify-center">
                                       <button onClick={handleInlineSave} className="p-1.5 bg-green-600 text-white rounded hover:bg-green-700 shadow"><CheckCircle size={16} /></button>
                                       <button onClick={handleInlineCancel} className="p-1.5 bg-slate-200 text-slate-600 rounded hover:bg-slate-300"><X size={16} /></button>
                                    </div>
                                 </td>
                              </tr>
                           );
                        }

                        // Normal Row
                        return (
                          <tr key={record.id} className={`hover:bg-slate-50 transition-colors ${record.isOutSync ? 'bg-amber-50/50' : ''}`}>
                            <td className="px-6 py-4 sticky left-0 bg-white group-hover:bg-slate-50 z-10 border-r border-slate-50">
                              <div className="flex items-center gap-3">
                                {emp && <img src={emp.avatarUrl} className="w-10 h-10 rounded-full bg-slate-200 border border-slate-100" />}
                                <div>
                                  <div className="font-bold text-slate-900 text-sm flex items-center gap-2">
                                     {emp ? `${emp.firstName} ${emp.lastName}` : record.employeeId}
                                  </div>
                                  <div className="text-xs text-slate-500 mt-0.5">{emp?.position}</div>
                                </div>
                              </div>
                            </td>
                            
                            {isZeroWork ? (
                               <td colSpan={13} className="px-6 py-4 text-center"><div className="flex items-center justify-center gap-2 text-slate-500 font-bold text-sm bg-slate-100/50 py-2 rounded-lg border border-slate-200"><AlertTriangle size={16} /> ไม่พบข้อมูลการลงเวลา</div></td>
                            ) : (
                               <>
                                  <td className="px-4 py-4 text-right font-mono text-slate-700">
                                     <span className="hover:text-blue-600 hover:underline transition-colors cursor-pointer" onClick={() => handleDrillDown('SALARY', record)}>
                                        {formatCurrency(record.baseSalary)}
                                     </span>
                                  </td>
                                  <td className="px-4 py-4 text-right font-mono text-green-600">
                                     <span className="flex items-center justify-end cursor-pointer hover:underline hover:text-green-800" onClick={() => handleDrillDown('OT', record)}>
                                        {record.ot > 0 ? formatCurrency(record.ot) : '-'}
                                        <ManualIndicator isManual={record.manuallyOverriddenFields?.includes('ot')} />
                                     </span>
                                  </td>
                                  <td className="px-4 py-4 text-right font-mono text-blue-600">{record.positionAllowance ? formatCurrency(record.positionAllowance) : '-'}</td>
                                  <td className="px-4 py-4 text-right font-mono text-blue-600">{record.travelAllowance ? formatCurrency(record.travelAllowance) : '-'}</td>
                                  <td className="px-4 py-4 text-right font-mono text-blue-600">{record.perDiem ? formatCurrency(record.perDiem) : '-'}</td>
                                  <td className="px-4 py-4 text-right font-mono text-blue-600">{record.diligenceAllowance ? formatCurrency(record.diligenceAllowance) : '-'}</td>
                                  <td className="px-4 py-4 text-right font-mono text-green-700 bg-green-50/30">{record.bonus ? formatCurrency(record.bonus) : '-'}</td>
                                  
                                  {/* NEW COLUMNS: SSO & TAX */}
                                  <td className="px-4 py-4 text-right font-mono text-red-600 bg-red-50/20 border-l border-red-50">{record.socialSecurity > 0 ? `-${formatCurrency(record.socialSecurity)}` : '-'}</td>
                                  <td className="px-4 py-4 text-right font-mono text-red-600 bg-red-50/20">{record.tax > 0 ? `-${formatCurrency(record.tax)}` : '-'}</td>

                                  <td className="px-4 py-4 text-right font-mono text-red-500">{totalAbsentDeduct > 0 ? `-${formatCurrency(totalAbsentDeduct)}` : '-'}</td>
                                  <td className="px-4 py-4 text-right font-mono text-amber-600">{record.lateDeduction > 0 ? `-${formatCurrency(record.lateDeduction)}` : '-'}</td>
                                  <td className="px-4 py-4 text-right font-mono text-red-500">{record.otherDeduction ? `-${formatCurrency(record.otherDeduction)}` : '-'}</td>
                                  <td className="px-6 py-4 text-right font-bold text-slate-900 font-mono text-base bg-slate-50/80 sticky right-[160px] z-10 border-l border-slate-100">
                                     {formatCurrency(record.netTotal)}
                                     {record.manualAdjustment !== 0 && <div className={`text-[9px] ${record.manualAdjustment! > 0 ? 'text-green-600' : 'text-red-500'}`}>{record.manualAdjustment! > 0 ? '+' : ''}{record.manualAdjustment} (Adj)</div>}
                                  </td>
                               </>
                            )}

                            <td className="px-4 py-4 text-center sticky right-0 bg-white z-10 border-l border-slate-50">
                               <div className="flex flex-col items-center gap-2">
                                   <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${record.status === 'Paid' ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-600'}`}>{record.status}</span>
                                   <div className="flex gap-1">
                                      <button onClick={() => handleViewPayslip(record)} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors" title="View Payslip"><FileText size={16} /></button>
                                      {canManagePayroll && (!isBatchLocked || record.isOutSync) && (
                                        <button 
                                            onClick={() => handleEditClick(record)} 
                                            className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded transition-colors"
                                            title="Edit Inline"
                                        >
                                            <Edit2 size={16} />
                                        </button>
                                      )}
                                   </div>
                               </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                    <tfoot className="bg-slate-100 border-t border-slate-300 font-bold text-xs uppercase sticky bottom-0 z-20 shadow-[0_-2px_5px_rgba(0,0,0,0.05)]">
                        <tr>
                           <td className="px-6 py-4 sticky left-0 bg-slate-100 z-20 border-r border-slate-200">TOTAL</td>
                           <td className="px-4 py-4 text-right text-slate-700">{formatCurrency(totals.baseSalary)}</td>
                           <td className="px-4 py-4 text-right text-green-700">{formatCurrency(totals.ot)}</td>
                           <td colSpan={4} className="px-4 py-4 text-center text-slate-400">---</td>
                           <td className="px-4 py-4 text-right text-green-700">{formatCurrency(totals.bonus)}</td>
                           <td className="px-4 py-4 text-right text-red-700">{formatCurrency(totals.socialSecurity)}</td>
                           <td className="px-4 py-4 text-right text-red-700">{formatCurrency(totals.tax)}</td>
                           <td colSpan={3} className="px-4 py-4 text-center text-slate-400">---</td>
                           <td className="px-6 py-4 text-right text-slate-900 bg-slate-200 sticky right-[160px] z-20 border-l border-slate-300 text-sm">
                              {formatCurrency(totals.netTotal)}
                           </td>
                           <td className="px-4 py-4 sticky right-0 bg-slate-100 z-20 border-l border-slate-200"></td>
                        </tr>
                    </tfoot>
                  </table>
                </div>
                
                {/* --- ADMIN ONLY: PAYSLIP RELEASE TOGGLE --- */}
                {canManagePayroll && hasRecords && (
                   <div className="bg-slate-50 border-t border-slate-200 p-4 flex justify-between items-center">
                      <div className="flex items-center gap-4">
                         <div className="p-2 bg-white rounded-lg border border-slate-200 shadow-sm">
                            {isPayslipReleased ? <Globe className="text-green-600" size={24}/> : <Lock className="text-slate-400" size={24}/>}
                         </div>
                         <div>
                            <h4 className="font-bold text-slate-800 text-sm">การเปิดเผยสลิปเงินเดือน (Payslip Visibility)</h4>
                            <p className="text-xs text-slate-500">
                               {isPayslipReleased 
                                  ? 'พนักงานสามารถดูสลิปเงินเดือนได้แล้ว (Public)' 
                                  : 'สลิปเงินเดือนถูกซ่อนอยู่ (Hidden from employees)'}
                            </p>
                         </div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                         <input 
                           type="checkbox" 
                           checked={isPayslipReleased} 
                           onChange={(e) => setIsPayslipReleased(e.target.checked)} 
                           className="sr-only peer" 
                         />
                         <div className="w-14 h-7 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-green-600"></div>
                         <span className="ml-3 text-sm font-medium text-slate-700 font-bold">
                            {isPayslipReleased ? 'OPEN' : 'CLOSED'}
                         </span>
                      </label>
                   </div>
                )}
             </div>
          )}
        </div>
      ) : (
        <div className="text-center py-20 text-slate-400 border-2 border-dashed border-slate-200 rounded-2xl"><Receipt size={48} className="mx-auto mb-4 opacity-20" /><p>ส่วนจัดการค่าใช้จ่าย (Coming Soon)</p></div>
      )}

      {/* ... (Keep existing My Payslip Widget and Modals) ... */}
      {mySlip && (isPayslipReleased || canManagePayroll) && (
         <div 
            className={`fixed bottom-0 right-0 w-full md:w-[450px] bg-white shadow-[0_-5px_30px_rgba(0,0,0,0.15)] transition-all duration-300 z-40 flex flex-col border-t border-slate-200 rounded-t-2xl md:right-8 md:bottom-0 overflow-hidden ${showBottomPayslip ? 'h-[600px]' : 'h-[70px]'} pb-safe`}
         >
            {/* Widget Header (Toggle) */}
            <div 
               className={`h-[70px] px-6 flex items-center justify-between cursor-pointer transition-colors shrink-0 ${isPayslipReleased ? 'bg-slate-800 text-white hover:bg-slate-900' : 'bg-amber-100 text-amber-800'}`}
               onClick={() => setShowBottomPayslip(!showBottomPayslip)}
            >
               <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full flex items-center justify-center ${isPayslipReleased ? 'bg-white/10' : 'bg-white/50'}`}>
                     {showBottomPayslip ? <EyeOff size={20}/> : <Eye size={20}/>}
                  </div>
                  <div>
                     <p className="text-[10px] font-bold opacity-70 uppercase tracking-wider flex items-center gap-2">
                        My Payslip 
                        {!isPayslipReleased && <span className="bg-amber-200 text-amber-900 px-1.5 py-0.5 rounded text-[9px] border border-amber-300">ADMIN VIEW</span>}
                     </p>
                     <p className="font-bold text-sm">{new Date(mySlip.month + '-01').toLocaleDateString('th-TH', { month: 'long', year: 'numeric' })}</p>
                  </div>
               </div>
               
               <div className="flex items-center gap-4">
                  <div className="text-right">
                     <p className="text-[10px] opacity-70 uppercase">Net Pay</p>
                     <p className={`text-lg font-mono font-bold ${isPayslipReleased ? 'text-emerald-400' : 'text-amber-700'}`}>{formatCurrency(mySlip.netTotal)}</p>
                  </div>
                  <ChevronUp className={`transition-transform duration-300 ${showBottomPayslip ? 'rotate-180' : ''}`} />
               </div>
            </div>

            {/* Content (Detail View) */}
            <div className="flex-1 overflow-y-auto bg-slate-50 p-6 custom-scrollbar">
               {/* Reusing Payslip UI Structure */}
               <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 space-y-6">
                  {/* Header */}
                  <div className="flex justify-between items-start border-b border-slate-100 pb-4">
                     <div className="flex gap-3">
                        <img src={currentUser.avatarUrl} className="w-12 h-12 rounded-full border border-slate-100" />
                        <div>
                           <h3 className="font-bold text-slate-800">{currentUser.firstName} {currentUser.lastName}</h3>
                           <p className="text-xs text-slate-500">{currentUser.position}</p>
                        </div>
                     </div>
                     <div className="text-right">
                        <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${mySlip.status === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>{mySlip.status}</span>
                     </div>
                  </div>

                  {/* Earnings */}
                  <div>
                     <h4 className="font-bold text-green-700 text-xs uppercase mb-3 border-b border-green-100 pb-1">Earnings (รายได้)</h4>
                     <div className="space-y-2 text-sm">
                        <div className="flex justify-between"><span className="text-slate-600">Base Salary</span><span className="font-mono">{formatCurrency(mySlip.baseSalary)}</span></div>
                        {mySlip.ot > 0 && <div className="flex justify-between"><span className="text-slate-600">Overtime</span><span className="font-mono">{formatCurrency(mySlip.ot)}</span></div>}
                        {(mySlip.positionAllowance || 0) > 0 && <div className="flex justify-between"><span className="text-slate-600">Position Allow.</span><span className="font-mono">{formatCurrency(mySlip.positionAllowance!)}</span></div>}
                        {(mySlip.travelAllowance || 0) > 0 && <div className="flex justify-between"><span className="text-slate-600">Travel Allow.</span><span className="font-mono">{formatCurrency(mySlip.travelAllowance!)}</span></div>}
                        {(mySlip.bonus || 0) > 0 && <div className="flex justify-between"><span className="text-slate-600">Bonus</span><span className="font-mono">{formatCurrency(mySlip.bonus!)}</span></div>}
                        {mySlip.manualAdjustment && mySlip.manualAdjustment > 0 && <div className="flex justify-between"><span className="text-slate-600">Adjustment</span><span className="font-mono">{formatCurrency(mySlip.manualAdjustment)}</span></div>}
                     </div>
                  </div>

                  {/* Deductions */}
                  <div>
                     <h4 className="font-bold text-red-700 text-xs uppercase mb-3 border-b border-red-100 pb-1">Deductions (รายการหัก)</h4>
                     <div className="space-y-2 text-sm">
                        {mySlip.socialSecurity > 0 && <div className="flex justify-between"><span className="text-slate-600">Social Security</span><span className="font-mono text-red-600">-{formatCurrency(mySlip.socialSecurity)}</span></div>}
                        {mySlip.tax > 0 && <div className="flex justify-between"><span className="text-slate-600">Tax</span><span className="font-mono text-red-600">-{formatCurrency(mySlip.tax)}</span></div>}
                        {mySlip.lateDeduction > 0 && <div className="flex justify-between"><span className="text-slate-600">Late</span><span className="font-mono text-red-600">-{formatCurrency(mySlip.lateDeduction)}</span></div>}
                        {mySlip.manualAdjustment && mySlip.manualAdjustment < 0 && <div className="flex justify-between"><span className="text-slate-600">Adjustment</span><span className="font-mono text-red-600">-{formatCurrency(Math.abs(mySlip.manualAdjustment))}</span></div>}
                     </div>
                  </div>

                  {/* Net Total */}
                  <div className="bg-slate-100 p-4 rounded-xl flex justify-between items-center mt-4">
                     <span className="font-bold text-slate-600 uppercase text-xs">Net Pay</span>
                     <span className="font-bold text-2xl text-slate-900 font-mono">{formatCurrency(mySlip.netTotal)}</span>
                  </div>
                  
                  {/* Download Button */}
                  <button 
                     onClick={() => { setShowBottomPayslip(false); handleViewPayslip(mySlip); }}
                     className="w-full py-3 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl font-bold text-sm shadow-sm transition-colors flex justify-center items-center gap-2"
                  >
                     <Printer size={16} /> Open Full Payslip
                  </button>
               </div>
            </div>
         </div>
      )}

      {/* --- Verify & Submit Modal (Keep Existing) --- */}
      {showPreviewModal && (
         <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[90] p-4 animate-fade-in" onClick={() => setShowPreviewModal(false)}>
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-fade-in-up" onClick={(e) => e.stopPropagation()}>
               <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                  <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                     <FileSearch className="text-emerald-600" /> Verify & Submit
                  </h3>
                  <button onClick={() => setShowPreviewModal(false)} className="text-slate-400 hover:text-slate-600"><X size={24} /></button>
               </div>
               <div className="p-6 space-y-4">
                  <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100 flex items-start gap-3">
                     <ShieldCheck className="text-emerald-600 shrink-0 mt-1" size={20} />
                     <div><h4 className="font-bold text-emerald-800 text-sm">ยืนยันความถูกต้อง</h4><p className="text-xs text-emerald-700 mt-1">กรุณาตรวจสอบว่าข้อมูลถูกต้องก่อนส่งอนุมัติ</p></div>
                  </div>
                  <div className="space-y-3">
                     <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg border border-slate-200"><span className="text-sm font-bold text-slate-600">Total Employees</span><span className="text-lg font-bold text-slate-800">{totalEmployees}</span></div>
                     <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg border border-slate-200"><span className="text-sm font-bold text-slate-600">Total Net Pay</span><span className="text-lg font-bold text-indigo-600 font-mono">{formatCurrency(totalNetPay)}</span></div>
                  </div>
               </div>
               <div className="p-6 border-t border-slate-100 flex gap-3">
                  <button onClick={() => setShowPreviewModal(false)} className="flex-1 py-3 text-slate-600 font-bold bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors">Cancel</button>
                  <button onClick={handleConfirmVerify} className="flex-1 py-3 text-white font-bold bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-lg transition-colors flex items-center justify-center gap-2"><Send size={18} /> Confirm Submit</button>
               </div>
            </div>
         </div>
      )}

      {/* --- Bank File Generation Modal (Updated) --- */}
      {bankFileModal && (
         <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[90] p-4 animate-fade-in">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg animate-fade-in-up">
               <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                  <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2"><Building2 className="text-blue-600"/> Bank File Generation</h3>
                  <button onClick={() => setBankFileModal(false)} className="text-slate-400 hover:text-slate-600"><X size={20}/></button>
               </div>
               <div className="p-8 text-center space-y-6">
                  <div>
                     <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Banknote size={40} className="text-blue-600" />
                     </div>
                     <h4 className="text-xl font-bold text-slate-800 mb-2">Ready to Export (CSV/Excel)</h4>
                     <p className="text-sm text-slate-500">
                        ระบบจะสร้างไฟล์ Excel (CSV) สำหรับนำส่งธนาคาร <br/>
                        ยอดรวมสุทธิ: <span className="font-bold text-slate-800">{formatCurrency(totalNetPay)}</span>
                     </p>
                  </div>
                  
                  {/* Step 1: Download */}
                  <button 
                     onClick={handleDownloadBankFile}
                     className={`w-full py-4 rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 transition-all ${
                        isFileDownloaded 
                           ? 'bg-slate-100 text-slate-500 border border-slate-200' 
                           : 'bg-blue-600 text-white hover:bg-blue-700'
                     }`}
                  >
                     <Download size={20} /> 
                     {isFileDownloaded ? 'Downloaded (Click to download again)' : '1. Download Bank File (CSV)'}
                  </button>

                  {/* Step 2: Complete */}
                  <div className={`transition-all duration-500 ${isFileDownloaded ? 'opacity-100 translate-y-0' : 'opacity-50 translate-y-2 pointer-events-none'}`}>
                     <div className="flex items-center gap-3 mb-3">
                        <div className="h-px bg-slate-200 flex-1"></div>
                        <span className="text-xs font-bold text-slate-400 uppercase">After Transfer</span>
                        <div className="h-px bg-slate-200 flex-1"></div>
                     </div>
                     <button 
                        onClick={handleCompletePayroll}
                        disabled={!isFileDownloaded}
                        className="w-full py-4 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200 flex items-center justify-center gap-2"
                     >
                        <CheckCircle2 size={20} /> 2. Mark as Completed (Paid)
                     </button>
                     <p className="text-[10px] text-slate-400 mt-2">
                        * กดปุ่มนี้เมื่อทำการโอนเงินผ่านธนาคารเรียบร้อยแล้ว สถานะจะเปลี่ยนเป็น "Paid"
                     </p>
                  </div>
               </div>
            </div>
         </div>
      )}

      {/* --- Drill Down Modal (Keep Existing) --- */}
      {drillRecord && drillDownType && (
         <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[90] p-4 animate-fade-in" onClick={() => setDrillRecord(null)}>
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-fade-in-up" onClick={(e) => e.stopPropagation()}>
               <div className="flex justify-between items-center p-4 border-b border-slate-100 bg-slate-50">
                  <h3 className="font-bold text-slate-800 flex items-center gap-2">
                     <HelpCircle size={18} className="text-blue-600" /> Source Breakdown
                  </h3>
                  <button onClick={() => setDrillRecord(null)} className="p-1 rounded-full hover:bg-slate-200 text-slate-400"><X size={20} /></button>
               </div>
               <div className="p-6">
                  {renderDrillDownContent()}
               </div>
               <div className="p-4 bg-slate-50 text-center border-t border-slate-100">
                  <button onClick={() => setDrillRecord(null)} className="text-sm font-bold text-blue-600 hover:text-blue-800">Close</button>
               </div>
            </div>
         </div>
      )}

      {/* Payslip Modal (Keep Existing) */}
      {showPayslipModal && selectedRecord && (
         <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[80] p-4 animate-fade-in">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl h-[90vh] flex flex-col overflow-hidden animate-fade-in-up border-t-8 border-slate-800">
               {/* ... (Existing Payslip Content) ... */}
               <div className="p-6 border-b border-slate-100 flex justify-between items-start bg-slate-50/50">
                  <div className="flex gap-4">
                     {companySettings?.logoUrl ? <img src={companySettings.logoUrl} className="w-16 h-16 object-contain rounded-lg border border-slate-200 bg-white p-1" /> : <div className="w-16 h-16 bg-slate-800 text-white rounded-lg flex items-center justify-center font-bold text-2xl">{companySettings?.name.charAt(0) || 'C'}</div>}
                     <div><h2 className="text-xl font-bold text-slate-800">{companySettings?.name}</h2><p className="text-xs text-slate-500 max-w-xs">{companySettings?.address}</p></div>
                  </div>
                  <div className="text-right"><h3 className="text-2xl font-bold text-slate-800 uppercase tracking-widest">Payslip</h3><p className="text-sm font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded inline-block mt-1">{selectedRecord.month}</p></div>
               </div>
               <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                  <div className="space-y-6">
                     <div className="grid grid-cols-2 gap-x-8 gap-y-4 text-sm border-b border-slate-100 pb-6">
                        <div><span className="block text-xs text-slate-400 uppercase font-bold mb-1">Employee</span><span className="font-bold text-slate-800">{getEmployee(selectedRecord.employeeId)?.firstName} {getEmployee(selectedRecord.employeeId)?.lastName}</span></div>
                        <div><span className="block text-xs text-slate-400 uppercase font-bold mb-1">Position</span><span className="font-medium text-slate-700">{getEmployee(selectedRecord.employeeId)?.position}</span></div>
                        <div><span className="block text-xs text-slate-400 uppercase font-bold mb-1">Bank</span><span className="font-mono text-slate-600">{getEmployee(selectedRecord.employeeId)?.bankName} {getEmployee(selectedRecord.employeeId)?.bankAccountNumber}</span></div>
                        <div><span className="block text-xs text-slate-400 uppercase font-bold mb-1">Date</span><span className="font-mono text-slate-600">{selectedRecord.paymentDate || 'Pending'}</span></div>
                     </div>
                     <div className="grid grid-cols-2 gap-8">
                        <div>
                           <h4 className="font-bold text-green-700 mb-3 uppercase text-xs tracking-wider border-b border-green-200 pb-1">Earnings</h4>
                           <div className="space-y-2 text-sm">
                              <div className="flex justify-between"><span className="text-slate-600">Base Salary</span><span className="font-mono font-bold">{formatCurrency(selectedRecord.baseSalary)}</span></div>
                              {selectedRecord.ot > 0 && <div className="flex justify-between"><span className="text-slate-600">OT</span><span className="font-mono">{formatCurrency(selectedRecord.ot)}</span></div>}
                              {selectedRecord.positionAllowance && <div className="flex justify-between"><span className="text-slate-600">Position</span><span className="font-mono">{formatCurrency(selectedRecord.positionAllowance)}</span></div>}
                              {selectedRecord.travelAllowance && <div className="flex justify-between"><span className="text-slate-600">Travel</span><span className="font-mono">{formatCurrency(selectedRecord.travelAllowance)}</span></div>}
                              {selectedRecord.perDiem && <div className="flex justify-between"><span className="text-slate-600">Per Diem</span><span className="font-mono">{formatCurrency(selectedRecord.perDiem)}</span></div>}
                              {selectedRecord.diligenceAllowance && <div className="flex justify-between"><span className="text-slate-600">Diligence</span><span className="font-mono">{formatCurrency(selectedRecord.diligenceAllowance)}</span></div>}
                              {selectedRecord.bonus && selectedRecord.bonus > 0 && <div className="flex justify-between"><span className="text-slate-600">Bonus</span><span className="font-mono">{formatCurrency(selectedRecord.bonus)}</span></div>}
                              {selectedRecord.expenses && selectedRecord.expenses > 0 && <div className="flex justify-between"><span className="text-slate-600">Expenses</span><span className="font-mono">{formatCurrency(selectedRecord.expenses)}</span></div>}
                              {selectedRecord.manualAdjustment && selectedRecord.manualAdjustment > 0 && <div className="flex justify-between"><span className="text-slate-600">Adjustment</span><span className="font-mono">{formatCurrency(selectedRecord.manualAdjustment)}</span></div>}
                           </div>
                        </div>
                        <div>
                           <h4 className="font-bold text-red-700 mb-3 uppercase text-xs tracking-wider border-b border-red-200 pb-1">Deductions</h4>
                           <div className="space-y-2 text-sm">
                              {selectedRecord.socialSecurity > 0 && <div className="flex justify-between"><span className="text-slate-600">SSO</span><span className="font-mono text-red-500">-{formatCurrency(selectedRecord.socialSecurity)}</span></div>}
                              {selectedRecord.tax > 0 && <div className="flex justify-between"><span className="text-slate-600">Tax</span><span className="font-mono text-red-500">-{formatCurrency(selectedRecord.tax)}</span></div>}
                              {selectedRecord.lateDeduction > 0 && <div className="flex justify-between"><span className="text-slate-600">Late</span><span className="font-mono text-red-500">-{formatCurrency(selectedRecord.lateDeduction)}</span></div>}
                              {selectedRecord.absentDeduction > 0 && <div className="flex justify-between"><span className="text-slate-600">Absent</span><span className="font-mono text-red-500">-{formatCurrency(selectedRecord.absentDeduction)}</span></div>}
                              {selectedRecord.unpaidLeaveDeduction > 0 && <div className="flex justify-between"><span className="text-slate-600">Unpaid Leave</span><span className="font-mono text-red-500">-{formatCurrency(selectedRecord.unpaidLeaveDeduction)}</span></div>}
                              {selectedRecord.otherDeduction > 0 && <div className="flex justify-between"><span className="text-slate-600">Other Deduct</span><span className="font-mono text-red-500">-{formatCurrency(selectedRecord.otherDeduction)}</span></div>}
                              {selectedRecord.manualAdjustment && selectedRecord.manualAdjustment < 0 && <div className="flex justify-between"><span className="text-slate-600">Adjustment</span><span className="font-mono text-red-500">-{formatCurrency(Math.abs(selectedRecord.manualAdjustment))}</span></div>}
                           </div>
                        </div>
                     </div>
                     <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex justify-between items-center">
                        <div><span className="block text-xs font-bold text-slate-400 uppercase">Net Pay</span><span className="text-xs text-slate-500">เงินได้สุทธิ</span></div>
                        <div className="text-2xl font-bold text-slate-800 font-mono border-b-2 border-double border-slate-300">{formatCurrency(selectedRecord.netTotal)}</div>
                     </div>
                  </div>
               </div>
               <div className="p-5 border-t border-slate-100 bg-white flex justify-end gap-3">
                  <button onClick={() => setShowPayslipModal(false)} className="px-5 py-2 bg-slate-800 text-white rounded-xl font-bold text-sm shadow-lg hover:bg-slate-700">Close</button>
               </div>
            </div>
         </div>
      )}
    </div>
  );
};
