
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Employee, Post, Task, TaskStatus, TaskPriority, TeamMessage, Channel, ChecklistItem, TaskComment, Role } from '../types';
import { Send, ThumbsUp, MessageSquare, MoreHorizontal, Layout, CheckSquare, Plus, Clock, Hash, Search, User, Trash2, Filter, Paperclip, Smile, Image as ImageIcon, CheckCircle2, X, Edit2, Check, Copy, FilePlus, Link as LinkIcon, Paperclip as AttachmentIcon, ListChecks, Calendar, Tag, ChevronDown, Users, GripVertical, Settings, LogOut, Crown, Lock, Megaphone } from 'lucide-react';

interface CollaborationProps {
  employees: Employee[];
  posts: Post[];
  tasks: Task[];
  teamMessages: TeamMessage[];
  channels: Channel[];
  onAddPost: (content: string, isAnnouncement: boolean) => void;
  onLikePost: (postId: string) => void;
  onCommentPost: (postId: string, content: string) => void;
  onAddTask: (task: Task) => void;
  onUpdateTaskStatus: (taskId: string, status: TaskStatus) => void;
  onDeleteTask: (taskId: string) => void;
  onUpdateTask?: (task: Task) => void; 
  onSendMessage: (content: string, channelId?: string, receiverId?: string) => void;
  onAddChannel: (channel: Channel) => void;
  onUpdateChannel: (channel: Channel) => void;
  onDeleteChannel: (channelId: string) => void;
  currentUser: Employee;
}

export const Collaboration: React.FC<CollaborationProps> = ({ 
  employees, posts, tasks, teamMessages, channels,
  onAddPost, onLikePost, onCommentPost, onAddTask, onUpdateTaskStatus, onDeleteTask, onUpdateTask, onSendMessage,
  onAddChannel, onUpdateChannel, onDeleteChannel, currentUser
}) => {
  const [activeTab, setActiveTab] = useState<'feed' | 'tasks' | 'chat'>('feed');
  
  // Post State
  const [content, setContent] = useState('');
  const [isAnnouncement, setIsAnnouncement] = useState(false);
  const [activeCommentBox, setActiveCommentBox] = useState<string | null>(null);
  const [commentText, setCommentText] = useState('');

  // Task State
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null); 
  const [taskFilter, setTaskFilter] = useState<'all' | 'my'>('all');
  const [newTaskTitle, setNewTaskTitle] = useState('');
  
  // Drag and Drop State
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
  const [dragOverColumn, setDragOverColumn] = useState<TaskStatus | null>(null);

  // Chat State
  const [selectedChatId, setSelectedChatId] = useState<string>('general');
  const [chatType, setChatType] = useState<'channel' | 'direct'>('channel');
  const [chatInput, setChatInput] = useState('');
  const [msgSearchTerm, setMsgSearchTerm] = useState('');
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const [contextMenu, setContextMenu] = useState<{ x: number, y: number, message: TeamMessage | null } | null>(null);

  // Channel Management State
  const [showChannelModal, setShowChannelModal] = useState(false);
  const [channelModalMode, setChannelModalMode] = useState<'create' | 'edit'>('create');
  const [editingChannel, setEditingChannel] = useState<Partial<Channel>>({});
  const [memberSearchTerm, setMemberSearchTerm] = useState('');

  // Task Detail Local States
  const [checklistInput, setChecklistInput] = useState('');
  const [commentInput, setCommentInput] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [showTagInput, setShowTagInput] = useState(false);
  const [showCollaboratorSelect, setShowCollaboratorSelect] = useState(false); 

  const canPostAnnouncement = [Role.CEO, Role.HR_MANAGER, Role.MANAGER, Role.SUPER_ADMIN].includes(currentUser.role);

  // --- Sync Selected Task with Parent State ---
  useEffect(() => {
    if (selectedTask) {
      const freshTask = tasks.find(t => t.id === selectedTask.id);
      if (freshTask && JSON.stringify(freshTask) !== JSON.stringify(selectedTask)) {
        setSelectedTask(freshTask);
      }
    }
  }, [tasks, selectedTask]);

  const getAuthor = (id: string) => employees.find(e => e.id === id);
  const getAssignee = (id: string) => employees.find(e => e.id === id);
  const getEmployee = (id: string) => employees.find(e => e.id === id);
  const getCurrentChannel = () => channels.find(c => c.id === selectedChatId);

  // --- Task Logic ---
  const handleUpdateField = (field: keyof Task, value: any) => {
    if (!selectedTask || !onUpdateTask) return;
    const updated = { ...selectedTask, [field]: value };
    onUpdateTask(updated); 
  };

  const handleDragStart = (e: React.DragEvent, taskId: string) => {
    setDraggedTaskId(taskId);
    e.dataTransfer.setData('taskId', taskId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent, status: TaskStatus) => {
    e.preventDefault(); 
    if (dragOverColumn !== status) {
        setDragOverColumn(status);
    }
  };

  const handleDrop = (e: React.DragEvent, status: TaskStatus) => {
    e.preventDefault();
    setDragOverColumn(null);
    const taskId = e.dataTransfer.getData('taskId');
    
    if (taskId && onUpdateTaskStatus) {
        onUpdateTaskStatus(taskId, status);
    }
    setDraggedTaskId(null);
  };

  const handleQuickComplete = (e: React.MouseEvent, task: Task) => {
      e.stopPropagation();
      const newStatus = task.status === 'Done' ? 'Todo' : 'Done';
      onUpdateTaskStatus(task.id, newStatus);
  };

  const handleAddCollaborator = (empId: string) => {
    if (!selectedTask) return;
    const current = selectedTask.collaboratorIds || [];
    if (!current.includes(empId)) {
        handleUpdateField('collaboratorIds', [...current, empId]);
    }
    setShowCollaboratorSelect(false);
  };

  const handleRemoveCollaborator = (empId: string) => {
    if (!selectedTask) return;
    const current = selectedTask.collaboratorIds || [];
    handleUpdateField('collaboratorIds', current.filter(id => id !== empId));
  };

  // Checklist Actions
  const handleAddChecklist = () => {
     if (!selectedTask || !checklistInput.trim()) return;
     const newItem: ChecklistItem = {
        id: `cl-${Date.now()}`,
        text: checklistInput,
        completed: false
     };
     const updatedChecklist = [...(selectedTask.checklist || []), newItem];
     handleUpdateField('checklist', updatedChecklist);
     setChecklistInput('');
  };

  const handleUpdateChecklistItem = (itemId: string, text: string) => {
     if (!selectedTask) return;
     const updatedChecklist = (selectedTask.checklist || []).map(item => 
        item.id === itemId ? { ...item, text } : item
     );
     setSelectedTask({ ...selectedTask, checklist: updatedChecklist });
     if (onUpdateTask) onUpdateTask({ ...selectedTask, checklist: updatedChecklist });
  };

  const handleToggleChecklist = (itemId: string) => {
     if (!selectedTask) return;
     const updatedChecklist = (selectedTask.checklist || []).map(item => 
        item.id === itemId ? { ...item, completed: !item.completed } : item
     );
     handleUpdateField('checklist', updatedChecklist);
  };

  const handleDeleteChecklist = (itemId: string) => {
     if (!selectedTask) return;
     const updatedChecklist = (selectedTask.checklist || []).filter(item => item.id !== itemId);
     handleUpdateField('checklist', updatedChecklist);
  };

  const handleChecklistKeyDown = (e: React.KeyboardEvent, itemId: string) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (!selectedTask) return;
      const currentIndex = selectedTask.checklist.findIndex(i => i.id === itemId);
      const newItem: ChecklistItem = { id: `cl-${Date.now()}`, text: '', completed: false };
      const newChecklist = [...selectedTask.checklist];
      newChecklist.splice(currentIndex + 1, 0, newItem);
      handleUpdateField('checklist', newChecklist);
    }
    if (e.key === 'Backspace' && (e.target as HTMLInputElement).value === '') {
       e.preventDefault();
       handleDeleteChecklist(itemId);
    }
  };

  const handleAddComment = () => {
     if (!selectedTask || !commentInput.trim()) return;
     const newComment: TaskComment = {
        id: `cm-${Date.now()}`,
        authorId: currentUser.id,
        content: commentInput,
        timestamp: new Date().toISOString()
     };
     const updatedComments = [...(selectedTask.comments || []), newComment];
     handleUpdateField('comments', updatedComments);
     setCommentInput('');
  };

  const handleMentionClick = (userId: string) => {
    const emp = getEmployee(userId);
    if (emp) {
      setCommentInput(prev => `${prev}@${emp.firstName} `);
    }
  };

  const handleAddTag = () => {
    if (!selectedTask || !tagInput.trim()) return;
    const currentTags = selectedTask.tags || [];
    if (!currentTags.includes(tagInput.trim())) {
      handleUpdateField('tags', [...currentTags, tagInput.trim()]);
    }
    setTagInput('');
    setShowTagInput(false);
  };

  const handleRemoveTag = (tagToRemove: string) => {
    if (!selectedTask) return;
    const updatedTags = (selectedTask.tags || []).filter(t => t !== tagToRemove);
    handleUpdateField('tags', updatedTags);
  };

  const handleAddAttachmentMock = () => {
    if (!selectedTask) return;
    const mockUrl = `https://example.com/file-${Date.now()}.pdf`;
    const updatedAttachments = [...(selectedTask.attachments || []), mockUrl];
    handleUpdateField('attachments', updatedAttachments);
  };

  const handleQuickAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTaskTitle.trim()) {
       const task: Task = {
         id: `T${Date.now()}`,
         orgId: currentUser.orgId,
         title: newTaskTitle,
         description: '',
         assigneeId: currentUser.id,
         reporterId: currentUser.id,
         collaboratorIds: [],
         dueDate: new Date().toISOString().split('T')[0],
         status: 'Todo',
         priority: 'Medium',
         createdAt: new Date().toISOString(),
         checklist: [],
         comments: [],
         tags: [],
         attachments: []
       };
       onAddTask(task);
       setNewTaskTitle('');
    }
  };

  // --- Chat Logic ---
  const filteredMessages = useMemo(() => {
    let msgs = [];
    if (chatType === 'channel') {
      msgs = teamMessages.filter(m => m.channelId === selectedChatId);
    } else {
      msgs = teamMessages.filter(m => 
        (m.senderId === currentUser.id && m.receiverId === selectedChatId) ||
        (m.senderId === selectedChatId && m.receiverId === currentUser.id)
      );
    }
    if (msgSearchTerm) {
      return msgs.filter(m => m.content.toLowerCase().includes(msgSearchTerm.toLowerCase()));
    }
    return msgs;
  }, [teamMessages, selectedChatId, chatType, currentUser.id, msgSearchTerm]);

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    if (chatType === 'channel') {
      onSendMessage(chatInput, selectedChatId, undefined);
    } else {
      onSendMessage(chatInput, undefined, selectedChatId);
    }
    setChatInput('');
  };

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (content.trim()) {
      onAddPost(content, isAnnouncement);
      setContent('');
      setIsAnnouncement(false);
    }
  };

  const handleCommentSubmit = (postId: string) => {
    if (commentText.trim()) {
        onCommentPost(postId, commentText);
        setCommentText('');
    }
  };

  const handleContextMenu = (e: React.MouseEvent, msg: TeamMessage) => {
    e.preventDefault();
    setContextMenu({ x: e.clientX, y: e.clientY, message: msg });
  };

  useEffect(() => {
    const handleClick = () => {
       setContextMenu(null);
       setShowCollaboratorSelect(false); 
    };
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  useEffect(() => {
    if (activeTab === 'chat') {
      chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [teamMessages, activeTab, selectedChatId]);

  // --- Channel Management Handlers ---
  const openCreateChannelModal = () => {
    setChannelModalMode('create');
    setEditingChannel({
      name: '',
      description: '',
      memberIds: [currentUser.id], 
      ownerId: currentUser.id,
      isPrivate: false
    });
    setMemberSearchTerm('');
    setShowChannelModal(true);
  };

  const openEditChannelModal = (channel: Channel) => {
    setChannelModalMode('edit');
    setEditingChannel({ ...channel }); 
    setMemberSearchTerm('');
    setShowChannelModal(true);
  };

  const toggleChannelMember = (empId: string) => {
    const currentMembers = editingChannel.memberIds || [];
    if (currentMembers.includes(empId)) {
      setEditingChannel({ ...editingChannel, memberIds: currentMembers.filter(id => id !== empId) });
    } else {
      setEditingChannel({ ...editingChannel, memberIds: [...currentMembers, empId] });
    }
  };

  const handleSaveChannel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingChannel.name) return;

    if (channelModalMode === 'create') {
      const newChannel: Channel = {
        id: `C${Date.now()}`,
        orgId: currentUser.orgId,
        name: editingChannel.name,
        description: editingChannel.description || '',
        ownerId: currentUser.id,
        memberIds: editingChannel.memberIds || [currentUser.id],
        isPrivate: editingChannel.isPrivate || false,
        avatarUrl: `https://ui-avatars.com/api/?name=${editingChannel.name}&background=random`
      };
      onAddChannel(newChannel);
    } else {
      if (editingChannel.id) {
        onUpdateChannel(editingChannel as Channel);
      }
    }
    setShowChannelModal(false);
  };

  const handleDeleteCurrentChannel = () => {
    if (editingChannel.id) {
      if (confirm('คุณแน่ใจหรือไม่ที่จะลบกลุ่มนี้? การกระทำนี้ไม่สามารถย้อนกลับได้')) {
        onDeleteChannel(editingChannel.id);
        setShowChannelModal(false);
        setSelectedChatId('general'); 
      }
    }
  };

  const getPriorityColor = (p: TaskPriority) => {
    switch (p) {
      case 'High': return 'bg-red-50 text-red-600 border-red-100';
      case 'Medium': return 'bg-amber-50 text-amber-600 border-amber-100';
      case 'Low': return 'bg-blue-50 text-blue-600 border-blue-100';
      default: return 'bg-slate-50 text-slate-600';
    }
  };

  return (
    <div className="h-[calc(100vh-140px)] flex flex-col animate-fade-in gap-4">
       {/* Tab Switcher */}
       <div className="flex bg-white p-1 rounded-xl shadow-sm border border-slate-200 self-start">
          <button onClick={() => setActiveTab('feed')} className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-colors ${activeTab === 'feed' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:bg-slate-50'}`}>
            <Layout size={16} /> ข่าวสาร (Feed)
          </button>
          <button onClick={() => setActiveTab('chat')} className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-colors ${activeTab === 'chat' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:bg-slate-50'}`}>
            <MessageSquare size={16} /> แชททีม (Chat)
          </button>
          <button onClick={() => setActiveTab('tasks')} className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-colors ${activeTab === 'tasks' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:bg-slate-50'}`}>
            <CheckSquare size={16} /> งาน (Tasks)
          </button>
       </div>

       {activeTab === 'chat' && (
         <div className="flex flex-1 overflow-hidden bg-white rounded-2xl border border-slate-200 shadow-sm">
           {/* Sidebar */}
           <div className="w-64 bg-slate-50 border-r border-slate-200 flex flex-col">
              <div className="p-4 border-b border-slate-200 flex justify-between items-center">
                 <h3 className="font-bold text-slate-700">ห้องสนทนา (Channels)</h3>
                 <button onClick={openCreateChannelModal} className="text-slate-400 hover:text-indigo-600 p-1 hover:bg-indigo-50 rounded"><Plus size={18}/></button>
              </div>
              <div className="flex-1 overflow-y-auto p-2 space-y-1">
                 {channels.map(ch => (
                    <button 
                      key={ch.id} 
                      onClick={() => { setSelectedChatId(ch.id); setChatType('channel'); }}
                      className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors ${selectedChatId === ch.id && chatType === 'channel' ? 'bg-white shadow-sm text-indigo-600 font-bold' : 'text-slate-600 hover:bg-slate-100'}`}
                    >
                       <span className="text-slate-400">#</span> {ch.name}
                       {ch.isPrivate && <Lock size={12} className="ml-auto text-slate-400" />}
                    </button>
                 ))}
                 <div className="mt-6 px-3 text-xs font-bold text-slate-400 uppercase tracking-wider">ข้อความส่วนตัว (Direct Message)</div>
                 {employees.filter(e => e.id !== currentUser.id).map(emp => (
                    <button 
                      key={emp.id} 
                      onClick={() => { setSelectedChatId(emp.id); setChatType('direct'); }}
                      className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors ${selectedChatId === emp.id && chatType === 'direct' ? 'bg-white shadow-sm text-indigo-600 font-bold' : 'text-slate-600 hover:bg-slate-100'}`}
                    >
                       <div className="relative">
                          <img src={emp.avatarUrl} className="w-6 h-6 rounded-full" />
                          <div className="absolute bottom-0 right-0 w-2 h-2 bg-green-500 border border-white rounded-full"></div>
                       </div>
                       {emp.firstName}
                    </button>
                 ))}
              </div>
           </div>
           
           {/* Chat Area */}
           <div className="flex-1 flex flex-col">
              <div className="h-16 border-b border-slate-200 flex items-center justify-between px-6 bg-white/80 backdrop-blur">
                 <div className="flex items-center gap-3">
                    {chatType === 'channel' ? (
                       <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center font-bold text-lg">#</div>
                    ) : (
                       <img src={getEmployee(selectedChatId)?.avatarUrl} className="w-10 h-10 rounded-full" />
                    )}
                    <div>
                       <h3 className="font-bold text-slate-800 flex items-center gap-2">
                          {chatType === 'channel' ? getCurrentChannel()?.name : `${getEmployee(selectedChatId)?.firstName}`}
                          {chatType === 'channel' && (
                             <button 
                               onClick={() => openEditChannelModal(getCurrentChannel()!)} 
                               className="text-slate-300 hover:text-indigo-600 transition-colors"
                             >
                                <Settings size={14} />
                             </button>
                          )}
                       </h3>
                       {chatType === 'channel' && <p className="text-xs text-slate-400">{getCurrentChannel()?.memberIds?.length} members</p>}
                    </div>
                 </div>
                 <div className="relative">
                    <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                      type="text" 
                      placeholder="ค้นหาข้อความ..." 
                      value={msgSearchTerm}
                      onChange={(e) => setMsgSearchTerm(e.target.value)}
                      className="pl-9 pr-4 py-1.5 bg-slate-50 border border-slate-200 rounded-full text-xs focus:ring-1 focus:ring-indigo-500 outline-none w-48"
                    />
                 </div>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50/50">
                 {filteredMessages.map(msg => {
                    const isMe = msg.senderId === currentUser.id;
                    const sender = getAuthor(msg.senderId);
                    return (
                       <div key={msg.id} className={`flex gap-3 ${isMe ? 'flex-row-reverse' : ''} group`} onContextMenu={(e) => handleContextMenu(e, msg)}>
                          <img src={sender?.avatarUrl} className="w-8 h-8 rounded-full self-end mb-1" />
                          <div className={`max-w-[70%] rounded-2xl px-4 py-3 text-sm relative ${isMe ? 'bg-indigo-600 text-white rounded-br-sm' : 'bg-white border border-slate-200 text-slate-700 rounded-bl-sm'}`}>
                             {!isMe && chatType === 'channel' && <div className="text-[10px] font-bold text-indigo-600 mb-1">{sender?.firstName}</div>}
                             {msg.content}
                             <div className={`text-[10px] mt-1 text-right opacity-70 ${isMe ? 'text-indigo-200' : 'text-slate-400'}`}>
                                {new Date(msg.timestamp).toLocaleTimeString('th-TH', {hour:'2-digit', minute:'2-digit'})}
                             </div>
                          </div>
                       </div>
                    );
                 })}
                 <div ref={chatBottomRef} />
              </div>

              <div className="p-4 bg-white border-t border-slate-200">
                 <form onSubmit={handleSendChat} className="flex gap-2 items-end bg-slate-50 p-2 rounded-xl border border-slate-200">
                    <button type="button" className="p-2 text-slate-400 hover:text-indigo-600"><Paperclip size={20} /></button>
                    <textarea 
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyDown={(e) => { if(e.key === 'Enter' && !e.shiftKey) handleSendChat(e); }}
                      placeholder="พิมพ์ข้อความ..."
                      className="flex-1 bg-transparent border-none focus:ring-0 outline-none text-sm max-h-32 resize-none py-2"
                      rows={1}
                    />
                    <button type="submit" disabled={!chatInput.trim()} className="p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 transition-colors shadow-sm">
                       <Send size={18} />
                    </button>
                 </form>
              </div>
           </div>
         </div>
       )}

       {/* --- CHANNEL MANAGEMENT MODAL --- */}
       {showChannelModal && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
             <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-fade-in-up">
                <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                   <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                      {channelModalMode === 'create' ? <Plus size={20} className="text-indigo-600"/> : <Edit2 size={20} className="text-indigo-600"/>}
                      {channelModalMode === 'create' ? 'สร้างกลุ่มใหม่ (Create Group)' : 'ตั้งค่ากลุ่ม (Group Settings)'}
                   </h3>
                   <button onClick={() => setShowChannelModal(false)} className="text-slate-400 hover:text-slate-600 transition-colors"><X size={20}/></button>
                </div>
                
                <div className="p-6 space-y-6">
                   {/* Name & Description */}
                   <div className="space-y-4">
                      <div>
                         <label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase">ชื่อกลุ่ม (Group Name)</label>
                         <input 
                           type="text" 
                           className="w-full border border-slate-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" 
                           placeholder="Ex. Marketing Team" 
                           value={editingChannel.name}
                           onChange={e => setEditingChannel({...editingChannel, name: e.target.value})}
                         />
                      </div>
                      <div>
                         <label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase">คำอธิบาย (Description)</label>
                         <input 
                           type="text" 
                           className="w-full border border-slate-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" 
                           placeholder="Optional description" 
                           value={editingChannel.description}
                           onChange={e => setEditingChannel({...editingChannel, description: e.target.value})}
                         />
                      </div>
                   </div>

                   <div className="h-px bg-slate-100"></div>

                   {/* Member Management */}
                   <div>
                      <div className="flex justify-between items-end mb-2">
                         <label className="block text-xs font-bold text-slate-500 uppercase">สมาชิก ({editingChannel.memberIds?.length || 0})</label>
                         <div className="relative">
                            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                            <input 
                              type="text" 
                              placeholder="ค้นหา..." 
                              className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
                              value={memberSearchTerm}
                              onChange={e => setMemberSearchTerm(e.target.value)}
                            />
                         </div>
                      </div>
                      
                      <div className="border border-slate-200 rounded-xl overflow-hidden h-48 overflow-y-auto custom-scrollbar bg-slate-50/30">
                         {employees
                           .filter(e => e.firstName.toLowerCase().includes(memberSearchTerm.toLowerCase()) || e.lastName.toLowerCase().includes(memberSearchTerm.toLowerCase()))
                           .map(emp => {
                              const isMember = editingChannel.memberIds?.includes(emp.id);
                              const isOwner = editingChannel.ownerId === emp.id;
                              
                              return (
                                 <div key={emp.id} className="flex items-center justify-between p-3 hover:bg-slate-50 transition-colors border-b border-slate-100 last:border-0">
                                    <div className="flex items-center gap-3">
                                       <div className="relative">
                                          <img src={emp.avatarUrl} className="w-8 h-8 rounded-full border border-slate-200" />
                                          {isOwner && (
                                             <div className="absolute -top-1 -right-1 bg-amber-400 text-white rounded-full p-0.5 border border-white" title="Group Owner">
                                                <Crown size={8} fill="currentColor" />
                                             </div>
                                          )}
                                       </div>
                                       <div>
                                          <div className="text-sm font-bold text-slate-700">{emp.firstName} {emp.lastName}</div>
                                          <div className="text-[10px] text-slate-400">{emp.position}</div>
                                       </div>
                                    </div>
                                    
                                    <div className="flex items-center gap-2">
                                       {/* Owner Transfer (Only visible in Edit Mode and if Current User is Owner) */}
                                       {channelModalMode === 'edit' && editingChannel.ownerId === currentUser.id && isMember && !isOwner && (
                                          <button 
                                            onClick={() => setEditingChannel({...editingChannel, ownerId: emp.id})}
                                            className="p-1.5 text-slate-300 hover:text-amber-500 hover:bg-amber-50 rounded-lg transition-colors"
                                            title="Make Owner"
                                          >
                                             <Crown size={14} />
                                          </button>
                                       )}
                                       
                                       <button 
                                          type="button"
                                          onClick={() => toggleChannelMember(emp.id)}
                                          className={`w-6 h-6 rounded-full flex items-center justify-center border transition-all ${isMember ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white border-slate-300 text-transparent hover:border-indigo-400'}`}
                                       >
                                          <Check size={12} strokeWidth={4} />
                                       </button>
                                    </div>
                                 </div>
                              );
                           })}
                      </div>
                   </div>
                </div>

                <div className="p-5 border-t border-slate-100 bg-slate-50 flex justify-between items-center">
                   {channelModalMode === 'edit' ? (
                      <button 
                        type="button" 
                        onClick={handleDeleteCurrentChannel}
                        className="text-red-500 hover:text-red-700 text-sm font-bold flex items-center gap-2 px-3 py-2 hover:bg-red-50 rounded-lg transition-colors"
                      >
                         <Trash2 size={16} /> ลบกลุ่ม
                      </button>
                   ) : <div></div>}
                   
                   <div className="flex gap-3">
                      <button onClick={() => setShowChannelModal(false)} className="px-5 py-2 text-slate-600 hover:bg-slate-200 rounded-xl font-bold text-sm transition-colors">ยกเลิก</button>
                      <button onClick={handleSaveChannel} className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-sm shadow-lg shadow-indigo-200 transition-all active:scale-95">
                         {channelModalMode === 'create' ? 'สร้างกลุ่ม' : 'บันทึก'}
                      </button>
                   </div>
                </div>
             </div>
          </div>
       )}

       {activeTab === 'feed' && (
          <div className="max-w-2xl mx-auto w-full space-y-6">
             <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                <div className="flex gap-4">
                   <img src={currentUser.avatarUrl} className="w-10 h-10 rounded-full" />
                   <div className="flex-1">
                      <textarea 
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                        placeholder="มีอะไรใหม่? (What's on your mind?)" 
                        className="w-full border-none focus:ring-0 text-slate-700 placeholder:text-slate-400 text-lg resize-none h-20"
                      />
                      <div className="flex justify-between items-center pt-2 border-t border-slate-100">
                         <div className="flex gap-2 items-center">
                            <div className="flex gap-1 text-slate-400 border-r border-slate-200 pr-2 mr-2">
                                <button className="hover:text-indigo-600 p-1.5 hover:bg-slate-50 rounded-full"><ImageIcon size={20} /></button>
                                <button className="hover:text-indigo-600 p-1.5 hover:bg-slate-50 rounded-full"><Smile size={20} /></button>
                            </div>
                            
                            {/* Announcement Toggle */}
                            {canPostAnnouncement && (
                                <label className="flex items-center gap-2 cursor-pointer text-sm text-slate-600 hover:text-indigo-600 select-none">
                                    <input 
                                        type="checkbox" 
                                        checked={isAnnouncement} 
                                        onChange={e => setIsAnnouncement(e.target.checked)} 
                                        className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
                                    />
                                    <span className="flex items-center gap-1 font-bold">
                                        <Megaphone size={16} className={isAnnouncement ? "text-indigo-600" : "text-slate-400"} /> 
                                        ประกาศแจ้งเตือน (Notify All)
                                    </span>
                                </label>
                            )}
                         </div>
                         <button onClick={handlePostSubmit} disabled={!content.trim()} className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-bold text-sm hover:bg-indigo-700 transition-colors disabled:opacity-50 shadow-md">
                            โพสต์ (Post)
                         </button>
                      </div>
                   </div>
                </div>
             </div>
             
             <div className="space-y-4">
                {posts.map(post => {
                   const isLiked = post.likedBy.includes(currentUser.id);
                   const author = getAuthor(post.authorId);
                   return (
                       <div key={post.id} className={`bg-white p-6 rounded-2xl shadow-sm border ${post.isAnnouncement ? 'border-purple-200 bg-purple-50/10' : 'border-slate-200'}`}>
                          {post.isAnnouncement && (
                              <div className="flex items-center gap-2 text-xs font-bold text-purple-600 mb-3 bg-purple-50 w-fit px-2 py-1 rounded-lg">
                                  <Megaphone size={12} /> ประกาศ (Announcement)
                              </div>
                          )}
                          <div className="flex justify-between items-start mb-4">
                             <div className="flex gap-3">
                                <img src={author?.avatarUrl} className="w-10 h-10 rounded-full border border-slate-100" />
                                <div>
                                   <h4 className="font-bold text-slate-800">{author?.firstName} {author?.lastName}</h4>
                                   <p className="text-xs text-slate-400">{new Date(post.timestamp).toLocaleString('th-TH')}</p>
                                </div>
                             </div>
                          </div>
                          <p className="text-slate-700 leading-relaxed mb-4 whitespace-pre-wrap">{post.content}</p>
                          
                          <div className="flex gap-4 border-t border-slate-100 pt-3">
                             <button 
                                onClick={() => onLikePost(post.id)}
                                className={`flex items-center gap-2 text-sm font-medium transition-colors ${isLiked ? 'text-indigo-600 font-bold' : 'text-slate-500 hover:text-indigo-600'}`}
                             >
                                <ThumbsUp size={18} fill={isLiked ? "currentColor" : "none"} /> {post.likes > 0 ? post.likes : 'ถูกใจ'}
                             </button>
                             <button 
                                onClick={() => setActiveCommentBox(activeCommentBox === post.id ? null : post.id)}
                                className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 text-sm font-medium transition-colors"
                             >
                                <MessageSquare size={18} /> {post.comments.length > 0 ? `${post.comments.length} ความเห็น` : 'แสดงความคิดเห็น'}
                             </button>
                          </div>

                          {/* Comments Section */}
                          {(activeCommentBox === post.id || post.comments.length > 0) && (
                              <div className="mt-4 pt-4 border-t border-slate-50 space-y-3">
                                  {post.comments.map(comment => {
                                      const commentAuthor = getAuthor(comment.authorId);
                                      return (
                                          <div key={comment.id} className="flex gap-3 text-sm">
                                              <img src={commentAuthor?.avatarUrl} className="w-8 h-8 rounded-full" />
                                              <div className="bg-slate-50 rounded-2xl px-4 py-2 flex-1">
                                                  <div className="flex justify-between items-baseline mb-1">
                                                      <span className="font-bold text-slate-700">{commentAuthor?.firstName}</span>
                                                      <span className="text-[10px] text-slate-400">{new Date(comment.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                                  </div>
                                                  <p className="text-slate-600">{comment.content}</p>
                                              </div>
                                          </div>
                                      );
                                  })}
                                  
                                  {/* Add Comment Input */}
                                  {activeCommentBox === post.id && (
                                      <div className="flex gap-3 items-start mt-4 animate-fade-in">
                                          <img src={currentUser.avatarUrl} className="w-8 h-8 rounded-full" />
                                          <div className="flex-1 relative">
                                              <input 
                                                  type="text" 
                                                  placeholder="แสดงความคิดเห็น..." 
                                                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 pr-10"
                                                  value={commentText}
                                                  onChange={e => setCommentText(e.target.value)}
                                                  onKeyDown={e => { if(e.key === 'Enter') handleCommentSubmit(post.id) }}
                                                  autoFocus
                                              />
                                              <button 
                                                  onClick={() => handleCommentSubmit(post.id)}
                                                  disabled={!commentText.trim()}
                                                  className="absolute right-2 top-1/2 -translate-y-1/2 text-indigo-600 hover:text-indigo-700 disabled:opacity-50"
                                              >
                                                  <Send size={16} />
                                              </button>
                                          </div>
                                      </div>
                                  )}
                              </div>
                          )}
                       </div>
                   );
                })}
             </div>
          </div>
       )}

       {/* --- TASKS VIEW --- */}
       {activeTab === 'tasks' && (
         <div className="flex flex-col h-full overflow-hidden">
            <div className="flex justify-between items-center mb-6 px-1">
               <div className="flex items-center gap-3">
                  <div className="flex items-center bg-white rounded-lg p-1 border border-slate-200">
                     <button onClick={() => setTaskFilter('all')} className={`px-3 py-1.5 rounded-md text-sm font-bold transition-all ${taskFilter === 'all' ? 'bg-slate-100 text-slate-800' : 'text-slate-500 hover:text-slate-700'}`}>งานทั้งหมด (All Tasks)</button>
                     <button onClick={() => setTaskFilter('my')} className={`px-3 py-1.5 rounded-md text-sm font-bold transition-all ${taskFilter === 'my' ? 'bg-slate-100 text-slate-800' : 'text-slate-500 hover:text-slate-700'}`}>งานของฉัน (My Tasks)</button>
                  </div>
                  <form onSubmit={handleQuickAddTask} className="hidden md:flex items-center gap-2">
                     <input 
                        type="text" 
                        placeholder="+ เพิ่มงานใหม่..." 
                        value={newTaskTitle}
                        onChange={e => setNewTaskTitle(e.target.value)}
                        className="bg-transparent border-b border-transparent hover:border-slate-300 focus:border-indigo-500 outline-none text-sm px-2 py-1 transition-colors w-64"
                     />
                  </form>
               </div>
               <button onClick={() => { setNewTaskTitle(''); setShowTaskModal(true); }} className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-bold text-sm hover:bg-indigo-700 flex items-center gap-2 shadow-sm">
                  <Plus size={16} /> งานใหม่
               </button>
            </div>
            
            <div className="flex-1 overflow-x-auto">
               <div className="flex gap-6 h-full min-w-[1000px] pb-4">
                  {[{id: 'Todo', label: 'งานใหม่ (To Do)'}, {id: 'In Progress', label: 'กำลังทำ (In Progress)'}, {id: 'Done', label: 'เสร็จสิ้น (Done)'}].map((statusItem) => (
                     <div 
                        key={statusItem.id} 
                        className={`flex-1 flex flex-col bg-slate-50 rounded-2xl border transition-colors duration-200 max-w-sm ${dragOverColumn === statusItem.id ? 'border-indigo-400 bg-indigo-50/50' : 'border-slate-200/60'}`}
                        onDragOver={(e) => handleDragOver(e, statusItem.id as TaskStatus)}
                        onDrop={(e) => handleDrop(e, statusItem.id as TaskStatus)}
                     >
                        <div className="p-4 flex justify-between items-center border-b border-slate-100 bg-white/50 rounded-t-2xl">
                           <h3 className="font-bold text-slate-700 flex items-center gap-2">
                              <span className={`w-2.5 h-2.5 rounded-full ${statusItem.id === 'Todo' ? 'bg-slate-400' : statusItem.id === 'In Progress' ? 'bg-blue-500' : 'bg-green-500'}`}></span>
                              {statusItem.label}
                           </h3>
                           <span className="bg-slate-200 text-slate-600 text-xs font-bold px-2 py-0.5 rounded-full">
                              {tasks.filter(t => t.status === statusItem.id && (taskFilter === 'all' || t.assigneeId === currentUser.id)).length}
                           </span>
                        </div>
                        <div className="p-3 space-y-3 overflow-y-auto flex-1 custom-scrollbar">
                           {tasks.filter(t => t.status === statusItem.id && (taskFilter === 'all' || t.assigneeId === currentUser.id)).map(task => (
                              <div 
                                 key={task.id} 
                                 draggable
                                 onDragStart={(e) => handleDragStart(e, task.id)}
                                 onClick={() => setSelectedTask(task)}
                                 className={`bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all group cursor-pointer relative ${draggedTaskId === task.id ? 'opacity-50 scale-95 rotate-1' : ''}`}
                              >
                                 <div className="flex flex-wrap gap-2 mb-2 pr-6">
                                    {task.tags && task.tags.map(tag => (
                                       <span key={tag} className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-500">{tag}</span>
                                    ))}
                                 </div>
                                 
                                 {/* Quick Complete Button */}
                                 <button 
                                    onClick={(e) => handleQuickComplete(e, task)}
                                    className={`absolute top-3 right-3 p-1 rounded-full transition-all duration-200 ${task.status === 'Done' ? 'text-green-500 hover:bg-green-50' : 'text-slate-300 hover:text-green-500 hover:bg-green-50'}`}
                                    title={task.status === 'Done' ? "Mark as Incomplete" : "Mark as Complete"}
                                 >
                                    <CheckCircle2 size={18} fill={task.status === 'Done' ? "currentColor" : "none"} className={task.status === 'Done' ? "text-green-500" : ""} />
                                 </button>

                                 <h4 className={`font-bold text-slate-800 text-sm mb-1 leading-snug ${task.status === 'Done' ? 'line-through text-slate-400' : ''}`}>{task.title}</h4>
                                 
                                 <div className="flex items-center gap-3 mt-3 text-slate-400 text-xs">
                                    {task.checklist && task.checklist.length > 0 && (
                                       <div className="flex items-center gap-1" title="Checklist Progress">
                                          <CheckSquare size={12} />
                                          <span>{task.checklist.filter(i => i.completed).length}/{task.checklist.length}</span>
                                       </div>
                                    )}
                                    {task.comments && task.comments.length > 0 && (
                                       <div className="flex items-center gap-1">
                                          <MessageSquare size={12} /> {task.comments.length}
                                       </div>
                                    )}
                                    {task.attachments && task.attachments.length > 0 && (
                                       <div className="flex items-center gap-1">
                                          <Paperclip size={12} /> {task.attachments.length}
                                       </div>
                                    )}
                                 </div>

                                 <div className="flex justify-between items-center pt-3 border-t border-slate-50 mt-2">
                                    <div className="flex -space-x-2">
                                       <img src={getAssignee(task.assigneeId)?.avatarUrl} className="w-6 h-6 rounded-full border-2 border-white" title={`Assignee: ${getAssignee(task.assigneeId)?.firstName}`} />
                                    </div>
                                    <div className={`text-[10px] flex items-center gap-1 px-2 py-0.5 rounded ${new Date(task.dueDate) < new Date() && task.status !== 'Done' ? 'bg-red-50 text-red-600' : 'bg-slate-50 text-slate-500'}`}>
                                       <Clock size={10} /> {new Date(task.dueDate).toLocaleDateString('th-TH', {day: 'numeric', month: 'short'})}
                                    </div>
                                 </div>
                              </div>
                           ))}
                           {statusItem.id === 'Todo' && (
                              <button 
                                 onClick={() => { setNewTaskTitle(''); setShowTaskModal(true); }}
                                 className="w-full py-3 border-2 border-dashed border-slate-200 rounded-xl text-slate-400 text-sm font-bold hover:border-indigo-300 hover:text-indigo-500 hover:bg-indigo-50/50 transition-all flex items-center justify-center gap-2"
                              >
                                 <Plus size={16} /> เพิ่มการ์ดใหม่
                              </button>
                           )}
                        </div>
                     </div>
                  ))}
               </div>
            </div>
         </div>
       )}

       {/* Create Task Modal */}
       {showTaskModal && (
         <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
            <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 animate-fade-in-up">
               <h3 className="text-xl font-bold mb-4">สร้างงานมอบหมายใหม่</h3>
               <form onSubmit={handleQuickAddTask} className="space-y-4">
                  <div>
                     <label className="text-xs font-bold text-slate-500 mb-1 block">หัวข้อภาระงาน</label>
                     <input required type="text" placeholder="ระบุหัวข้อ..." className="w-full border rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" value={newTaskTitle} onChange={e => setNewTaskTitle(e.target.value)} />
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                     <button type="button" onClick={() => setShowTaskModal(false)} className="px-4 py-2 text-slate-500 hover:bg-slate-50 rounded-xl font-bold text-sm">ยกเลิก</button>
                     <button type="submit" className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold text-sm hover:bg-indigo-700">สร้างงาน</button>
                  </div>
               </form>
            </div>
         </div>
       )}

       {/* --- TASK DETAIL MODAL (LARK STYLE) --- */}
       {selectedTask && (
          <div 
            className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-[60] backdrop-blur-sm"
            onClick={() => setSelectedTask(null)}
          >
             <div 
               className="bg-white rounded-xl shadow-2xl w-full max-w-5xl h-[85vh] flex overflow-hidden animate-in zoom-in-95 duration-200"
               onClick={(e) => e.stopPropagation()}
             >
                
                {/* LEFT: Main Content */}
                <div className="flex-1 flex flex-col overflow-y-auto custom-scrollbar bg-white">
                   {/* Header / Title */}
                   <div className="p-8 pb-4">
                      <div className="flex justify-between items-start mb-4">
                         <div className="flex items-center gap-2">
                            {/* Tags Area */}
                            {selectedTask.tags?.map(tag => (
                               <span key={tag} className="text-[10px] font-bold px-2 py-1 rounded bg-slate-100 text-slate-600 flex items-center gap-1 group border border-slate-200">
                                  {tag}
                                  <button onClick={() => handleRemoveTag(tag)} className="hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"><X size={10} /></button>
                               </span>
                            ))}
                            {showTagInput ? (
                               <input 
                                 autoFocus
                                 type="text" 
                                 className="text-[10px] border border-slate-300 rounded px-2 py-1 w-20 outline-none"
                                 value={tagInput}
                                 onChange={e => setTagInput(e.target.value)}
                                 onKeyDown={e => { if(e.key === 'Enter') handleAddTag() }}
                                 onBlur={() => setShowTagInput(false)}
                               />
                            ) : (
                               <button onClick={() => setShowTagInput(true)} className="text-[10px] text-slate-400 hover:text-blue-600 flex items-center gap-1 px-2 py-1 rounded hover:bg-slate-50 transition-colors border border-dashed border-slate-300">
                                  <Plus size={10} /> Add Tag
                               </button>
                            )}
                         </div>
                         <div className="flex gap-2">
                            <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"><LinkIcon size={18}/></button>
                            <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"><MoreHorizontal size={18}/></button>
                            <button onClick={() => setSelectedTask(null)} className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors ml-2"><X size={20}/></button>
                         </div>
                      </div>
                      
                      <div className="mb-4">
                         <input 
                           type="text" 
                           value={selectedTask.title} 
                           onChange={e => handleUpdateField('title', e.target.value)}
                           className="text-3xl font-bold text-slate-800 w-full border-none outline-none placeholder:text-slate-300 bg-transparent focus:ring-0 px-0"
                           placeholder="Task Title"
                         />
                      </div>

                      {/* Meta Row (Lark style properties) */}
                      <div className="flex flex-wrap gap-6 items-center">
                         {/* Assignee */}
                         <div className="flex items-center gap-2 group relative">
                            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 border border-dashed border-slate-300 group-hover:border-blue-400 transition-colors overflow-hidden">
                               {getAssignee(selectedTask.assigneeId) ? (
                                  <img src={getAssignee(selectedTask.assigneeId)?.avatarUrl} className="w-full h-full object-cover" />
                               ) : <User size={14} />}
                            </div>
                            <div className="flex flex-col">
                               <span className="text-[10px] font-bold text-slate-400 uppercase">ผู้รับผิดชอบ</span>
                               <select 
                                 className="text-sm font-medium text-slate-700 bg-transparent outline-none cursor-pointer appearance-none hover:text-blue-600 pr-4"
                                 value={selectedTask.assigneeId}
                                 onChange={(e) => handleUpdateField('assigneeId', e.target.value)}
                               >
                                  {employees.map(e => <option key={e.id} value={e.id}>{e.firstName}</option>)}
                               </select>
                            </div>
                         </div>

                         {/* Due Date */}
                         <div className="flex items-center gap-2 group">
                            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 border border-dashed border-slate-300 group-hover:border-blue-400 transition-colors">
                               <Calendar size={14} />
                            </div>
                            <div className="flex flex-col">
                               <span className="text-[10px] font-bold text-slate-400 uppercase">กำหนดส่ง</span>
                               <input 
                                 type="date" 
                                 value={selectedTask.dueDate} 
                                 onChange={e => handleUpdateField('dueDate', e.target.value)}
                                 className="text-sm font-medium text-slate-700 bg-transparent outline-none cursor-pointer hover:text-blue-600 font-mono"
                               />
                            </div>
                         </div>

                         {/* Collaborators Section (New) */}
                         <div className="flex items-center gap-2 group relative">
                            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 border border-dashed border-slate-300 group-hover:border-blue-400 transition-colors">
                               <Users size={14} />
                            </div>
                            <div className="flex flex-col relative">
                               <span className="text-[10px] font-bold text-slate-400 uppercase">ผู้ร่วมงาน</span>
                               <div className="flex items-center gap-1 mt-0.5">
                                  {selectedTask.collaboratorIds?.map((id, index) => {
                                     const col = getEmployee(id);
                                     if (!col) return null;
                                     return (
                                        <div key={id} className="relative w-5 h-5 group/collab">
                                           <img 
                                             src={col.avatarUrl} 
                                             className="w-full h-full rounded-full border border-white shadow-sm object-cover" 
                                             title={col.firstName}
                                           />
                                           <button 
                                             onClick={() => handleRemoveCollaborator(id)}
                                             className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-2.5 h-2.5 flex items-center justify-center opacity-0 group-hover/collab:opacity-100 transition-opacity"
                                           >
                                              <X size={6} strokeWidth={4} />
                                           </button>
                                        </div>
                                     );
                                  })}
                                  <button 
                                    onClick={(e) => { e.stopPropagation(); setShowCollaboratorSelect(!showCollaboratorSelect); }}
                                    className="w-5 h-5 rounded-full bg-slate-100 border border-dashed border-slate-300 flex items-center justify-center text-slate-400 hover:text-blue-600 hover:border-blue-300 text-[10px] transition-colors"
                                  >
                                     <Plus size={10} />
                                  </button>
                               </div>

                               {/* Collaborator Dropdown */}
                               {showCollaboratorSelect && (
                                  <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-100 py-1 z-50 animate-in fade-in zoom-in-95 duration-200">
                                     <div className="px-3 py-2 border-b border-slate-50">
                                        <input 
                                          autoFocus
                                          type="text" 
                                          placeholder="Search..." 
                                          className="w-full text-xs outline-none bg-transparent"
                                          onClick={e => e.stopPropagation()}
                                        />
                                     </div>
                                     <div className="max-h-40 overflow-y-auto custom-scrollbar">
                                        {employees.filter(e => e.id !== selectedTask.assigneeId && !(selectedTask.collaboratorIds || []).includes(e.id)).map(emp => (
                                           <button 
                                             key={emp.id}
                                             onClick={(e) => { e.stopPropagation(); handleAddCollaborator(emp.id); }}
                                             className="w-full flex items-center gap-2 px-3 py-2 hover:bg-slate-50 text-left transition-colors"
                                           >
                                              <img src={emp.avatarUrl} className="w-5 h-5 rounded-full" />
                                              <span className="text-xs font-medium text-slate-700 truncate">{emp.firstName}</span>
                                           </button>
                                        ))}
                                     </div>
                                  </div>
                               )}
                            </div>
                         </div>

                         {/* Status */}
                         <div className="flex flex-col">
                            <span className="text-[10px] font-bold text-slate-400 uppercase mb-0.5">สถานะ</span>
                            <select 
                               value={selectedTask.status}
                               onChange={(e) => handleUpdateField('status', e.target.value)}
                               className={`px-2 py-1 rounded text-xs font-bold uppercase tracking-wider border cursor-pointer outline-none ${
                               selectedTask.status === 'Done' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-blue-100 text-blue-700 border-blue-200'
                            }`}>
                               <option value="Todo">งานใหม่ (Todo)</option>
                               <option value="In Progress">กำลังทำ (In Progress)</option>
                               <option value="Done">เสร็จสิ้น (Done)</option>
                            </select>
                         </div>

                         {/* Priority */}
                         <div className="flex flex-col">
                            <span className="text-[10px] font-bold text-slate-400 uppercase mb-0.5">ความสำคัญ</span>
                            <select 
                               value={selectedTask.priority}
                               onChange={(e) => handleUpdateField('priority', e.target.value)}
                               className={`px-2 py-1 rounded text-xs font-bold uppercase tracking-wider border cursor-pointer outline-none ${getPriorityColor(selectedTask.priority)}`}>
                               <option value="Low">ต่ำ (Low)</option>
                               <option value="Medium">ปานกลาง (Medium)</option>
                               <option value="High">สูง (High)</option>
                            </select>
                         </div>
                      </div>
                   </div>

                   <div className="h-px bg-slate-100 w-full mb-6"></div>

                   {/* Body */}
                   <div className="px-8 pb-8 space-y-8">
                      {/* Description */}
                      <div className="group">
                         <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                            <FilePlus size={14}/> รายละเอียด (Description)
                         </h4>
                         <textarea 
                           className="w-full min-h-[120px] text-slate-700 text-sm leading-relaxed resize-none border-none outline-none focus:ring-0 placeholder:text-slate-300 bg-transparent p-0"
                           placeholder="Add a detailed description..."
                           value={selectedTask.description}
                           onChange={e => handleUpdateField('description', e.target.value)}
                         />
                      </div>

                      {/* Checklist */}
                      <div>
                         <div className="flex justify-between items-center mb-3">
                            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
                               <ListChecks size={14}/> รายการเช็ค (Checklist) ({selectedTask.checklist?.filter(i => i.completed).length || 0}/{selectedTask.checklist?.length || 0})
                            </h4>
                         </div>
                         
                         {/* Progress Bar */}
                         {(selectedTask.checklist?.length || 0) > 0 && (
                            <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden mb-4">
                               <div 
                                 className="h-full bg-green-500 transition-all duration-500" 
                                 style={{ width: `${(selectedTask.checklist!.filter(i => i.completed).length / selectedTask.checklist!.length) * 100}%` }}
                               ></div>
                            </div>
                         )}

                         <div className="space-y-1">
                            {selectedTask.checklist?.map(item => (
                               <div key={item.id} className="flex items-start gap-3 group hover:bg-slate-50 p-1.5 -mx-1.5 rounded transition-colors">
                                  <button 
                                    onClick={() => handleToggleChecklist(item.id)}
                                    className={`mt-0.5 shrink-0 w-5 h-5 rounded border flex items-center justify-center transition-all duration-200 ${item.completed ? 'bg-blue-600 border-blue-600 text-white' : 'bg-white border-slate-300 hover:border-blue-500'}`}
                                  >
                                     {item.completed && <Check size={12} strokeWidth={3} />}
                                  </button>
                                  {/* Editable Input */}
                                  <input
                                    type="text"
                                    className={`text-sm flex-1 bg-transparent outline-none border-none p-0 focus:ring-0 ${item.completed ? 'text-slate-400 line-through' : 'text-slate-700'}`}
                                    value={item.text}
                                    onChange={(e) => handleUpdateChecklistItem(item.id, e.target.value)}
                                    onKeyDown={(e) => handleChecklistKeyDown(e, item.id)}
                                  />
                                  <button 
                                    onClick={() => handleDeleteChecklist(item.id)}
                                    className="opacity-0 group-hover:opacity-100 text-slate-300 hover:text-red-500 transition-opacity p-1"
                                  >
                                     <Trash2 size={14} />
                                  </button>
                               </div>
                            ))}
                            
                            {/* Add Item Input */}
                            <div className="flex items-center gap-3 mt-2 pl-1.5">
                               <Plus size={16} className="text-slate-400 shrink-0" />
                               <input 
                                 type="text" 
                                 placeholder="Add an item..." 
                                 className="flex-1 text-sm bg-transparent outline-none placeholder:text-slate-400 py-1"
                                 value={checklistInput}
                                 onChange={e => setChecklistInput(e.target.value)}
                                 onKeyDown={e => { if(e.key === 'Enter') handleAddChecklist() }}
                               />
                            </div>
                         </div>
                      </div>

                      {/* Attachments */}
                      <div>
                         <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                            <AttachmentIcon size={14}/> ไฟล์แนบ (Attachments)
                         </h4>
                         <div className="flex flex-wrap gap-3">
                            {selectedTask.attachments?.map((att, idx) => (
                               <a href={att} key={idx} target="_blank" className="flex items-center gap-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-blue-600 hover:underline hover:bg-blue-50 transition-colors">
                                  <LinkIcon size={12}/> File {idx+1}
                               </a>
                            ))}
                            <button onClick={handleAddAttachmentMock} className="flex items-center gap-2 px-3 py-2 bg-white border border-dashed border-slate-300 rounded-lg text-xs font-bold text-slate-500 hover:border-slate-400 hover:text-slate-700 transition-colors">
                               <Plus size={12}/> Add File
                            </button>
                         </div>
                      </div>
                   </div>
                </div>

                {/* RIGHT: Activity & Comments */}
                <div className="w-96 bg-white border-l border-slate-200 flex flex-col">
                   <div className="p-4 border-b border-slate-200">
                      <h4 className="font-bold text-slate-700 text-sm">กิจกรรม (Activity)</h4>
                   </div>
                   
                   <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-6">
                      {/* Comments List */}
                      {selectedTask.comments?.map(comment => {
                         const author = getAuthor(comment.authorId);
                         return (
                            <div key={comment.id} className="flex gap-3 items-start animate-fade-in-up group">
                               <img src={author?.avatarUrl} className="w-8 h-8 rounded-full border border-slate-200 mt-1" />
                               <div className="flex-1 min-w-0">
                                  <div className="flex justify-between items-baseline">
                                     <span className="text-xs font-bold text-slate-800">{author?.firstName}</span>
                                     <span className="text-[10px] text-slate-400">{new Date(comment.timestamp).toLocaleTimeString('th-TH', {hour:'2-digit', minute:'2-digit'})}</span>
                                  </div>
                                  <div className="text-sm text-slate-600 mt-1 leading-relaxed break-words">
                                     {comment.content}
                                  </div>
                               </div>
                            </div>
                         );
                      })}
                      {(!selectedTask.comments || selectedTask.comments.length === 0) && (
                         <div className="flex flex-col items-center justify-center h-full text-slate-400 opacity-60">
                            <p className="text-xs">No activity yet.</p>
                         </div>
                      )}
                   </div>

                   {/* Comment Input */}
                   <div className="p-4 border-t border-slate-200 bg-white">
                      <div className="relative border border-slate-200 rounded-xl bg-white shadow-sm focus-within:ring-2 focus-within:ring-indigo-100 transition-all">
                         <textarea 
                           className="w-full rounded-xl p-3 text-sm outline-none resize-none pr-10 bg-transparent min-h-[50px] max-h-[120px]"
                           rows={2}
                           placeholder="Write a comment... (@ to mention)"
                           value={commentInput}
                           onChange={e => setCommentInput(e.target.value)}
                           onKeyDown={e => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleAddComment(); }}}
                         />
                         <button 
                           onClick={handleAddComment}
                           disabled={!commentInput.trim()}
                           className="absolute right-2 bottom-2 p-1.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 transition-colors shadow-sm"
                         >
                            <Send size={14} />
                         </button>
                      </div>
                      <div className="flex gap-2 mt-2 overflow-x-auto pb-1 no-scrollbar">
                         {employees.slice(0, 3).map(emp => (
                            <button key={emp.id} onClick={() => handleMentionClick(emp.id)} className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded hover:bg-slate-200 whitespace-nowrap transition-colors">
                               @{emp.firstName}
                            </button>
                         ))}
                      </div>
                   </div>
                </div>

             </div>
          </div>
       )}
       
       {/* Context Menu for Chat */}
       {contextMenu && (
          <div className="fixed bg-white shadow-xl rounded-xl border border-slate-100 py-1 z-50 w-48 animate-in fade-in zoom-in duration-100" style={{ top: contextMenu.y, left: contextMenu.x }}>
             <button onClick={() => { /* Task logic */ }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2">
                <CheckSquare size={14} /> สร้างงานจากข้อความ
             </button>
             <button onClick={() => { navigator.clipboard.writeText(contextMenu.message?.content || ''); setContextMenu(null); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-2">
                <Copy size={14} /> คัดลอกข้อความ
             </button>
          </div>
       )}
    </div>
  );
};
