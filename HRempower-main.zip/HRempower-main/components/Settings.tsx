
import React, { useState, useEffect } from 'react';
import { CompanySettings, Employee, Role, LeaveType, EmploymentTypeConfig, EmploymentConditionRule, OTRateConfig, NotificationSettings, NotificationRule, PermissionKey, RolePermissions, CheckInLocation } from '../types';
import { DEFAULT_ROLE_PERMISSIONS } from '../constants'; 
import { Permissions } from '../utils/permissions';
import { Building, MapPin, Clock, Shield, Save, Lock, Calendar, Trash2, Plus, AlertCircle, Briefcase, CheckCircle2, DollarSign, Calculator, Upload, Globe, Edit2, Coins, ExternalLink, Locate, Wifi, Monitor, Bell, Key, RefreshCcw, Eye, MousePointer2, CheckSquare, Info, Sparkles, AlertTriangle, RotateCcw, Undo2, Ban, Phone, Mail, Hash, Map } from 'lucide-react';

interface SettingsProps {
  settings: CompanySettings;
  onSaveSettings: (settings: CompanySettings) => void;
  currentUser: Employee;
}

const getColorClasses = (color: string) => {
  const map: any = {
    blue: { bg: 'bg-blue-500', text: 'text-blue-600', ring: 'focus:ring-blue-500', light: 'bg-blue-50', border: 'border-blue-200' },
    orange: { bg: 'bg-orange-500', text: 'text-orange-600', ring: 'focus:ring-orange-500', light: 'bg-orange-50', border: 'border-orange-200' },
    indigo: { bg: 'bg-indigo-500', text: 'text-indigo-600', ring: 'focus:ring-indigo-500', light: 'bg-indigo-50', border: 'border-indigo-200' },
    amber: { bg: 'bg-amber-500', text: 'text-amber-600', ring: 'focus:ring-amber-500', light: 'bg-amber-50', border: 'border-amber-200' },
    red: { bg: 'bg-red-500', text: 'text-red-600', ring: 'focus:ring-red-500', light: 'bg-red-50', border: 'border-red-200' },
    green: { bg: 'bg-green-500', text: 'text-green-600', ring: 'focus:ring-green-500', light: 'bg-green-50', border: 'border-green-200' },
  };
  return map[color] || map.blue;
};

// Helper UI for OT Rate Configuration Card
const OTRateConfigCard = ({ 
  title, 
  color, 
  items,
  selectedType,
  updateOTRule
}: { 
  title: string, 
  color: string, 
  items: { key: keyof EmploymentTypeConfig['conditions']['ot']['rates'], label: string }[],
  selectedType: EmploymentTypeConfig | undefined,
  updateOTRule: (rateKey: keyof EmploymentTypeConfig['conditions']['ot']['rates'], updates: Partial<OTRateConfig>) => void
}) => {
  if (!selectedType) return null;
  const styles = getColorClasses(color);
  
  return (
    <div className={`border border-slate-200 rounded-xl bg-white overflow-hidden shadow-sm hover:shadow-md transition-shadow`}>
       <div className={`px-4 py-3 border-b border-slate-100 flex items-center gap-2 bg-slate-50`}>
          <div className={`w-2.5 h-2.5 rounded-full ${styles.bg}`}></div> 
          <span className="font-bold text-slate-700 text-sm">{title}</span>
       </div>
       <div className="p-4 space-y-5">
         {items.map((item) => {
            const config = selectedType.conditions.ot.rates[item.key];
            return (
               <div key={item.key}>
                  <div className="flex justify-between items-center mb-2">
                     <label className="text-xs font-bold text-slate-500 uppercase tracking-wide">{item.label}</label>
                  </div>
                  <div className="space-y-2">
                     {/* Mode Switcher */}
                     <div className="flex bg-slate-100 p-1 rounded-lg">
                        <button 
                          type="button"
                          onClick={() => updateOTRule(item.key, { mode: 'Multiplier' })}
                          className={`flex-1 py-1.5 px-2 rounded-md text-[10px] font-bold transition-all ${config.mode === 'Multiplier' ? `bg-white ${styles.text} shadow-sm ring-1 ring-slate-200` : 'text-slate-400 hover:text-slate-600'}`}
                        >
                           คูณเท่า (Multiplier)
                        </button>
                        <button 
                          type="button"
                          onClick={() => updateOTRule(item.key, { mode: 'Fixed' })}
                          className={`flex-1 py-1.5 px-2 rounded-md text-[10px] font-bold transition-all ${config.mode === 'Fixed' ? `bg-white ${styles.text} shadow-sm ring-1 ring-slate-200` : 'text-slate-400 hover:text-slate-600'}`}
                        >
                           เหมาจ่าย (Fixed)
                        </button>
                     </div>
                     
                     {/* Input */}
                     <div className="relative">
                        <input 
                          type="number" 
                          className={`w-full border rounded-lg p-2 text-sm font-bold text-right pr-12 outline-none focus:ring-2 ${styles.ring} focus:border-transparent ${config.mode === 'Multiplier' ? 'border-slate-300 text-slate-700' : 'border-slate-300 text-slate-700'}`}
                          value={config.rate}
                          onChange={(e) => updateOTRule(item.key, { rate: Number(e.target.value) })}
                          step={config.mode === 'Multiplier' ? 0.1 : 10}
                        />
                        <span className={`absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold ${config.mode === 'Multiplier' ? 'text-slate-400' : 'text-slate-400'}`}>
                           {config.mode === 'Multiplier' ? 'เท่า' : 'THB'}
                        </span>
                     </div>
                  </div>
               </div>
            );
         })}
       </div>
    </div>
  );
};

// Helper UI for Notification Row
const NotificationRow = ({ label, category, settingKey, rule, toggleNotificationRule }: { label: string, category: 'probation' | 'general', settingKey: string, rule: NotificationRule, toggleNotificationRule: (category: 'probation' | 'general', key: string, field: keyof NotificationRule, value: boolean) => void }) => (
  <div className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-xl hover:shadow-sm transition-all group">
     <div className="flex items-center gap-4">
        {/* Main Toggle */}
        <label className="relative inline-flex items-center cursor-pointer">
           <input 
             type="checkbox" 
             checked={rule.enabled} 
             onChange={(e) => toggleNotificationRule(category, settingKey, 'enabled', e.target.checked)} 
             className="sr-only peer" 
           />
           <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
        </label>
        <span className={`font-bold text-sm ${rule.enabled ? 'text-slate-800' : 'text-slate-400'}`}>{label}</span>
     </div>

     {/* Recipient Checkboxes */}
     <div className={`flex gap-6 items-center transition-opacity duration-300 ${rule.enabled ? 'opacity-100' : 'opacity-40 pointer-events-none'}`}>
        <label className="flex items-center gap-2 cursor-pointer hover:text-blue-600 transition-colors">
           <input 
              type="checkbox" 
              checked={rule.notifyHR} 
              onChange={(e) => toggleNotificationRule(category, settingKey, 'notifyHR', e.target.checked)}
              className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
           />
           <span className="text-xs font-medium text-slate-600">HR</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer hover:text-blue-600 transition-colors">
           <input 
              type="checkbox" 
              checked={rule.notifyManager} 
              onChange={(e) => toggleNotificationRule(category, settingKey, 'notifyManager', e.target.checked)}
              className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
           />
           <span className="text-xs font-medium text-slate-600">Manager</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer hover:text-blue-600 transition-colors">
           <input 
              type="checkbox" 
              checked={rule.notifyEmployee} 
              onChange={(e) => toggleNotificationRule(category, settingKey, 'notifyEmployee', e.target.checked)}
              className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
           />
           <span className="text-xs font-medium text-slate-600">Employee</span>
        </label>
     </div>
  </div>
);

export const Settings: React.FC<SettingsProps> = ({ settings, onSaveSettings, currentUser }) => {
  const [activeTab, setActiveTab] = useState<'company' | 'time' | 'leave' | 'location' | 'employment' | 'notifications' | 'permissions'>('company');
  const [formData, setFormData] = useState<CompanySettings>(() => {
    const existingPerms = settings.rolePermissions || [];
    const mergedPermissions = DEFAULT_ROLE_PERMISSIONS.map(defaultRoleConfig => {
       const existingRoleConfig = existingPerms.find(p => p.role === defaultRoleConfig.role);
       if (existingRoleConfig) {
          return { ...existingRoleConfig, permissions: existingRoleConfig.permissions || [] };
       }
       return defaultRoleConfig;
    });
    
    // Ensure locations array exists (migration)
    const initialLocations = settings.locations || (settings.gpsLatitude ? [{
        id: 'LOC_DEFAULT',
        name: 'สำนักงานใหญ่ (Default)',
        lat: settings.gpsLatitude,
        lng: settings.gpsLongitude,
        radius: settings.gpsRadiusMeters || 500
    }] : []);

    return { ...settings, rolePermissions: mergedPermissions, locations: initialLocations };
  });

  const [showSaveSuccess, setShowSaveSuccess] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  
  // LOCKOUT STATE: Check if user removed their own rights
  const [isLockingOut, setIsLockingOut] = useState(false);

  // Check for unsaved changes & lockout risk
  useEffect(() => {
     const isDirty = JSON.stringify(formData) !== JSON.stringify(settings);
     setHasUnsavedChanges(isDirty);

     // Check Anti-Lockout
     const myRole = currentUser.role;
     if (myRole !== Role.SUPER_ADMIN) { // Super Admin bypasses this
        const myPerms = formData.rolePermissions.find(p => p.role === myRole);
        const hasSettingsManage = myPerms?.permissions.includes('settings_manage');
        setIsLockingOut(!hasSettingsManage);
     }
  }, [formData, settings, currentUser]);

  // Local states
  const [newHoliday, setNewHoliday] = useState({ date: '', name: '' });
  const [newLeaveType, setNewLeaveType] = useState({ name: '', quota: 30 });
  const [selectedTypeId, setSelectedTypeId] = useState<string>(formData.employmentTypes?.[0]?.id || '');
  const [conditionTab, setConditionTab] = useState<'late' | 'absent' | 'missing' | 'early'>('late');
  
  // Location States
  const [selectedLocId, setSelectedLocId] = useState<string | null>(formData.locations.length > 0 ? formData.locations[0].id : null);
  const [editingLoc, setEditingLoc] = useState<CheckInLocation | null>(null);

  useEffect(() => {
     if(selectedLocId) {
        const found = formData.locations.find(l => l.id === selectedLocId);
        if(found) setEditingLoc({...found});
     } else if (formData.locations.length > 0) {
        setSelectedLocId(formData.locations[0].id);
     }
  }, [selectedLocId, formData.locations]);

  const canEdit = Permissions.canEditCompanySettings(currentUser.role, formData.rolePermissions);

  // Derived state for Employment Tab
  const selectedType = formData.employmentTypes.find(t => t.id === selectedTypeId);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleToggleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: checked }));
  };

  // Handlers
  const handleDayToggle = (day: string) => { setFormData(prev => { const exists = prev.workDays.includes(day); if (exists) { return { ...prev, workDays: prev.workDays.filter(d => d !== day) }; } else { return { ...prev, workDays: [...prev.workDays, day] }; } }); };
  
  // --- HOLIDAY HANDLERS (INTEGRATED) ---
  const handleAddHoliday = () => { if (newHoliday.date && newHoliday.name) { setFormData(prev => ({ ...prev, publicHolidays: [...prev.publicHolidays, { id: `H${Date.now()}`, ...newHoliday }] })); setNewHoliday({ date: '', name: '' }); } };
  const handleDeleteHoliday = (id: string) => { setFormData(prev => ({ ...prev, publicHolidays: prev.publicHolidays.filter(h => h.id !== id) })); };
  
  const handleQuotaChange = (type: string, quota: number) => { setFormData(prev => ({ ...prev, leaveQuotas: prev.leaveQuotas.map(q => q.type === type ? { ...q, quota } : q) })); };
  const handleAddLeaveType = () => { if (newLeaveType.name && newLeaveType.quota > 0) { if (formData.leaveQuotas.some(q => q.type === newLeaveType.name)) { alert('ชื่อการลานี้มีอยู่แล้ว'); return; } setFormData(prev => ({ ...prev, leaveQuotas: [...prev.leaveQuotas, { type: newLeaveType.name, quota: newLeaveType.quota }] })); setNewLeaveType({ name: '', quota: 30 }); } };
  const handleDeleteLeaveType = (typeName: string) => { if (confirm(`คุณแน่ใจหรือไม่ที่จะลบประเภทการลา "${typeName}"?`)) { setFormData(prev => ({ ...prev, leaveQuotas: prev.leaveQuotas.filter(q => q.type !== typeName) })); } };
  
  const handleAddEmploymentType = (type: 'Monthly' | 'Daily') => { 
      const newId = `ET${Date.now()}`; 
      const newType: EmploymentTypeConfig = { 
          id: newId, 
          name: type === 'Monthly' ? 'พนักงานรายเดือน (ใหม่)' : 'พนักงานรายวัน (ใหม่)', 
          nameEn: type === 'Monthly' ? 'New Monthly Staff' : 'New Daily Staff', 
          paymentType: type, 
          salaryBasis: type === 'Monthly' ? 'Standard30' : 'ActualDays', 
          otBasis: type === 'Monthly' ? 'Salary' : 'Custom', 
          conditions: { 
              ot: { enabled: true, rates: { otNormal: { mode: 'Multiplier', rate: 1.5 }, workDayOff: { mode: 'Multiplier', rate: 1.0 }, otDayOff: { mode: 'Multiplier', rate: 3.0 }, workPublicHoliday: { mode: 'Multiplier', rate: 1.0 }, otPublicHoliday: { mode: 'Multiplier', rate: 3.0 } } }, 
              late: type === 'Monthly' ? { action: 'None', calculationMode: 'ProRated', enabled: true } : { action: 'DeductSalary', calculationMode: 'Fixed', fixedAmount: 50, enabled: true }, 
              absent: { action: 'DeductSalary', calculationMode: 'ProRated', enabled: true }, 
              missingPunch: type === 'Monthly' ? { action: 'None', calculationMode: 'Fixed', enabled: true } : { action: 'DeductSalary', calculationMode: 'Fixed', fixedAmount: 100, enabled: true }, 
              earlyLeave: { action: 'None', calculationMode: 'ProRated', enabled: false } 
          }, 
          calculateTax: type === 'Monthly', 
          calculateSSO: true 
      }; 
      setFormData(prev => ({ ...prev, employmentTypes: [...prev.employmentTypes, newType] })); 
      setSelectedTypeId(newId); 
  };

  const updateSelectedType = (updates: Partial<EmploymentTypeConfig>) => { setFormData(prev => ({ ...prev, employmentTypes: prev.employmentTypes.map(t => t.id === selectedTypeId ? { ...t, ...updates } : t) })); };
  const updateCondition = (condKey: keyof EmploymentTypeConfig['conditions'], updates: Partial<EmploymentConditionRule>) => { setFormData(prev => ({ ...prev, employmentTypes: prev.employmentTypes.map(t => { if (t.id === selectedTypeId) { return { ...t, conditions: { ...t.conditions, [condKey]: { ...t.conditions[condKey], ...updates } } }; } return t; }) })); };
  const updateOTRule = (rateKey: keyof EmploymentTypeConfig['conditions']['ot']['rates'], updates: Partial<OTRateConfig>) => { setFormData(prev => ({ ...prev, employmentTypes: prev.employmentTypes.map(t => { if (t.id === selectedTypeId) { return { ...t, conditions: { ...t.conditions, ot: { ...t.conditions.ot, rates: { ...t.conditions.ot.rates, [rateKey]: { ...t.conditions.ot.rates[rateKey], ...updates } } } } }; } return t; }) })); };
  const toggleNotificationRule = (category: 'probation' | 'general', key: string, field: keyof NotificationRule, value: boolean) => { setFormData(prev => ({ ...prev, notificationSettings: { ...prev.notificationSettings, [category]: { ...prev.notificationSettings[category], [key]: { ...prev.notificationSettings[category][key as any], [field]: value } } } })); };

  // --- PERMISSION LOGIC ---
  const getPermissionLockReason = (role: Role, key: PermissionKey): string | null => {
     if (role === Role.CEO) {
        if (key === 'settings_manage') return "Critical: CEO must manage settings";
        if (key === 'employee_view') return "Critical: CEO must view employees";
        if (key === 'data_view_all') return "Critical: CEO sees all data";
     }
     if (role === Role.HR_MANAGER) {
        if (key === 'employee_view') return "Critical: HR must view employees";
        if (key === 'settings_manage') return "Critical: HR must manage settings";
     }
     return null;
  };

  const togglePermission = (role: Role, key: PermissionKey) => { if (getPermissionLockReason(role, key)) return; setFormData(prev => { const currentPermissions = prev.rolePermissions ? [...prev.rolePermissions] : []; const roleIndex = currentPermissions.findIndex(r => r.role === role); if (roleIndex > -1) { const existingPerms = currentPermissions[roleIndex].permissions || []; let newPerms = existingPerms.includes(key) ? existingPerms.filter(p => p !== key) : [...existingPerms, key]; currentPermissions[roleIndex] = { ...currentPermissions[roleIndex], permissions: newPerms }; } else { currentPermissions.push({ role: role, permissions: [key] }); } return { ...prev, rolePermissions: currentPermissions }; }); };
  const togglePermissionRow = (key: PermissionKey) => { const roles = [Role.CEO, Role.HR_MANAGER, Role.HR_STAFF, Role.MANAGER, Role.STAFF]; setFormData(prev => { const currentPermissions = prev.rolePermissions ? [...prev.rolePermissions] : []; const editableRoles = roles.filter(r => !getPermissionLockReason(r, key)); const allEditableHaveIt = editableRoles.every(r => { const config = currentPermissions.find(cp => cp.role === r); return config?.permissions?.includes(key); }); const updatedPermissions = currentPermissions.map(item => ({...item, permissions: [...(item.permissions || [])]})); roles.forEach(role => { if (getPermissionLockReason(role, key)) return; const roleIndex = updatedPermissions.findIndex(rp => rp.role === role); if (roleIndex > -1) { const currentRolePerms = updatedPermissions[roleIndex].permissions; if (allEditableHaveIt) { updatedPermissions[roleIndex].permissions = currentRolePerms.filter(p => p !== key); } else if (!currentRolePerms.includes(key)) { updatedPermissions[roleIndex].permissions.push(key); } } else if (!allEditableHaveIt) { updatedPermissions.push({ role, permissions: [key] }); } }); return { ...prev, rolePermissions: updatedPermissions }; }); };
  const toggleRoleColumn = (role: Role) => { const allKeys = permissionCategories.flatMap(cat => cat.items.map(i => i.key)); setFormData(prev => { const currentPermissions = prev.rolePermissions ? [...prev.rolePermissions] : []; const roleIndex = currentPermissions.findIndex(r => r.role === role); const updatedPermissions = currentPermissions.map(item => ({...item, permissions: [...(item.permissions || [])]})); if (roleIndex > -1) { const existingRolePerms = updatedPermissions[roleIndex].permissions; const editableKeys = allKeys.filter(k => !getPermissionLockReason(role, k)); const hasAllEditable = editableKeys.every(k => existingRolePerms.includes(k)); if (hasAllEditable) { updatedPermissions[roleIndex].permissions = existingRolePerms.filter(p => !!getPermissionLockReason(role, p as PermissionKey)); } else { const newPerms = new Set([...existingRolePerms, ...editableKeys]); updatedPermissions[roleIndex].permissions = Array.from(newPerms); } } else { const editableKeys = allKeys.filter(k => !getPermissionLockReason(role, k)); updatedPermissions.push({ role, permissions: editableKeys }); } return { ...prev, rolePermissions: updatedPermissions }; }); };
  const resetPermissionRow = (key: PermissionKey) => { setFormData(prev => { const defaultState = DEFAULT_ROLE_PERMISSIONS; const updatedPermissions = (prev.rolePermissions || []).map(roleConfig => { const defaultRoleConfig = defaultState.find(d => d.role === roleConfig.role); const shouldHave = defaultRoleConfig?.permissions?.includes(key); let newPerms = roleConfig.permissions.filter(p => p !== key); if (shouldHave) newPerms.push(key); return { ...roleConfig, permissions: newPerms }; }); return { ...prev, rolePermissions: updatedPermissions }; }); };

  const handleResetPermissions = () => {
    if(confirm("การรีเซ็ตจะล้างค่าสิทธิ์ทั้งหมดให้เป็นค่าว่าง (Clear All) ยกเว้นสิทธิ์ที่ถูกล็อคป้องกันไว้ คุณแน่ใจหรือไม่?")) {
       const resetState: RolePermissions[] = [Role.CEO, Role.HR_MANAGER, Role.HR_STAFF, Role.MANAGER, Role.STAFF].map(role => {
          const allKeys = permissionCategories.flatMap(cat => cat.items.map(i => i.key));
          const lockedKeys = allKeys.filter(k => !!getPermissionLockReason(role, k));
          return { role, permissions: lockedKeys };
       });
       setFormData(prev => ({ ...prev, rolePermissions: resetState }));
    }
  };

  const handleRecommendedPermissions = () => {
    if(!confirm("ระบบจะโหลดค่าแนะนำ (Smart Config) ซึ่งจะแทนที่การตั้งค่าปัจจุบัน\n\nต้องการดำเนินการต่อหรือไม่?")) return;
    const standardPermissions = JSON.parse(JSON.stringify(DEFAULT_ROLE_PERMISSIONS));
    setFormData(prev => ({ ...prev, rolePermissions: standardPermissions }));
  };

  const handleGetCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        if (editingLoc) {
            setEditingLoc({ ...editingLoc, lat: Number(position.coords.latitude.toFixed(6)), lng: Number(position.coords.longitude.toFixed(6)) });
        } else {
            // Update Default / Main GPS if no specific location selected (Legacy fallback)
            setFormData(prev => ({ ...prev, gpsLatitude: Number(position.coords.latitude.toFixed(6)), gpsLongitude: Number(position.coords.longitude.toFixed(6)) }));
        }
      }, (error) => { alert('ไม่สามารถระบุตำแหน่งได้: ' + error.message); });
    } else { alert('เบราว์เซอร์นี้ไม่รองรับการระบุตำแหน่ง'); }
  };

  // Location Handlers
  const handleAddLocation = () => {
     const newLoc: CheckInLocation = {
        id: `LOC_${Date.now()}`,
        name: 'New Location',
        lat: 13.7563,
        lng: 100.5018,
        radius: 500
     };
     const newLocations = [...formData.locations, newLoc];
     setFormData({...formData, locations: newLocations});
     setSelectedLocId(newLoc.id);
     setEditingLoc(newLoc);
  };

  const handleSaveLocation = () => {
     if (editingLoc) {
        const newLocations = formData.locations.map(l => l.id === editingLoc.id ? editingLoc : l);
        setFormData({...formData, locations: newLocations});
        // Also update legacy top-level fields if it's the first location
        if(newLocations.length > 0 && newLocations[0].id === editingLoc.id) {
            setFormData(prev => ({ ...prev, locations: newLocations, gpsLatitude: editingLoc.lat, gpsLongitude: editingLoc.lng, gpsRadiusMeters: editingLoc.radius }));
        }
     }
  };

  // --- LOCATION DELETE HANDLER ---
  const handleDeleteLocation = (id: string) => {
     if(formData.locations.length <= 1) {
        alert("ต้องมีจุดเช็คอินอย่างน้อย 1 จุด (Cannot delete last location)");
        return;
     }
     if(confirm("ลบจุดเช็คอินนี้ใช่หรือไม่?")) {
        const newLocations = formData.locations.filter(l => l.id !== id);
        setFormData({...formData, locations: newLocations});
        
        // Select another location or clear selection if deleted one was selected
        if (selectedLocId === id) {
            const nextLoc = newLocations[0];
            setSelectedLocId(nextLoc.id);
            setEditingLoc(nextLoc);
        }
     }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // --- ANTI-LOCKOUT CHECK ---
    if (isLockingOut) {
       alert("SECURITY ALERT:\n\nคุณกำลังจะปิดสิทธิ์การเข้าถึงเมนู 'Settings' ของบทบาทคุณเอง\nระบบไม่อนุญาตให้บันทึกเพื่อป้องกันการถูกล็อคออกจากระบบ\n\nกรุณาเพิ่มสิทธิ์ 'Company Settings' ให้กับบทบาทของคุณก่อนบันทึก");
       return;
    }

    onSaveSettings(formData);
    setShowSaveSuccess(true);
    setTimeout(() => setShowSaveSuccess(false), 3000);
  };

  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  
  // Define Categories
  const permissionCategories: { title: string, items: { key: PermissionKey, label: string, icon: any, desc: string }[] }[] = [
     {
        title: 'Employee Data (ข้อมูลพนักงาน)',
        items: [
           { key: 'employee_view', label: 'View List', icon: Eye, desc: 'ดูรายชื่อพนักงานเบื้องต้น' },
           { key: 'employee_view_full', label: 'View Full Profile', icon: Lock, desc: 'ดูข้อมูลส่วนตัว/เงินเดือน (Sensitive)' },
           { key: 'employee_create', label: 'Create Employee', icon: Plus, desc: 'เพิ่มพนักงานใหม่' },
           { key: 'employee_edit', label: 'Edit Employee', icon: Edit2, desc: 'แก้ไขข้อมูลพนักงาน' },
           { key: 'employee_delete', label: 'Delete Employee', icon: Trash2, desc: 'ลบข้อมูลพนักงาน' },
        ]
     },
     {
        title: 'Time & Attendance (เวลาเข้างาน)',
        items: [
           { key: 'attendance_view', label: 'View Logs', icon: Clock, desc: 'ดูประวัติการลงเวลา' },
           { key: 'attendance_manage', label: 'Manage/Approve', icon: CheckCircle2, desc: 'แก้ไขเวลา / อนุมัติคำขอแก้เวลา' },
           { key: 'shift_manage', label: 'Manage Shifts', icon: Calendar, desc: 'จัดการตารางงาน/กะงาน' },
        ]
     },
     {
        title: 'Leave Management (การลา)',
        items: [
           { key: 'leave_view', label: 'View Requests', icon: Calendar, desc: 'ดูปฏิทินและประวัติการลา' },
           { key: 'leave_approve', label: 'Approve/Reject', icon: CheckCircle2, desc: 'อนุมัติการลา' },
        ]
     },
     {
        title: 'Payroll (เงินเดือน)',
        items: [
           { key: 'payroll_view', label: 'View Dashboard', icon: DollarSign, desc: 'ดูภาพรวมเงินเดือน' },
           { key: 'payroll_calc', label: 'Calculate & Edit', icon: Calculator, desc: 'คำนวณและแก้ไขยอดเงิน' },
           { key: 'payroll_approve', label: 'Approve Payment', icon: CheckCircle2, desc: 'อนุมัติการจ่ายเงิน' },
           { key: 'payroll_export', label: 'Export Bank File', icon: Upload, desc: 'ส่งออกไฟล์ธนาคาร' },
        ]
     },
     {
        title: 'Performance (ประเมินผล)',
        items: [
           { key: 'goal_view', label: 'View Goals', icon: Locate, desc: 'ดูเป้าหมายองค์กร/ทีม' },
           { key: 'goal_manage', label: 'Manage Goals', icon: Edit2, desc: 'สร้าง/แก้ไขเป้าหมาย' },
           { key: 'review_manage', label: 'Conduct Reviews', icon: Shield, desc: 'ประเมินผลงานพนักงาน' },
        ]
     },
     {
        title: 'System & Admin (ระบบ)',
        items: [
           { key: 'settings_manage', label: 'Company Settings', icon: Key, desc: 'ตั้งค่าบริษัท (วันหยุด, โควตาลา, พิกัด)' },
           { key: 'data_view_all', label: 'View All Data', icon: Globe, desc: 'ดูข้อมูลข้ามแผนก/ทั้งองค์กร' },
           { key: 'announcement_create', label: 'Announcements', icon: Bell, desc: 'สร้างประกาศข่าวสาร' },
        ]
     }
  ];

  if (!canEdit) {
     return (
        <div className="flex flex-col items-center justify-center h-full text-slate-400 p-8 text-center bg-slate-50">
           <Lock size={48} className="mb-4 opacity-20" />
           <h2 className="text-xl font-bold text-slate-600">Access Restricted</h2>
           <p className="text-sm mt-2 max-w-md">คุณไม่มีสิทธิ์ในการแก้ไขการตั้งค่าระบบ กรุณาติดต่อผู้ดูแลระบบหรือฝ่ายบุคคล (Admin Only)</p>
        </div>
     );
  }

  return (
    <div className="flex flex-col h-full bg-slate-50 animate-fade-in relative">
      {/* ... (Header & Sidebar remain same) ... */}
      <div className="px-6 py-4 bg-white border-b border-slate-200 flex justify-between items-center sticky top-0 z-10 shrink-0 shadow-sm">
        <div>
          <h2 className="text-xl font-bold text-slate-800">การตั้งค่า (Settings)</h2>
          <p className="text-xs text-slate-500">จัดการข้อมูลบริษัทและนโยบาย HR</p>
        </div>
        <div className="md:hidden">
           <select className="bg-slate-50 border border-slate-200 rounded-lg p-2 text-sm font-bold text-slate-700 outline-none" value={activeTab} onChange={(e) => setActiveTab(e.target.value as any)}>
             <option value="company">องค์กร</option>
             <option value="time">เวลาทำงาน</option>
             <option value="leave">การลา</option>
             <option value="employment">ประเภทการจ้าง</option>
             <option value="notifications">การแจ้งเตือน</option>
             <option value="permissions">สิทธิ์การใช้งาน</option>
             <option value="location">พิกัด</option>
           </select>
        </div>
      </div>

      <div className="flex flex-1 min-h-0 bg-slate-50/50">
        <div className="hidden md:block w-64 bg-white border-r border-slate-200 p-4 shrink-0 overflow-y-auto">
          <nav className="space-y-1">
            <button onClick={() => setActiveTab('company')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-bold transition-colors ${activeTab === 'company' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}><Building size={18} /> องค์กร (Company)</button>
            <button onClick={() => setActiveTab('time')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-bold transition-colors ${activeTab === 'time' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}><Clock size={18} /> เวลา & วันหยุด</button>
            <button onClick={() => setActiveTab('leave')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-bold transition-colors ${activeTab === 'leave' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}><Shield size={18} /> นโยบายการลา</button>
            <button onClick={() => setActiveTab('employment')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-bold transition-colors ${activeTab === 'employment' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}><Briefcase size={18} /> ประเภทการจ้าง</button>
            <button onClick={() => setActiveTab('notifications')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-bold transition-colors ${activeTab === 'notifications' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}><Bell size={18} /> การแจ้งเตือน</button>
            <button onClick={() => setActiveTab('permissions')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-bold transition-colors ${activeTab === 'permissions' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}><Key size={18} /> สิทธิ์การใช้งาน (RBAC)</button>
            <button onClick={() => setActiveTab('location')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-bold transition-colors ${activeTab === 'location' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}><MapPin size={18} /> พิกัดลงเวลา</button>
          </nav>
        </div>

        <div className="flex-1 flex flex-col min-h-0 bg-white">
          <form id="settings-form" onSubmit={handleSubmit} className="flex flex-col h-full">
            <div className="flex-1 overflow-y-auto p-6 md:p-8">
              
              {/* COMPANY TAB */}
              {activeTab === 'company' && (
                <div className="space-y-6 max-w-5xl animate-fade-in mx-auto">
                  <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-slate-50 rounded-full -mr-10 -mt-10 z-0"></div>
                    <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2 relative z-10">
                      <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg"><Building size={20}/></div>
                      ข้อมูลทั่วไป (General Information)
                    </h3>
                    
                    <div className="flex flex-col md:flex-row gap-8 relative z-10">
                      <div className="flex flex-col items-center gap-3">
                        <div className="w-32 h-32 rounded-2xl bg-slate-50 border-2 border-dashed border-slate-200 flex items-center justify-center relative group cursor-pointer hover:border-indigo-400 hover:bg-indigo-50/30 transition-all">
                          {formData.logoUrl ? (
                            <img src={formData.logoUrl} className="w-full h-full object-contain p-2" />
                          ) : (
                            <div className="text-slate-300 text-center"><Upload size={32} className="mx-auto mb-2" /><span className="text-xs font-bold">Upload Logo</span></div>
                          )}
                          <div className="absolute inset-0 bg-black/40 rounded-2xl opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                            <span className="text-white text-xs font-bold">Change</span>
                          </div>
                        </div>
                        <span className="text-xs text-slate-400">แนะนำขนาด 512x512px</span>
                      </div>
                      
                      <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="col-span-2 md:col-span-1">
                          <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">ชื่อบริษัท (ไทย)</label>
                          <input type="text" name="name" value={formData.name} onChange={handleInputChange} className="w-full border border-slate-300 rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow" placeholder="เช่น บริษัท ตัวอย่าง จำกัด" />
                        </div>
                        <div className="col-span-2 md:col-span-1">
                          <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">Company Name (English)</label>
                          <input type="text" name="nameEn" value={formData.nameEn || ''} onChange={handleInputChange} className="w-full border border-slate-300 rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow" placeholder="e.g. Example Co., Ltd." />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">คำอธิบาย / สโลแกน</label>
                          <input type="text" className="w-full border border-slate-300 rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow" placeholder="เช่น ผู้นำด้านนวัตกรรม..." />
                        </div>
                      </div>
                    </div>

                    <div className="mt-8 pt-8 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
                        <div className="md:col-span-2">
                            <h4 className="text-sm font-bold text-slate-700 mb-4 flex items-center gap-2">
                                <MapPin size={16} className="text-indigo-500" /> ที่อยู่และข้อมูลติดต่อ (Address & Contact)
                            </h4>
                        </div>
                        <div className="md:col-span-2">
                            <label className="block text-xs font-bold text-slate-500 mb-1">ที่อยู่บริษัท (Address)</label>
                            <textarea 
                                name="address" 
                                value={formData.address} 
                                onChange={handleInputChange} 
                                className="w-full border border-slate-300 rounded-xl p-3 text-sm focus:ring-2 focus:ring-indigo-500 outline-none h-24 resize-none"
                                placeholder="ระบุที่อยู่บริษัท..." 
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 mb-1 flex items-center gap-1"><Phone size={12}/> เบอร์โทรศัพท์ (Phone)</label>
                            <input type="text" name="phone" value={formData.phone} onChange={handleInputChange} className="w-full border border-slate-300 rounded-xl p-3 text-sm" />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 mb-1 flex items-center gap-1"><Mail size={12}/> อีเมล (Email)</label>
                            <input type="email" name="email" value={formData.email || ''} onChange={handleInputChange} className="w-full border border-slate-300 rounded-xl p-3 text-sm" />
                        </div>
                        <div className="md:col-span-2">
                            <label className="block text-xs font-bold text-slate-500 mb-1 flex items-center gap-1"><Globe size={12}/> เว็บไซต์ (Website)</label>
                            <input type="text" name="website" value={formData.website || ''} onChange={handleInputChange} className="w-full border border-slate-300 rounded-xl p-3 text-sm" />
                        </div>
                    </div>

                    <div className="mt-8 pt-8 border-t border-slate-100 grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
                        <div className="md:col-span-3">
                            <h4 className="text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
                                <Shield size={16} className="text-green-600" /> ข้อมูลนิติบุคคล (Legal Entity)
                            </h4>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 mb-1 flex items-center gap-1"><Hash size={12}/> เลขผู้เสียภาษี (Tax ID)</label>
                            <input type="text" name="taxId" value={formData.taxId || ''} onChange={handleInputChange} className="w-full border border-slate-300 rounded-xl p-3 text-sm font-mono" placeholder="0-0000-00000-00-0" />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 mb-1 flex items-center gap-1"><Hash size={12}/> เลขประกันสังคม (SSO ID)</label>
                            <input type="text" name="socialSecurityId" value={formData.socialSecurityId || ''} onChange={handleInputChange} className="w-full border border-slate-300 rounded-xl p-3 text-sm font-mono" placeholder="10-0000000-0" />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 mb-1 flex items-center gap-1"><Building size={12}/> รหัสสาขา (Branch Code)</label>
                            <input type="text" name="branchCode" value={formData.branchCode || ''} onChange={handleInputChange} className="w-full border border-slate-300 rounded-xl p-3 text-sm font-mono" placeholder="00000" />
                        </div>
                    </div>
                  </div>
                </div>
              )}

              {/* LOCATION TAB (UPDATED) */}
              {activeTab === 'location' && (
                <div className="h-full flex flex-col md:flex-row gap-6 animate-fade-in max-w-6xl mx-auto">
                  {/* Left: Location List */}
                  <div className="w-full md:w-80 flex flex-col gap-4">
                     <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                        <div className="flex justify-between items-center mb-4">
                           <h3 className="font-bold text-slate-800 flex items-center gap-2">
                              <MapPin size={20} className="text-indigo-600"/> จุดเช็คอิน
                           </h3>
                           <button type="button" onClick={handleAddLocation} className="p-2 bg-indigo-50 text-indigo-600 rounded-full hover:bg-indigo-100 transition-colors">
                              <Plus size={18}/>
                           </button>
                        </div>
                        
                        <div className="space-y-2 max-h-[400px] overflow-y-auto custom-scrollbar pr-1">
                           {formData.locations.map(loc => (
                              <div 
                                 key={loc.id}
                                 onClick={() => { setSelectedLocId(loc.id); }}
                                 className={`p-3 rounded-xl border-2 cursor-pointer transition-all ${selectedLocId === loc.id ? 'border-indigo-500 bg-indigo-50 shadow-sm' : 'border-transparent bg-slate-50 hover:border-slate-200'}`}
                              >
                                 <div className="flex justify-between items-start">
                                    <div>
                                       <h4 className={`font-bold text-sm ${selectedLocId === loc.id ? 'text-indigo-800' : 'text-slate-700'}`}>{loc.name}</h4>
                                       <p className="text-xs text-slate-500 mt-1 font-mono">{loc.lat.toFixed(4)}, {loc.lng.toFixed(4)}</p>
                                    </div>
                                    {formData.locations.length > 1 && (
                                       <button 
                                          onClick={(e) => { e.stopPropagation(); handleDeleteLocation(loc.id); }}
                                          className="text-slate-400 hover:text-red-500 p-1"
                                       >
                                          <Trash2 size={14} />
                                       </button>
                                    )}
                                 </div>
                              </div>
                           ))}
                        </div>
                     </div>

                     <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                        <div className="flex items-center justify-between mb-2">
                           <span className="text-xs font-bold text-slate-500 uppercase">System Status</span>
                           <label className="relative inline-flex items-center cursor-pointer">
                              <input type="checkbox" name="isGeofencingEnabled" checked={formData.isGeofencingEnabled} onChange={handleToggleChange} className="sr-only peer" />
                              <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-green-500"></div>
                           </label>
                        </div>
                        <p className="text-xs text-slate-400">
                           {formData.isGeofencingEnabled ? 'จำกัดการลงเวลาเฉพาะในพื้นที่ (On)' : 'อนุญาตให้ลงเวลาที่ไหนก็ได้ (Off)'}
                        </p>
                     </div>
                  </div>

                  {/* Right: Map & Editor */}
                  <div className="flex-1 flex flex-col gap-4 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden h-[600px]">
                     {editingLoc ? (
                        <div className="flex flex-col h-full">
                           {/* Map Visualizer (Interactive iframe) */}
                           <div className="flex-1 relative bg-slate-100">
                              <iframe 
                                 width="100%" 
                                 height="100%" 
                                 frameBorder="0" 
                                 scrolling="no" 
                                 marginHeight={0} 
                                 marginWidth={0} 
                                 src={`https://maps.google.com/maps?q=${editingLoc.lat},${editingLoc.lng}&z=16&output=embed`}
                                 className="absolute inset-0"
                              ></iframe>
                              
                              {/* Overlay Controls */}
                              <div className="absolute top-4 right-4 flex flex-col gap-2">
                                 <button type="button" onClick={handleGetCurrentLocation} className="bg-white p-3 rounded-xl shadow-lg text-indigo-600 hover:bg-indigo-50 font-bold text-xs flex items-center gap-2">
                                    <Locate size={18} /> Current GPS
                                 </button>
                              </div>
                           </div>

                           {/* Editor Form */}
                           <div className="p-6 bg-white border-t border-slate-100">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                 <div>
                                    <label className="block text-xs font-bold text-slate-500 mb-1">ชื่อสถานที่ (Location Name)</label>
                                    <input 
                                       type="text" 
                                       className="w-full border border-slate-300 rounded-lg p-2.5 text-sm"
                                       value={editingLoc.name}
                                       onChange={e => setEditingLoc({...editingLoc, name: e.target.value})}
                                    />
                                 </div>
                                 <div>
                                    <label className="block text-xs font-bold text-slate-500 mb-1">รัศมี (Radius: {editingLoc.radius}m)</label>
                                    <div className="flex items-center gap-2">
                                       <input 
                                          type="range" min="50" max="1000" step="50"
                                          className="flex-1"
                                          value={editingLoc.radius}
                                          onChange={e => setEditingLoc({...editingLoc, radius: Number(e.target.value)})}
                                       />
                                       <span className="text-xs font-bold bg-slate-100 px-2 py-1 rounded w-12 text-center">{editingLoc.radius}m</span>
                                    </div>
                                 </div>
                                 <div className="flex gap-2">
                                    <div className="flex-1">
                                       <label className="block text-[10px] font-bold text-slate-400 mb-1">LATITUDE</label>
                                       <input 
                                          type="number" step="0.000001"
                                          className="w-full border border-slate-200 bg-slate-50 rounded-lg p-2 text-xs font-mono"
                                          value={editingLoc.lat}
                                          onChange={e => setEditingLoc({...editingLoc, lat: Number(e.target.value)})}
                                       />
                                    </div>
                                    <div className="flex-1">
                                       <label className="block text-[10px] font-bold text-slate-400 mb-1">LONGITUDE</label>
                                       <input 
                                          type="number" step="0.000001"
                                          className="w-full border border-slate-200 bg-slate-50 rounded-lg p-2 text-xs font-mono"
                                          value={editingLoc.lng}
                                          onChange={e => setEditingLoc({...editingLoc, lng: Number(e.target.value)})}
                                       />
                                    </div>
                                 </div>
                                 <div className="flex gap-2 items-end">
                                    {formData.locations.length > 1 && (
                                       <button 
                                          type="button" 
                                          onClick={() => handleDeleteLocation(editingLoc.id)}
                                          className="px-4 py-2.5 bg-white border border-red-200 text-red-600 rounded-lg font-bold text-sm hover:bg-red-50 transition-all flex items-center justify-center gap-2"
                                       >
                                          <Trash2 size={16} /> Delete
                                       </button>
                                    )}
                                    <button 
                                       type="button" 
                                       onClick={handleSaveLocation}
                                       className="flex-1 py-2.5 bg-indigo-600 text-white rounded-lg font-bold text-sm hover:bg-indigo-700 shadow-md transition-all flex items-center justify-center gap-2"
                                    >
                                       <Save size={16} /> Update Location
                                    </button>
                                 </div>
                              </div>
                           </div>
                        </div>
                     ) : (
                        <div className="flex flex-col items-center justify-center h-full text-slate-400">
                           <Map size={48} className="mb-4 opacity-20"/>
                           <p>Select a location to edit</p>
                        </div>
                     )}
                  </div>
                </div>
              )}

              {/* TIME TAB - RE-ADDED HOLIDAY MANAGEMENT */}
              {activeTab === 'time' && (
                <div className="space-y-6 max-w-4xl animate-fade-in mx-auto">
                  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                    <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                      <Clock className="text-blue-600" size={20}/> เวลาทำงานปกติ (Standard Work Time)
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">เวลาเข้างาน</label>
                        <input type="time" name="workStartTime" value={formData.workStartTime} onChange={handleInputChange} className="w-full border border-slate-300 rounded-xl p-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">เวลาเลิกงาน</label>
                        <input type="time" name="workEndTime" value={formData.workEndTime} onChange={handleInputChange} className="w-full border border-slate-300 rounded-xl p-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-500 mb-1 uppercase">อนุโลมสาย (นาที)</label>
                        <div className="relative">
                          <input type="number" name="lateThresholdMinutes" value={formData.lateThresholdMinutes} onChange={handleInputChange} className="w-full border border-slate-300 rounded-xl p-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
                          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 font-bold">MINS</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                      <h4 className="font-bold text-slate-700 mb-3 text-sm uppercase">วันทำงาน (Work Days)</h4>
                      <div className="flex flex-wrap gap-2">
                        {days.map(day => (
                          <button 
                            key={day} 
                            type="button"
                            onClick={() => handleDayToggle(day)} 
                            className={`w-12 h-12 rounded-xl font-bold text-xs transition-all border-2 flex items-center justify-center ${formData.workDays.includes(day) ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-200' : 'bg-white text-slate-400 border-slate-200 hover:border-slate-300'}`}
                          >
                            {day}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Holiday Management Section */}
                  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                     <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                        <Calendar className="text-red-500" size={20}/> วันหยุดประจำปี (Public Holidays)
                     </h3>
                     
                     {/* Add New Holiday */}
                     <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mb-4">
                        <div className="flex flex-col md:flex-row gap-4 items-end">
                           <div className="flex-1 w-full">
                              <label className="block text-xs font-bold text-slate-500 mb-1">ชื่อวันหยุด (Name)</label>
                              <input 
                                type="text" 
                                className="w-full border border-slate-300 rounded-xl p-2.5 text-sm" 
                                placeholder="เช่น วันปีใหม่" 
                                value={newHoliday.name} 
                                onChange={(e) => setNewHoliday({...newHoliday, name: e.target.value})} 
                              />
                           </div>
                           <div className="w-full md:w-40">
                              <label className="block text-xs font-bold text-slate-500 mb-1">วันที่ (Date)</label>
                              <input 
                                type="date" 
                                className="w-full border border-slate-300 rounded-xl p-2.5 text-sm" 
                                value={newHoliday.date} 
                                onChange={(e) => setNewHoliday({...newHoliday, date: e.target.value})} 
                              />
                           </div>
                           <button 
                              type="button" 
                              onClick={handleAddHoliday} 
                              disabled={!newHoliday.name || !newHoliday.date} 
                              className="bg-indigo-600 text-white p-2.5 rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-lg shadow-indigo-200 flex items-center justify-center gap-2 min-w-[100px]"
                           >
                              <Plus size={18} /> เพิ่ม
                           </button>
                        </div>
                     </div>

                     {/* Holiday List */}
                     <div className="space-y-2 max-h-60 overflow-y-auto custom-scrollbar pr-1">
                        {formData.publicHolidays.sort((a,b) => a.date.localeCompare(b.date)).map(h => (
                           <div key={h.id} className="flex justify-between items-center p-3 bg-white border border-slate-100 rounded-xl hover:bg-slate-50 transition-colors group">
                              <div className="flex items-center gap-3">
                                 <div className="w-10 h-10 bg-red-50 text-red-500 rounded-lg flex items-center justify-center font-bold text-xs flex-col leading-none">
                                    <span>{new Date(h.date).getDate()}</span>
                                    <span className="text-[8px] uppercase">{new Date(h.date).toLocaleString('en-US', {month:'short'})}</span>
                                 </div>
                                 <span className="font-bold text-slate-700 text-sm">{h.name}</span>
                              </div>
                              <button 
                                 type="button" 
                                 onClick={() => handleDeleteHoliday(h.id)} 
                                 className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
                              >
                                 <Trash2 size={16} />
                              </button>
                           </div>
                        ))}
                        {formData.publicHolidays.length === 0 && (
                           <div className="text-center py-8 text-slate-400 text-sm">ยังไม่มีข้อมูลวันหยุด</div>
                        )}
                     </div>
                  </div>
                </div>
              )}
              
              {/* LEAVE TAB */}
              {activeTab === 'leave' && (<div className="space-y-6 max-w-4xl animate-fade-in mx-auto"><div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm"><h3 className="text-lg font-bold text-slate-800 mb-2 flex items-center gap-2"><Shield className="text-blue-600" size={20}/> สิทธิ์การลา (Leave Quotas)</h3><p className="text-sm text-slate-500 mb-6">กำหนดประเภทและจำนวนวันลาสำหรับพนักงาน</p><div className="grid grid-cols-1 gap-4 mb-6">{formData.leaveQuotas.map((q, index) => (<div key={index} className="flex items-center gap-4 p-4 border border-slate-200 rounded-xl bg-white hover:bg-slate-50 transition-colors"><div className="flex-1"><div className="text-sm font-bold text-slate-700">{q.type}</div><div className="text-xs text-slate-400">ค่าเริ่มต้น</div></div><div className="flex items-center gap-2"><input type="number" className="w-20 border border-slate-300 rounded-lg p-2 text-right font-bold text-blue-600 text-sm" value={q.quota} onChange={(e) => handleQuotaChange(q.type, Number(e.target.value))} /><span className="text-sm text-slate-500 font-bold w-12">วัน/ปี</span></div><button type="button" onClick={() => handleDeleteLeaveType(q.type)} className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"><Trash2 size={18} /></button></div>))}</div><div className="bg-slate-50 p-4 rounded-xl border border-slate-200"><h4 className="text-sm font-bold text-slate-700 mb-3 uppercase">เพิ่มประเภทการลาใหม่</h4><div className="flex flex-col md:flex-row gap-4 items-end"><div className="flex-1 w-full"><label className="block text-xs font-bold text-slate-500 mb-1">ชื่อการลา (Leave Name)</label><input type="text" className="w-full border border-slate-300 rounded-xl p-2.5 text-sm" placeholder="เช่น ลาบวช, ลาพิเศษ" value={newLeaveType.name} onChange={(e) => setNewLeaveType({...newLeaveType, name: e.target.value})} /></div><div className="w-full md:w-32"><label className="block text-xs font-bold text-slate-500 mb-1">จำนวนวัน (Quota)</label><input type="number" className="w-full border border-slate-300 rounded-xl p-2.5 text-sm" placeholder="30" value={newLeaveType.quota} onChange={(e) => setNewLeaveType({...newLeaveType, quota: Number(e.target.value)})} /></div><button type="button" onClick={handleAddLeaveType} disabled={!newLeaveType.name || newLeaveType.quota <= 0} className="bg-indigo-600 text-white p-2.5 rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-lg shadow-indigo-200 flex items-center justify-center gap-2 min-w-[100px]"><Plus size={18} /> เพิ่ม</button></div></div></div></div>)}
              
              {/* EMPLOYMENT TAB (ENHANCED) */}
              {activeTab === 'employment' && (
                <div className="flex flex-col lg:flex-row gap-8 h-full animate-fade-in">
                  
                  {/* Left Sidebar: Type List */}
                  <div className="w-full lg:w-72 flex flex-col gap-4 shrink-0">
                     <div className="grid grid-cols-2 gap-2">
                        <button type="button" onClick={() => handleAddEmploymentType('Monthly')} className="flex items-center justify-center gap-2 py-3 bg-blue-50 text-blue-600 border-2 border-dashed border-blue-200 rounded-xl font-bold text-xs hover:bg-blue-100 hover:border-blue-300 transition-all">
                           <Plus size={16} /> เพิ่มแบบรายเดือน
                        </button>
                        <button type="button" onClick={() => handleAddEmploymentType('Daily')} className="flex items-center justify-center gap-2 py-3 bg-orange-50 text-orange-600 border-2 border-dashed border-orange-200 rounded-xl font-bold text-xs hover:bg-orange-100 hover:border-orange-300 transition-all">
                           <Plus size={16} /> เพิ่มแบบรายวัน
                        </button>
                     </div>
                     <div className="space-y-2 overflow-y-auto max-h-[500px] custom-scrollbar pr-1">
                        {formData.employmentTypes.map(type => (
                           <button key={type.id} type="button" onClick={() => setSelectedTypeId(type.id)} className={`w-full p-4 rounded-xl text-left border-2 transition-all group ${selectedTypeId === type.id ? (type.paymentType === 'Monthly' ? 'bg-blue-50 border-blue-500 ring-1 ring-blue-200' : 'bg-orange-50 border-orange-500 ring-1 ring-orange-200') : 'bg-white border-slate-100 hover:border-slate-300'}`}>
                              <div className="flex justify-between items-start mb-1">
                                 <span className={`font-bold text-sm ${selectedTypeId === type.id ? 'text-slate-800' : 'text-slate-600'}`}>{type.name}</span>
                                 {selectedTypeId === type.id && <CheckCircle2 size={16} className={type.paymentType === 'Monthly' ? 'text-blue-600' : 'text-orange-600'} />}
                              </div>
                              <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${type.paymentType === 'Monthly' ? 'bg-blue-100 text-blue-700' : 'bg-orange-100 text-orange-700'}`}>{type.paymentType}</span>
                           </button>
                        ))}
                     </div>
                  </div>

                  {/* Right Panel: Details */}
                  <div className="flex-1 min-w-0 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
                     {selectedType ? (
                        <div className="flex flex-col h-full">
                           {/* Header */}
                           <div className="p-6 border-b border-slate-100 bg-slate-50 flex justify-between items-start">
                              <div>
                                 <div className="flex items-center gap-3 mb-2">
                                    <h3 className="text-xl font-bold text-slate-800">{selectedType.name}</h3>
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide border ${selectedType.paymentType === 'Monthly' ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-orange-100 text-orange-700 border-orange-200'}`}>
                                       {selectedType.paymentType}
                                    </span>
                                 </div>
                                 <p className="text-xs text-slate-500">ID: {selectedType.id}</p>
                              </div>
                           </div>

                           <div className="flex-1 overflow-y-auto p-6 space-y-8 custom-scrollbar">
                              {/* 1. Basic Info */}
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                 <div>
                                    <label className="block text-xs font-bold text-slate-500 mb-1">ชื่อประเภท (TH)</label>
                                    <input type="text" className="w-full border border-slate-300 rounded-xl p-2.5 text-sm" value={selectedType.name} onChange={e => updateSelectedType({ name: e.target.value })} />
                                 </div>
                                 <div>
                                    <label className="block text-xs font-bold text-slate-500 mb-1">Name (EN)</label>
                                    <input type="text" className="w-full border border-slate-300 rounded-xl p-2.5 text-sm" value={selectedType.nameEn} onChange={e => updateSelectedType({ nameEn: e.target.value })} />
                                 </div>
                              </div>

                              {/* 2. Condition Tabs (Late, Absent, etc.) */}
                              <div>
                                 <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><AlertCircle size={18} className="text-red-500"/> เงื่อนไขการหักเงิน (Deduction Rules)</h4>
                                 
                                 <div className="flex gap-2 border-b border-slate-200 mb-4 overflow-x-auto">
                                    {['late', 'absent', 'missing', 'early'].map(tab => (
                                       <button 
                                         key={tab}
                                         type="button"
                                         onClick={() => setConditionTab(tab as any)}
                                         className={`px-4 py-2 text-sm font-bold border-b-2 transition-colors capitalize whitespace-nowrap ${conditionTab === tab ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
                                       >
                                          {tab === 'late' ? 'มาสาย (Late)' : tab === 'absent' ? 'ขาดงาน (Absent)' : tab === 'missing' ? 'ลืมลงเวลา (No Punch)' : 'ออกก่อน (Early)'}
                                       </button>
                                    ))}
                                 </div>

                                 <div className="bg-slate-50 p-6 rounded-xl border border-slate-200">
                                    {/* Late Logic */}
                                    {conditionTab === 'late' && (
                                       <div className="space-y-4">
                                          <div className="flex items-center gap-3 mb-4">
                                             <label className="relative inline-flex items-center cursor-pointer">
                                                <input type="checkbox" checked={selectedType.conditions.late.enabled} onChange={e => updateCondition('late', { enabled: e.target.checked })} className="sr-only peer" />
                                                <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                                                <span className="ml-3 text-sm font-bold text-slate-700">เปิดใช้งานการหักเงินเมื่อมาสาย</span>
                                             </label>
                                          </div>
                                          
                                          {selectedType.conditions.late.enabled && (
                                             <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fade-in">
                                                <div>
                                                   <label className="block text-xs font-bold text-slate-500 mb-1">รูปแบบการหัก (Action)</label>
                                                   <select 
                                                     value={selectedType.conditions.late.action} 
                                                     onChange={e => updateCondition('late', { action: e.target.value as any })}
                                                     className="w-full border border-slate-300 rounded-xl p-2.5 text-sm"
                                                   >
                                                      <option value="None">ไม่หักเงิน (บันทึกสถิติเท่านั้น)</option>
                                                      <option value="DeductSalary">หักเงินเดือน</option>
                                                   </select>
                                                </div>
                                                {selectedType.conditions.late.action === 'DeductSalary' && (
                                                   <div>
                                                      <label className="block text-xs font-bold text-slate-500 mb-1">วิธีคำนวณ (Calculation)</label>
                                                      <select 
                                                        value={selectedType.conditions.late.calculationMode} 
                                                        onChange={e => updateCondition('late', { calculationMode: e.target.value as any })}
                                                        className="w-full border border-slate-300 rounded-xl p-2.5 text-sm"
                                                      >
                                                         <option value="ProRated">ตามจริง (นาทีละ...บาท ตามฐานเงินเดือน)</option>
                                                         <option value="Fixed">จำนวนตายตัว (Fixed Amount)</option>
                                                      </select>
                                                   </div>
                                                )}
                                                {selectedType.conditions.late.action === 'DeductSalary' && selectedType.conditions.late.calculationMode === 'Fixed' && (
                                                   <div>
                                                      <label className="block text-xs font-bold text-slate-500 mb-1">จำนวนเงิน (บาท/ครั้ง)</label>
                                                      <input 
                                                        type="number" 
                                                        value={selectedType.conditions.late.fixedAmount || 0}
                                                        onChange={e => updateCondition('late', { fixedAmount: Number(e.target.value) })}
                                                        className="w-full border border-slate-300 rounded-xl p-2.5 text-sm"
                                                      />
                                                   </div>
                                                )}
                                             </div>
                                          )}
                                       </div>
                                    )}
                                    
                                    {/* Absent Logic */}
                                    {conditionTab === 'absent' && (
                                        <div className="space-y-4">
                                           <div className="flex items-center gap-3">
                                             <label className="relative inline-flex items-center cursor-pointer">
                                                <input type="checkbox" checked={selectedType.conditions.absent.enabled} onChange={e => updateCondition('absent', { enabled: e.target.checked })} className="sr-only peer" />
                                                <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                                                <span className="ml-3 text-sm font-bold text-slate-700">เปิดใช้งานการหักเงินเมื่อขาดงาน</span>
                                             </label>
                                           </div>
                                           {selectedType.conditions.absent.enabled && (
                                              <div className="p-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-600">
                                                 ระบบจะคำนวณหักเงินตามสัดส่วนรายวัน/รายชั่วโมง โดยอัตโนมัติ (Pro-rated)
                                              </div>
                                           )}
                                        </div>
                                    )}

                                    {/* Missing Logic */}
                                    {conditionTab === 'missing' && (
                                        <div className="space-y-4">
                                           <div className="flex items-center gap-3">
                                             <label className="relative inline-flex items-center cursor-pointer">
                                                <input type="checkbox" checked={selectedType.conditions.missingPunch.enabled} onChange={e => updateCondition('missingPunch', { enabled: e.target.checked })} className="sr-only peer" />
                                                <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                                                <span className="ml-3 text-sm font-bold text-slate-700">เปิดใช้งานการหักเงินเมื่อลืมลงเวลา</span>
                                             </label>
                                           </div>
                                           {selectedType.conditions.missingPunch.enabled && (
                                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                 <div>
                                                    <label className="block text-xs font-bold text-slate-500 mb-1">จำนวนเงินค่าปรับ (บาท/ครั้ง)</label>
                                                    <input 
                                                      type="number" 
                                                      value={selectedType.conditions.missingPunch.fixedAmount || 0} 
                                                      onChange={e => updateCondition('missingPunch', { fixedAmount: Number(e.target.value) })}
                                                      className="w-full border border-slate-300 rounded-xl p-2.5 text-sm"
                                                    />
                                                 </div>
                                              </div>
                                           )}
                                        </div>
                                    )}
                                 </div>
                              </div>

                              {/* 3. OT Configuration */}
                              <div>
                                 <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Clock size={18} className="text-green-600"/> การคำนวณ OT (Overtime Rules)</h4>
                                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <OTRateConfigCard 
                                       title="OT ปกติ (Normal)" 
                                       color="green" 
                                       items={[{key: 'otNormal', label: 'หลังเลิกงาน (1.5x)'}]}
                                       selectedType={selectedType}
                                       updateOTRule={updateOTRule}
                                    />
                                    <OTRateConfigCard 
                                       title="วันหยุด (Day Off)" 
                                       color="orange" 
                                       items={[
                                          {key: 'workDayOff', label: 'ทำงานวันหยุด (1.0x)'},
                                          {key: 'otDayOff', label: 'OT วันหยุด (3.0x)'}
                                       ]}
                                       selectedType={selectedType}
                                       updateOTRule={updateOTRule}
                                    />
                                    <OTRateConfigCard 
                                       title="นักขัตฤกษ์ (Public Holiday)" 
                                       color="red" 
                                       items={[
                                          {key: 'workPublicHoliday', label: 'ทำงานนักขัตฤกษ์ (1.0x)'},
                                          {key: 'otPublicHoliday', label: 'OT นักขัตฤกษ์ (3.0x)'}
                                       ]}
                                       selectedType={selectedType}
                                       updateOTRule={updateOTRule}
                                    />
                                 </div>
                              </div>

                              {/* 4. Tax & SSO */}
                              <div className="p-6 bg-slate-50 rounded-xl border border-slate-200">
                                 <h4 className="font-bold text-slate-800 mb-4">การหักภาษีและประกันสังคม</h4>
                                 <div className="flex flex-col md:flex-row gap-8">
                                    <label className="flex items-center gap-2 cursor-pointer">
                                       <input type="checkbox" checked={selectedType.calculateTax} onChange={e => updateSelectedType({ calculateTax: e.target.checked })} className="w-5 h-5 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500" />
                                       <span className="text-sm text-slate-700">คำนวณภาษี ณ ที่จ่าย (Withholding Tax)</span>
                                    </label>
                                    <label className="flex items-center gap-2 cursor-pointer">
                                       <input type="checkbox" checked={selectedType.calculateSSO} onChange={e => updateSelectedType({ calculateSSO: e.target.checked })} className="w-5 h-5 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500" />
                                       <span className="text-sm text-slate-700">คำนวณประกันสังคม (Social Security)</span>
                                    </label>
                                 </div>
                              </div>

                           </div>
                        </div>
                     ) : (
                        <div className="flex flex-col items-center justify-center h-full text-slate-400 p-10">
                           <Briefcase size={48} className="mb-4 opacity-20" />
                           <p>เลือกประเภทการจ้างงานเพื่อแก้ไข</p>
                        </div>
                     )}
                  </div>
                </div>
              )}

              {activeTab === 'notifications' && (<div className="space-y-6 max-w-4xl animate-fade-in mx-auto"><div className="bg-slate-50 rounded-2xl p-6 border border-slate-200 mb-6"><div className="flex items-start gap-4"><div className="p-3 bg-white rounded-xl shadow-sm text-blue-600"><Bell size={24} /></div><div><h3 className="text-lg font-bold text-slate-800">การตั้งค่าการแจ้งเตือน (Notifications)</h3><p className="text-sm text-slate-500 mt-1">กำหนดเหตุการณ์ที่ต้องการให้ระบบแจ้งเตือน และเลือกผู้รับข้อความ (HR, หัวหน้างาน, พนักงาน)</p></div></div></div><div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden"><div className="px-6 py-4 border-b border-slate-100 bg-slate-50 flex items-center gap-2"><Clock size={18} className="text-slate-500" /><h4 className="font-bold text-slate-700">การแจ้งเตือนทดลองงาน (Probation Alerts)</h4></div><div className="p-6 space-y-4"><NotificationRow label="ครบ 30 วัน (1st Follow-up)" category="probation" settingKey="day30" rule={formData.notificationSettings.probation.day30} toggleNotificationRule={toggleNotificationRule} /><NotificationRow label="ครบ 60 วัน (Mid-term Review)" category="probation" settingKey="day60" rule={formData.notificationSettings.probation.day60} toggleNotificationRule={toggleNotificationRule} /><NotificationRow label="ครบ 90 วัน (Pre-evaluation)" category="probation" settingKey="day90" rule={formData.notificationSettings.probation.day90} toggleNotificationRule={toggleNotificationRule} /><NotificationRow label="ครบ 119 วัน (Final Decision)" category="probation" settingKey="day119" rule={formData.notificationSettings.probation.day119} toggleNotificationRule={toggleNotificationRule} /></div></div>{/* ... */}</div>)}

              {activeTab === 'permissions' && (
                 /* ... Permissions Tab (Keep existing) ... */
                 <div className="space-y-6 max-w-6xl animate-fade-in mx-auto">
                    <div className="flex justify-between items-start mb-6">
                        <div className="flex items-start gap-4">
                            <div className="p-3 bg-white rounded-xl shadow-sm text-purple-600"><Key size={24} /></div>
                            <div>
                               <h3 className="text-lg font-bold text-slate-800">สิทธิ์การใช้งาน (Granular Permissions)</h3>
                               <p className="text-sm text-slate-500 mt-1">กำหนดสิทธิ์การเข้าถึงข้อมูลและการดำเนินการต่างๆ อย่างละเอียดสำหรับแต่ละบทบาท</p>
                            </div>
                        </div>
                        <div className="flex gap-3">
                           <button 
                              onClick={handleRecommendedPermissions}
                              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg text-xs font-bold transition-all shadow-md shadow-purple-200 hover:shadow-lg active:scale-95"
                           >
                              <Sparkles size={14} /> ใช้ค่าแนะนำ (Smart Config)
                           </button>
                           
                           <button 
                              onClick={handleResetPermissions} 
                              className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-500 hover:text-red-600 hover:border-red-200 rounded-lg text-xs font-bold transition-all shadow-sm active:scale-95"
                           >
                              <RefreshCcw size={14} /> Reset to Default
                           </button>
                        </div>
                    </div>

                    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                       <div className="overflow-x-auto">
                          <table className="w-full text-left">
                             <thead>
                                <tr className="bg-slate-50 border-b border-slate-200 text-xs uppercase font-bold text-slate-500">
                                   <th className="px-6 py-4 sticky left-0 bg-slate-50 z-10 border-r border-slate-200 min-w-[300px]">
                                      รายการสิทธิ์ (Permissions)
                                   </th>
                                   {[Role.CEO, Role.HR_MANAGER, Role.HR_STAFF, Role.MANAGER, Role.STAFF].map((role) => (
                                      <th key={role} className="px-4 py-4 text-center min-w-[100px] hover:bg-slate-100 cursor-pointer transition-colors group" onClick={() => toggleRoleColumn(role)}>
                                         <div className="flex flex-col items-center gap-1">
                                            <span className="text-slate-800 group-hover:text-purple-600 transition-colors">{role}</span>
                                            <span className="text-[9px] text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity">Select All</span>
                                         </div>
                                      </th>
                                   ))}
                                </tr>
                             </thead>
                             <tbody className="divide-y divide-slate-100 text-sm">
                                {permissionCategories.map((category, catIdx) => (
                                   <React.Fragment key={category.title}>
                                      <tr className="bg-slate-50/50">
                                         <td colSpan={6} className="px-6 py-3 font-bold text-slate-700 text-xs uppercase tracking-wide border-y border-slate-100 sticky left-0 z-10 bg-slate-50">
                                            {category.title}
                                         </td>
                                      </tr>
                                      {category.items.map((perm) => (
                                         <tr key={perm.key} className="hover:bg-slate-50 transition-colors group/row">
                                            <td 
                                               className="px-6 py-3 sticky left-0 bg-white group-hover/row:bg-slate-50 z-10 border-r border-slate-100 cursor-pointer"
                                               onClick={() => togglePermissionRow(perm.key)}
                                            >
                                               <div className="flex items-center justify-between w-full">
                                                  <div className="flex items-center gap-3 pl-4">
                                                     <perm.icon size={16} className="text-slate-400 shrink-0" />
                                                     <div>
                                                        <div className="font-bold text-slate-700 group-hover/row:text-purple-600 transition-colors">{perm.label}</div>
                                                        <div className="text-[10px] text-slate-400">{perm.desc}</div>
                                                     </div>
                                                  </div>
                                                  <button 
                                                     onClick={(e) => { e.stopPropagation(); resetPermissionRow(perm.key); }}
                                                     className="p-1.5 text-slate-300 hover:text-orange-500 hover:bg-orange-50 rounded-full transition-colors opacity-0 group-hover/row:opacity-100"
                                                     title="Reset this row to default"
                                                  >
                                                     <Undo2 size={14} />
                                                  </button>
                                               </div>
                                            </td>
                                            {[Role.CEO, Role.HR_MANAGER, Role.HR_STAFF, Role.MANAGER, Role.STAFF].map((role) => {
                                               const roleConfig = (formData.rolePermissions || []).find(r => r.role === role);
                                               const isChecked = roleConfig?.permissions?.includes(perm.key) || false;
                                               const lockReason = getPermissionLockReason(role, perm.key);
                                               
                                               return (
                                                  <td key={role} className="px-4 py-3 text-center relative group/cell">
                                                     <label className={`inline-flex items-center p-2 rounded-full transition-colors ${lockReason ? 'cursor-not-allowed opacity-80' : 'cursor-pointer hover:bg-purple-50'}`}>
                                                        <input 
                                                           type="checkbox" 
                                                           className="sr-only peer" 
                                                           checked={isChecked}
                                                           onChange={() => togglePermission(role, perm.key)}
                                                           disabled={!!lockReason}
                                                        />
                                                        {lockReason ? (
                                                           <div className="relative">
                                                              <Lock className="text-red-500 fill-red-50" size={18} />
                                                           </div>
                                                        ) : isChecked ? (
                                                           <CheckSquare className="text-purple-600 fill-purple-100" size={20} />
                                                        ) : (
                                                           <div className="w-5 h-5 border-2 border-slate-300 rounded hover:border-purple-400 transition-colors"></div>
                                                        )}
                                                     </label>
                                                     {lockReason && (
                                                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 bg-slate-800 text-white text-[10px] p-2 rounded-lg shadow-xl opacity-0 group-hover/cell:opacity-100 transition-opacity pointer-events-none z-50 text-center font-medium">
                                                           <div className="flex items-center justify-center gap-1 mb-1 text-red-300 font-bold uppercase"><AlertTriangle size={10} /> Locked</div>
                                                           {lockReason}
                                                           <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-slate-800"></div>
                                                        </div>
                                                     )}
                                                  </td>
                                               );
                                            })}
                                         </tr>
                                      ))}
                                   </React.Fragment>
                                ))}
                             </tbody>
                          </table>
                       </div>
                       <div className="p-4 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 italic text-center flex items-center justify-center gap-2">
                          <Info size={14} />
                          <span>สิทธิ์ของ Super Admin จะถูกเปิดใช้งานทั้งหมดโดยอัตโนมัติเพื่อความปลอดภัย (ไม่แสดงในตาราง)</span>
                       </div>
                    </div>
                 </div>
              )}

            </div>

            {/* FIXED FOOTER with Unsaved Changes Indicator and Anti-Lockout */}
            <div className={`p-4 border-t border-slate-200 bg-white flex justify-between items-center shrink-0 z-20 transition-shadow ${hasUnsavedChanges ? 'shadow-[0_-4px_20px_rgba(0,0,0,0.1)] border-t-amber-400 border-t-2' : ''}`}>
               <div className="flex items-center gap-2 px-2">
                  {hasUnsavedChanges && !isLockingOut && (
                     <div className="flex items-center gap-2 text-amber-600 font-bold text-sm animate-pulse">
                        <AlertCircle size={18} />
                        <span>มีการแก้ไขข้อมูลที่ยังไม่ได้บันทึก (Unsaved Changes)</span>
                     </div>
                  )}
                  {isLockingOut && (
                     <div className="flex items-center gap-2 text-red-600 font-bold text-sm animate-pulse">
                        <Ban size={18} />
                        <span>Warning: You are removing your own access! Save disabled.</span>
                     </div>
                  )}
                  {showSaveSuccess && (
                     <span className="text-green-600 text-sm flex items-center gap-1 font-bold animate-fade-in">
                        <CheckCircle2 size={18} /> บันทึกข้อมูลเรียบร้อยแล้ว
                     </span>
                  )}
               </div>
               
               <div className="flex gap-3">
                  <button type="button" onClick={() => setFormData(settings)} className="px-5 py-2.5 text-slate-600 hover:bg-slate-100 rounded-xl font-bold text-sm transition-colors">
                     ยกเลิก
                  </button>
                  {canEdit && (
                     <button 
                        type="submit" 
                        disabled={isLockingOut}
                        className={`px-6 py-2.5 rounded-xl font-bold text-sm shadow-lg transition-all flex items-center gap-2 ${
                           isLockingOut 
                              ? 'bg-slate-300 text-slate-500 cursor-not-allowed' 
                              : hasUnsavedChanges 
                                 ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-amber-200 scale-105' 
                                 : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-200'
                        }`}
                     >
                        {isLockingOut ? <Lock size={18}/> : <Save size={18} />} 
                        {isLockingOut ? 'Locked (Safety)' : 'บันทึกการตั้งค่า'}
                     </button>
                  )}
               </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
