
import React, { useMemo } from 'react';
import { Employee } from '../types';
import { Edit2, User } from 'lucide-react';

interface OrgChartProps {
  employees: Employee[];
  onEdit: (emp: Employee) => void;
}

interface TreeNode extends Employee {
  children: TreeNode[];
}

const DepartmentColors: Record<string, string> = {
  'HR': 'bg-pink-100 text-pink-700 border-pink-200',
  'IT': 'bg-blue-100 text-blue-700 border-blue-200',
  'Sales': 'bg-emerald-100 text-emerald-700 border-emerald-200',
  'Marketing': 'bg-orange-100 text-orange-700 border-orange-200',
  'Operations': 'bg-slate-100 text-slate-700 border-slate-200',
  'Executive': 'bg-purple-100 text-purple-700 border-purple-200',
};

const OrgNode: React.FC<{ node: TreeNode; onEdit: (emp: Employee) => void }> = ({ node, onEdit }) => {
  const deptColor = DepartmentColors[node.department] || 'bg-gray-100 text-gray-700 border-gray-200';

  return (
    <div className="flex flex-col items-center">
      <div className="relative group cursor-pointer transition-transform hover:-translate-y-1" onClick={() => onEdit(node)}>
        <div className="flex flex-col items-center bg-white p-4 rounded-xl shadow-sm border border-slate-200 w-48 relative z-10 hover:shadow-md hover:border-indigo-300 transition-all">
          <div className="relative">
             <img 
               src={node.avatarUrl} 
               className="w-12 h-12 rounded-full border-2 border-white shadow-sm object-cover mb-2" 
               alt={node.firstName}
             />
             <span className={`absolute -bottom-1 -right-1 w-4 h-4 border-2 border-white rounded-full ${node.status.includes('Probation') ? 'bg-amber-400' : 'bg-green-500'}`}></span>
          </div>
          
          <h4 className="font-bold text-slate-800 text-sm text-center leading-tight mb-1">{node.firstName} {node.lastName}</h4>
          <p className="text-xs text-slate-500 text-center mb-2 font-medium">{node.position}</p>
          
          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wide border ${deptColor}`}>
            {node.department}
          </span>

          <button 
            className="absolute top-2 right-2 p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
            onClick={(e) => { e.stopPropagation(); onEdit(node); }}
          >
            <Edit2 size={14} />
          </button>
        </div>
        
        {/* Connection Point Top (Hidden for root, handled by parent) */}
        {/* Connection Point Bottom */}
        {node.children.length > 0 && (
           <div className="absolute -bottom-4 left-1/2 w-px h-4 bg-slate-300 -ml-px"></div>
        )}
      </div>

      {node.children.length > 0 && (
        <>
          <div className="h-4"></div> {/* Spacing for vertical line */}
          <div className="flex relative pt-4">
             {/* Horizontal Line connecting children */}
             {node.children.length > 1 && (
               <div className="absolute top-0 left-0 right-0 h-px bg-slate-300 mx-auto" 
                    style={{ 
                      width: `calc(100% - ${100 / node.children.length}%)`, // Rough approximation to center lines
                      left: `calc(${50 / node.children.length}%)`,
                      right: `calc(${50 / node.children.length}%)`
                    }}>
               </div>
             )}
             
             {node.children.map((child, index) => (
                <div key={child.id} className="flex flex-col items-center px-4 relative">
                   {/* Vertical line up to horizontal bar */}
                   <div className="w-px h-4 bg-slate-300 absolute top-0 left-1/2 -ml-px -mt-4"></div>
                   
                   {node.children.length > 1 && (
                     <>
                        {index === 0 && <div className="absolute top-[-1px] right-0 w-1/2 h-px bg-slate-300 -mt-4"></div>}
                        {index === node.children.length - 1 && <div className="absolute top-[-1px] left-0 w-1/2 h-px bg-slate-300 -mt-4"></div>}
                        {index > 0 && index < node.children.length - 1 && <div className="absolute top-[-1px] left-0 w-full h-px bg-slate-300 -mt-4"></div>}
                     </>
                   )}

                   <OrgNode node={child} onEdit={onEdit} />
                </div>
             ))}
          </div>
        </>
      )}
    </div>
  );
};

export const OrgChart: React.FC<OrgChartProps> = ({ employees, onEdit }) => {
  const tree = useMemo(() => {
    const employeeMap = new Map<string, TreeNode>();
    
    // 1. Initialize Nodes
    employees.forEach(emp => {
      employeeMap.set(emp.id, { ...emp, children: [] });
    });

    const roots: TreeNode[] = [];

    // 2. Build Tree
    employees.forEach(emp => {
      const node = employeeMap.get(emp.id)!;
      if (emp.managerId && employeeMap.has(emp.managerId)) {
        const manager = employeeMap.get(emp.managerId)!;
        manager.children.push(node);
      } else {
        roots.push(node);
      }
    });

    return roots;
  }, [employees]);

  if (employees.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-96 text-slate-400">
        <User size={48} className="mb-4 opacity-20" />
        <p>ไม่มีข้อมูลพนักงาน</p>
      </div>
    );
  }

  return (
    <div className="w-full overflow-auto bg-slate-50 rounded-2xl border border-slate-200 p-8 custom-scrollbar">
      <div className="min-w-fit flex justify-center gap-16 pb-12">
        {tree.map(root => (
          <OrgNode key={root.id} node={root} onEdit={onEdit} />
        ))}
      </div>
    </div>
  );
};
