
import React, { useState, useMemo } from 'react';
import { Employee, Role, Department, EmployeeStatus, EmploymentType, Gender, Nationality, Religion, MaritalStatus, EmergencyContact, RolePermissions } from '../types';
import { Permissions } from '../utils/permissions';
import { Search, Plus, User, Briefcase, Mail, Phone, MapPin, Edit2, X, Save, Shield, Calendar, DollarSign, Camera, Filter, MoreHorizontal, LayoutGrid, Table, GitMerge, UserPlus, HeartPulse, CreditCard, Coins } from 'lucide-react';
import { OrgChart } from './OrgChart';

interface EmployeeListProps {
  employees: Employee[];
  onSaveEmployee: (employee: Employee) => void;
  currentUser: Employee;
  rolePermissions?: RolePermissions[];
}

export const EmployeeList: React.FC<EmployeeListProps> = ({ employees, onSaveEmployee, currentUser, rolePermissions }) => {
  const [viewMode, setViewMode] = useState<'grid' | 'table' | 'org'>('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [showModal, setShowModal] = useState(false);
  
  // For editing/creating
  const [editingEmployee, setEditingEmployee] = useState<Partial<Employee>>({});

  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => {
      const matchesSearch = (emp.firstName + ' ' + emp.lastName).toLowerCase().includes(searchTerm.toLowerCase()) || 
                            emp.email.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesDept = selectedDept === 'All' || emp.department === selectedDept;
      return matchesSearch && matchesDept;
    });
  }, [employees, searchTerm, selectedDept]);

  const handleAddNew = () => {
    setEditingEmployee({
      // Default values
      firstName: '', lastName: '', email: '', position: '', 
      department: Department.IT, role: Role.STAFF, 
      status: EmployeeStatus.PROBATION, employmentType: EmploymentType.MONTHLY,
      joinDate: new Date().toISOString().split('T')[0],
      salary: 15000,
      avatarUrl: `https://ui-avatars.com/api/?name=New+User&background=random`,
      orgId: currentUser.orgId,
      gender: Gender.MALE,
      emergencyContact: { firstName: '', lastName: '', phone: '', relation: '' }
    });
    setShowModal(true);
  };

  const handleEdit = (emp: Employee) => {
    setEditingEmployee({ 
        ...emp,
        emergencyContact: emp.emergencyContact || { firstName: '', lastName: '', phone: '', relation: '' }
    });
    setShowModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingEmployee.firstName && editingEmployee.email) {
      onSaveEmployee({
        ...editingEmployee,
        id: editingEmployee.id || `E${Date.now()}`
      } as Employee);
      setShowModal(false);
    }
  };

  const updateEmergencyContact = (field: keyof EmergencyContact, value: string) => {
    setEditingEmployee(prev => ({
      ...prev,
      emergencyContact: {
        firstName: prev.emergencyContact?.firstName || '',
        lastName: prev.emergencyContact?.lastName || '',
        phone: prev.emergencyContact?.phone || '',
        relation: prev.emergencyContact?.relation || '',
        [field]: value
      } as EmergencyContact
    }));
  };

  const canEdit = Permissions.canManageEmployees(currentUser.role, rolePermissions);

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">รายชื่อพนักงาน ({employees.length})</h2>
          <p className="text-slate-500 text-sm">จัดการข้อมูลพนักงานและโครงสร้างองค์กร</p>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
             <div className="relative flex-1 md:flex-none">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="ค้นหาชื่อ, อีเมล..." 
                  className="pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full md:w-64"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
             </div>
             
             <div className="hidden md:block w-px h-8 bg-slate-200 mx-1"></div>

             <div className="flex bg-slate-100 p-1 rounded-xl">
                <button onClick={() => setViewMode('grid')} className={`p-2 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-400'}`}><LayoutGrid size={18} /></button>
                <button onClick={() => setViewMode('table')} className={`p-2 rounded-lg transition-colors ${viewMode === 'table' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-400'}`}><Table size={18} /></button>
                <button onClick={() => setViewMode('org')} className={`p-2 rounded-lg transition-colors ${viewMode === 'org' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-400'}`}><GitMerge size={18} /></button>
             </div>

             {canEdit && (
               <button 
                 onClick={handleAddNew}
                 className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-indigo-200 flex items-center gap-2 whitespace-nowrap ml-2 transition-all active:scale-95"
               >
                 <UserPlus size={18} /> เพิ่มพนักงาน
               </button>
             )}
        </div>
      </div>

      {/* Grid View */}
      {viewMode === 'grid' && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredEmployees.map(emp => (
            <div key={emp.id} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all group relative">
               <div className="flex justify-between items-start mb-4">
                  <div className="flex gap-4">
                     <img src={emp.avatarUrl} className="w-14 h-14 rounded-full border-2 border-white shadow-sm object-cover" />
                     <div>
                        <h3 className="font-bold text-slate-800 text-lg">{emp.firstName} {emp.lastName}</h3>
                        <p className="text-sm text-slate-500">{emp.position}</p>
                        <span className="inline-block mt-1 px-2 py-0.5 bg-slate-100 text-slate-600 text-[10px] font-bold rounded uppercase tracking-wide">{emp.department}</span>
                     </div>
                  </div>
                  {canEdit && (
                    <button onClick={() => handleEdit(emp)} className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100">
                       <Edit2 size={18} />
                    </button>
                  )}
               </div>
               
               <div className="grid grid-cols-2 gap-4 mt-4 pt-4 border-t border-slate-50">
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                     <Mail size={14} /> <span className="truncate">{emp.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                     <Phone size={14} /> <span>{emp.phone || '-'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                     <Calendar size={14} /> <span>Joined {new Date(emp.joinDate).getFullYear()}</span>
                  </div>
               </div>
            </div>
          ))}
        </div>
      )}

      {/* Table View */}
      {viewMode === 'table' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
           <table className="w-full text-left">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase">
                 <tr>
                    <th className="px-6 py-4">พนักงาน (Employee)</th>
                    <th className="px-6 py-4">ตำแหน่ง (Position)</th>
                    <th className="px-6 py-4">แผนก (Department)</th>
                    <th className="px-6 py-4">สถานะ (Status)</th>
                    <th className="px-6 py-4">ติดต่อ (Contact)</th>
                    <th className="px-6 py-4 text-right">จัดการ (Action)</th>
                 </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                 {filteredEmployees.map(emp => (
                    <tr key={emp.id} className="hover:bg-slate-50 transition-colors">
                       <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                             <img src={emp.avatarUrl} className="w-8 h-8 rounded-full border border-slate-200" />
                             <span className="font-bold text-slate-700">{emp.firstName} {emp.lastName}</span>
                          </div>
                       </td>
                       <td className="px-6 py-4 text-slate-600">{emp.position}</td>
                       <td className="px-6 py-4"><span className="bg-slate-100 text-slate-600 px-2 py-1 rounded text-xs font-bold">{emp.department}</span></td>
                       <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded text-xs font-bold ${emp.status === EmployeeStatus.PERMANENT ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                             {emp.status}
                          </span>
                       </td>
                       <td className="px-6 py-4 text-slate-500">{emp.email}</td>
                       <td className="px-6 py-4 text-right">
                          {canEdit && (
                             <button onClick={() => handleEdit(emp)} className="text-indigo-600 hover:text-indigo-800 font-bold text-xs">แก้ไข (Edit)</button>
                          )}
                       </td>
                    </tr>
                 ))}
              </tbody>
           </table>
        </div>
      )}

      {viewMode === 'org' && (
         <OrgChart 
            employees={searchTerm ? filteredEmployees : employees} 
            onEdit={handleEdit} 
         />
      )}

      {/* --- ADD/EDIT MODAL --- */}
      {showModal && (
         <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl h-[90vh] flex flex-col animate-fade-in-up">
               <div className="px-8 py-5 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                  <h3 className="font-bold text-xl text-slate-800 flex items-center gap-2">
                     {editingEmployee.id ? <User size={24} className="text-indigo-600" /> : <UserPlus size={24} className="text-indigo-600" />}
                     {editingEmployee.id ? 'แก้ไขข้อมูลพนักงาน (Edit Employee)' : 'เพิ่มพนักงานใหม่ (Add Employee)'}
                  </h3>
                  <button onClick={() => setShowModal(false)} className="p-2 hover:bg-slate-200 rounded-full text-slate-400 transition-colors"><X size={24}/></button>
               </div>
               
               <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                  <form id="empForm" onSubmit={handleSave} className="space-y-8">
                     
                     {/* 1. Personal Info */}
                     <div>
                        <h4 className="font-bold text-slate-700 mb-4 flex items-center gap-2"><User size={18}/> ข้อมูลส่วนตัว (Personal Info)</h4>
                        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
                           <div className="md:col-span-3 flex flex-col items-center gap-4">
                              <div className="w-32 h-32 rounded-full bg-slate-100 border-4 border-white shadow-lg overflow-hidden relative group cursor-pointer">
                                 <img src={editingEmployee.avatarUrl} className="w-full h-full object-cover" />
                                 <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Camera className="text-white" size={24} />
                                 </div>
                              </div>
                              <div className="text-center">
                                 <button type="button" className="text-xs font-bold text-indigo-600 hover:underline">เปลี่ยนรูปโปรไฟล์</button>
                              </div>
                           </div>
                           
                           <div className="md:col-span-9 grid grid-cols-1 md:grid-cols-2 gap-6">
                              <div>
                                 <label className="block text-xs font-bold text-slate-500 mb-1">ชื่อจริง (First Name)</label>
                                 <input required type="text" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none" value={editingEmployee.firstName} onChange={e => setEditingEmployee({...editingEmployee, firstName: e.target.value})} />
                              </div>
                              <div>
                                 <label className="block text-xs font-bold text-slate-500 mb-1">นามสกุล (Last Name)</label>
                                 <input required type="text" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none" value={editingEmployee.lastName} onChange={e => setEditingEmployee({...editingEmployee, lastName: e.target.value})} />
                              </div>
                              <div>
                                 <label className="block text-xs font-bold text-slate-500 mb-1">เลขบัตรประชาชน (National ID)</label>
                                 <input required type="text" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none" value={editingEmployee.nationalId || ''} onChange={e => setEditingEmployee({...editingEmployee, nationalId: e.target.value})} />
                              </div>
                              <div>
                                 <label className="block text-xs font-bold text-slate-500 mb-1">เพศ (Gender)</label>
                                 <select required className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none bg-white" value={editingEmployee.gender} onChange={e => setEditingEmployee({...editingEmployee, gender: e.target.value as Gender})}>
                                    <option value="">เลือกเพศ</option>
                                    {Object.values(Gender).map(g => <option key={g} value={g}>{g}</option>)}
                                 </select>
                              </div>
                              <div>
                                 <label className="block text-xs font-bold text-slate-500 mb-1">วันเกิด (Date of Birth)</label>
                                 <input required type="date" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none" value={editingEmployee.birthDate || ''} onChange={e => setEditingEmployee({...editingEmployee, birthDate: e.target.value})} />
                              </div>
                              <div>
                                 <label className="block text-xs font-bold text-slate-500 mb-1">เบอร์โทรศัพท์ (Phone)</label>
                                 <input required type="tel" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none" value={editingEmployee.phone || ''} onChange={e => setEditingEmployee({...editingEmployee, phone: e.target.value})} />
                              </div>
                              <div className="md:col-span-2">
                                 <label className="block text-xs font-bold text-slate-500 mb-1">อีเมล (Email)</label>
                                 <input required type="email" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none" value={editingEmployee.email} onChange={e => setEditingEmployee({...editingEmployee, email: e.target.value})} />
                              </div>
                              <div className="md:col-span-2">
                                 <label className="block text-xs font-bold text-slate-500 mb-1">ที่อยู่ปัจจุบัน (Address)</label>
                                 <textarea required className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none resize-none h-20" value={editingEmployee.address || ''} onChange={e => setEditingEmployee({...editingEmployee, address: e.target.value})}></textarea>
                              </div>
                           </div>
                        </div>
                     </div>

                     <div className="h-px bg-slate-100"></div>

                     {/* 2. Emergency Contact */}
                     <div>
                        <h4 className="font-bold text-slate-700 mb-4 flex items-center gap-2"><HeartPulse size={18}/> ผู้ติดต่อฉุกเฉิน (Emergency Contact)</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-red-50/50 p-6 rounded-2xl border border-red-100">
                           <div>
                              <label className="block text-xs font-bold text-slate-500 mb-1">ชื่อจริง (First Name)</label>
                              <input type="text" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none bg-white" value={editingEmployee.emergencyContact?.firstName || ''} onChange={e => updateEmergencyContact('firstName', e.target.value)} />
                           </div>
                           <div>
                              <label className="block text-xs font-bold text-slate-500 mb-1">นามสกุล (Last Name)</label>
                              <input type="text" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none bg-white" value={editingEmployee.emergencyContact?.lastName || ''} onChange={e => updateEmergencyContact('lastName', e.target.value)} />
                           </div>
                           <div>
                              <label className="block text-xs font-bold text-slate-500 mb-1">ความสัมพันธ์ (Relation)</label>
                              <input type="text" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none bg-white" value={editingEmployee.emergencyContact?.relation || ''} onChange={e => updateEmergencyContact('relation', e.target.value)} />
                           </div>
                           <div className="md:col-span-3">
                              <label className="block text-xs font-bold text-slate-500 mb-1">เบอร์ติดต่อ (Phone)</label>
                              <input type="tel" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none bg-white" value={editingEmployee.emergencyContact?.phone || ''} onChange={e => updateEmergencyContact('phone', e.target.value)} />
                           </div>
                        </div>
                     </div>

                     <div className="h-px bg-slate-100"></div>

                     {/* 3. Employment Details */}
                     <div>
                        <h4 className="font-bold text-slate-700 mb-4 flex items-center gap-2"><Briefcase size={18}/> ข้อมูลการทำงาน (Employment)</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                           <div>
                              <label className="block text-xs font-bold text-slate-500 mb-1">ตำแหน่ง (Position)</label>
                              <input required type="text" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none" value={editingEmployee.position} onChange={e => setEditingEmployee({...editingEmployee, position: e.target.value})} />
                           </div>
                           <div>
                              <label className="block text-xs font-bold text-slate-500 mb-1">แผนก (Department)</label>
                              <select className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none bg-white" value={editingEmployee.department} onChange={e => setEditingEmployee({...editingEmployee, department: e.target.value})}>
                                 {Object.values(Department).map(d => <option key={d} value={d}>{d}</option>)}
                              </select>
                           </div>
                           <div>
                              <label className="block text-xs font-bold text-slate-500 mb-1">บทบาท (Role)</label>
                              <select className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none bg-white" value={editingEmployee.role} onChange={e => setEditingEmployee({...editingEmployee, role: e.target.value as Role})}>
                                 {Object.values(Role).map(r => <option key={r} value={r}>{r}</option>)}
                              </select>
                           </div>
                           <div>
                              <label className="block text-xs font-bold text-slate-500 mb-1">สถานะ (Status)</label>
                              <select className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none bg-white" value={editingEmployee.status} onChange={e => setEditingEmployee({...editingEmployee, status: e.target.value as EmployeeStatus})}>
                                 {Object.values(EmployeeStatus).map(s => <option key={s} value={s}>{s}</option>)}
                              </select>
                           </div>
                           <div>
                              <label className="block text-xs font-bold text-slate-500 mb-1">ประเภทการจ้าง (Type)</label>
                              <select className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none bg-white" value={editingEmployee.employmentType} onChange={e => setEditingEmployee({...editingEmployee, employmentType: e.target.value as EmploymentType})}>
                                 {Object.values(EmploymentType).map(t => <option key={t} value={t}>{t}</option>)}
                              </select>
                           </div>
                           <div>
                              <label className="block text-xs font-bold text-slate-500 mb-1">วันที่เริ่มงาน (Join Date)</label>
                              <input type="date" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none" value={editingEmployee.joinDate} onChange={e => setEditingEmployee({...editingEmployee, joinDate: e.target.value})} />
                           </div>
                           <div>
                              <label className="block text-xs font-bold text-slate-500 mb-1">หัวหน้างานโดยตรง (Manager)</label>
                              <select 
                                className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none bg-white" 
                                value={editingEmployee.managerId || ''} 
                                onChange={e => setEditingEmployee({...editingEmployee, managerId: e.target.value || null})}
                              >
                                 <option value="">-- ไม่ระบุ (No Manager) --</option>
                                 {employees
                                    .filter(emp => emp.id !== editingEmployee.id)
                                    .map(emp => (
                                    <option key={emp.id} value={emp.id}>
                                       {emp.firstName} {emp.lastName} ({emp.position})
                                    </option>
                                 ))}
                              </select>
                           </div>
                        </div>
                     </div>

                     <div className="h-px bg-slate-100"></div>

                     {/* 4. Salary & Bank & Allowances */}
                     <div>
                        <h4 className="font-bold text-slate-700 mb-4 flex items-center gap-2"><CreditCard size={18}/> เงินเดือน & บัญชี (Payroll)</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                           <div>
                              <label className="block text-xs font-bold text-slate-500 mb-1">เงินเดือนฐาน (Base Salary)</label>
                              <input type="number" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none font-mono font-bold text-slate-800" value={editingEmployee.salary} onChange={e => setEditingEmployee({...editingEmployee, salary: Number(e.target.value)})} />
                           </div>
                           <div>
                              <label className="block text-xs font-bold text-slate-500 mb-1">ชื่อธนาคาร (Bank Name)</label>
                              <input type="text" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none" value={editingEmployee.bankName || ''} onChange={e => setEditingEmployee({...editingEmployee, bankName: e.target.value})} placeholder="e.g. KBANK" />
                           </div>
                           <div>
                              <label className="block text-xs font-bold text-slate-500 mb-1">เลขบัญชี (Account No.)</label>
                              <input type="text" className="w-full border border-slate-300 rounded-xl p-3 focus:ring-2 focus:ring-indigo-500 outline-none font-mono" value={editingEmployee.bankAccountNumber || ''} onChange={e => setEditingEmployee({...editingEmployee, bankAccountNumber: e.target.value})} placeholder="XXX-X-XXXXX-X" />
                           </div>
                        </div>

                        {/* Additional Allowances Section */}
                        <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                           <h5 className="font-bold text-slate-700 mb-4 flex items-center gap-2"><Coins size={16} className="text-amber-500"/> เงินเพิ่มประจำ/สวัสดิการ (Base Allowances)</h5>
                           <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                              <div>
                                 <label className="block text-xs font-bold text-slate-500 mb-1">ค่าตำแหน่ง (Position)</label>
                                 <input type="number" className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none bg-white" placeholder="0" value={editingEmployee.basePositionAllowance || ''} onChange={e => setEditingEmployee({...editingEmployee, basePositionAllowance: Number(e.target.value)})} />
                              </div>
                              <div>
                                 <label className="block text-xs font-bold text-slate-500 mb-1">ค่าเดินทาง (Travel)</label>
                                 <input type="number" className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none bg-white" placeholder="0" value={editingEmployee.baseTravelAllowance || ''} onChange={e => setEditingEmployee({...editingEmployee, baseTravelAllowance: Number(e.target.value)})} />
                              </div>
                              <div>
                                 <label className="block text-xs font-bold text-slate-500 mb-1">เบี้ยเลี้ยง (Per Diem)</label>
                                 <input type="number" className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none bg-white" placeholder="0" value={editingEmployee.basePerDiem || ''} onChange={e => setEditingEmployee({...editingEmployee, basePerDiem: Number(e.target.value)})} />
                              </div>
                              <div>
                                 <label className="block text-xs font-bold text-slate-500 mb-1">เบี้ยขยัน (Diligence)</label>
                                 <input type="number" className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none bg-white" placeholder="0" value={editingEmployee.baseDiligenceAllowance || ''} onChange={e => setEditingEmployee({...editingEmployee, baseDiligenceAllowance: Number(e.target.value)})} />
                              </div>
                           </div>
                        </div>
                     </div>

                  </form>
               </div>

               <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end gap-3 rounded-b-2xl">
                  <button type="button" onClick={() => setShowModal(false)} className="px-6 py-3 text-slate-500 hover:bg-slate-200 rounded-xl font-bold transition-colors">ยกเลิก</button>
                  <button type="submit" form="empForm" className="px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-lg shadow-indigo-200 transition-all flex items-center gap-2">
                     <Save size={18} /> บันทึกข้อมูล
                  </button>
               </div>
            </div>
         </div>
      )}
    </div>
  );
};
