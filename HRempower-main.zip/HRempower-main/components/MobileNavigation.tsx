
import React from 'react';
import { Tab, Role } from '../types';
import { LayoutDashboard, Clock, Calendar, User, MessageSquare } from 'lucide-react';

interface MobileNavigationProps {
  activeTab: Tab;
  onNavigate: (tab: Tab) => void;
  toggleMenu: () => void;
  role: Role;
  unreadChatCount?: number; 
}

export const MobileNavigation: React.FC<MobileNavigationProps> = ({ activeTab, onNavigate, toggleMenu, role, unreadChatCount = 0 }) => {
  
  const navItems = [
    { tab: Tab.DASHBOARD, icon: LayoutDashboard, label: 'หน้าแรก' },
    { tab: Tab.ATTENDANCE, icon: Clock, label: 'ลงเวลา' },
    { tab: Tab.COLLAB, icon: MessageSquare, label: 'แชท', badge: unreadChatCount }, 
    { tab: Tab.LEAVE, icon: Calendar, label: 'ลา' },
    { tab: Tab.PROFILE, icon: User, label: 'ฉัน' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-4 py-2 pb-safe z-40 md:hidden shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
      <div className="flex justify-between items-center">
        {navItems.map((item) => (
          <button
            key={item.tab}
            onClick={() => onNavigate(item.tab)}
            className={`relative flex flex-col items-center gap-1 p-2 rounded-xl transition-all w-16 ${
              activeTab === item.tab 
                ? 'text-indigo-600 bg-indigo-50' 
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <div className="relative">
              <item.icon size={22} strokeWidth={activeTab === item.tab ? 2.5 : 2} />
              {/* Notification Badge */}
              {item.badge && item.badge > 0 ? (
                <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full min-w-[16px] flex items-center justify-center border-2 border-white animate-bounce">
                  {item.badge > 99 ? '99+' : item.badge}
                </span>
              ) : null}
            </div>
            <span className="text-[10px] font-bold">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
