
import React, { useState } from 'react';
import { Employee, Role } from '../types';
import { Sparkles, User, Lock, ArrowRight, AlertCircle, Phone, Mail } from 'lucide-react';

interface LoginProps {
  employees: Employee[];
  onLogin: (employee: Employee) => void;
}

export const Login: React.FC<LoginProps> = ({ employees, onLogin }) => {
  const [identifier, setIdentifier] = useState(''); // Email or Username
  const [password, setPassword] = useState(''); // Phone or Password
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      // 1. Check Super Admin (Yafad)
      if (identifier === 'yafad' && password === '1000000') {
        const admin = employees.find(e => e.role === Role.SUPER_ADMIN);
        if (admin) {
          onLogin(admin);
          return;
        }
      }

      // 2. Check Employee
      const foundEmployee = employees.find(e => 
        e.email.toLowerCase() === identifier.toLowerCase() || 
        (e.role === Role.SUPER_ADMIN && e.email === identifier) 
      );

      if (foundEmployee) {
        // A. Check if user has a specific password set (New System)
        if (foundEmployee.password) {
           if (foundEmployee.password === password) {
              onLogin(foundEmployee);
              setIsLoading(false);
              return;
           }
        } 
        // B. Fallback to Phone Number (Legacy / Default)
        else {
           // Normalize phone input (remove spaces, dashes) for comparison ONLY if using phone auth
           const cleanInput = password.replace(/[^0-9]/g, '');
           const empPhone = foundEmployee.phone?.replace(/[^0-9]/g, '');
           
           if (empPhone === cleanInput) {
              onLogin(foundEmployee);
              setIsLoading(false);
              return;
           }
        }
      }

      setError('ชื่อผู้ใช้งานหรือรหัสผ่านไม่ถูกต้อง (Invalid Username or Password)');
      setIsLoading(false);
    }, 800);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-900 via-brand-900 to-slate-900 relative overflow-hidden font-sans">
      {/* Background Ambience */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-[100px] animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-[100px] animate-pulse delay-1000"></div>
      </div>

      <div className="w-full max-w-md p-8 relative z-10">
        {/* Logo Section */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-brand-500 to-indigo-500 shadow-glow mb-4 transform rotate-6 hover:rotate-0 transition-transform duration-500">
            <Sparkles className="text-white w-8 h-8" />
          </div>
          <h1 className="text-3xl font-bold text-white tracking-tight mb-2">EmpowerHR</h1>
          <p className="text-slate-400 text-sm">ระบบบริหารจัดการบุคคลมืออาชีพ (Professional Workforce Management)</p>
        </div>

        {/* Login Card */}
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-8 shadow-2xl">
          <form onSubmit={handleLogin} className="space-y-6">
            
            {/* Identifier Input */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider pl-1">อีเมล / ชื่อผู้ใช้ (Email / Username)</label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-slate-400 group-focus-within:text-white transition-colors" />
                </div>
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  className="w-full bg-slate-900/50 border border-slate-700 text-white text-sm rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent block w-full pl-11 p-3.5 placeholder-slate-500 transition-all outline-none"
                  placeholder="name@company.com"
                />
              </div>
            </div>

            {/* Password Input */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider pl-1">รหัสผ่าน (Password)</label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-slate-400 group-focus-within:text-white transition-colors" />
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-900/50 border border-slate-700 text-white text-sm rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent block w-full pl-11 p-3.5 placeholder-slate-500 transition-all outline-none"
                  placeholder="••••••••"
                />
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/20 border border-red-500/50 text-red-200 text-xs font-medium animate-fade-in">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {error}
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white font-bold py-3.5 px-4 rounded-xl shadow-lg transform transition-all active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed group"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <>
                  เข้าสู่ระบบ (Sign In) <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </form>

          {/* Footer */}
          <div className="mt-8 text-center">
            <p className="text-slate-500 text-xs">
              ติดต่อฝ่ายบุคคลหากลืมรหัสผ่าน (Contact HR if forgot password)
            </p>
          </div>
        </div>
        
        <div className="text-center mt-6 text-slate-600 text-[10px] uppercase tracking-widest font-bold">
          EmpowerHR v2.5
        </div>
      </div>
    </div>
  );
};
