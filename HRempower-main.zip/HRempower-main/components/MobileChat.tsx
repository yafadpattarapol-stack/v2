
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Employee, TeamMessage, Channel } from '../types';
import { Search, ChevronLeft, Send, Image as ImageIcon, Paperclip, Hash, Lock, MoreVertical, Camera } from 'lucide-react';

interface MobileChatProps {
  currentUser: Employee;
  employees: Employee[];
  teamMessages: TeamMessage[];
  channels: Channel[];
  onSendMessage: (content: string, channelId?: string, receiverId?: string) => void;
  typingChatId?: string | null; // ID of the channel/user currently typing
}

export const MobileChat: React.FC<MobileChatProps> = ({ 
  currentUser, employees, teamMessages, channels, onSendMessage, typingChatId 
}) => {
  const [view, setView] = useState<'list' | 'room'>('list');
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [activeChatType, setActiveChatType] = useState<'channel' | 'direct'>('channel');
  const [inputMessage, setInputMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Scroll to bottom on new message
  useEffect(() => {
    if (view === 'room') {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [teamMessages, view, activeChatId, typingChatId]);

  // Auto-resize textarea
  const handleInputResize = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputMessage(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = `${Math.min(e.target.scrollHeight, 100)}px`;
  };

  // --- Data Logic ---
  const getEmployee = (id: string) => employees.find(e => e.id === id);
  const getChannel = (id: string) => channels.find(c => c.id === id);

  const filteredMessages = useMemo(() => {
    if (!activeChatId) return [];
    if (activeChatType === 'channel') {
      return teamMessages.filter(m => m.channelId === activeChatId);
    } else {
      return teamMessages.filter(m => 
        (m.senderId === currentUser.id && m.receiverId === activeChatId) ||
        (m.senderId === activeChatId && m.receiverId === currentUser.id)
      );
    }
  }, [teamMessages, activeChatId, activeChatType, currentUser.id]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || !activeChatId) return;

    if (activeChatType === 'channel') {
      onSendMessage(inputMessage, activeChatId, undefined);
    } else {
      onSendMessage(inputMessage, undefined, activeChatId);
    }
    setInputMessage('');
    if(textareaRef.current) textareaRef.current.style.height = 'auto';
  };

  const getLastMessage = (id: string, type: 'channel' | 'direct') => {
     let msgs = [];
     if (type === 'channel') {
        msgs = teamMessages.filter(m => m.channelId === id);
     } else {
        msgs = teamMessages.filter(m => (m.senderId === currentUser.id && m.receiverId === id) || (m.senderId === id && m.receiverId === currentUser.id));
     }
     if (msgs.length === 0) return null;
     return msgs[msgs.length - 1];
  };

  const formatTime = (dateStr: string) => {
     const date = new Date(dateStr);
     const now = new Date();
     if (date.toDateString() === now.toDateString()) {
        return date.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' });
     }
     return date.toLocaleDateString('th-TH', { day: 'numeric', month: 'short' });
  };

  // --- RENDER LIST VIEW ---
  const renderList = () => (
    <div className="flex flex-col h-full bg-slate-50 animate-fade-in pb-20">
       <div className="px-6 pt-6 pb-4 bg-white sticky top-0 z-10 border-b border-slate-100">
          <h2 className="text-2xl font-bold text-slate-800 mb-4">แชท (Chats)</h2>
          <div className="relative">
             <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
             <input 
               type="text" 
               placeholder="ค้นหาชื่อ หรือข้อความ..." 
               className="w-full pl-10 pr-4 py-3 bg-slate-100 border-none rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
             />
          </div>
       </div>

       <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-6">
          
          {/* Channels Section */}
          <div>
             <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 px-2">Official Channels</h3>
             <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                {channels.filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase())).map((channel, idx) => {
                   const lastMsg = getLastMessage(channel.id, 'channel');
                   return (
                      <div 
                        key={channel.id} 
                        onClick={() => { setActiveChatId(channel.id); setActiveChatType('channel'); setView('room'); }}
                        className={`p-4 flex items-center gap-4 active:bg-slate-50 transition-colors cursor-pointer ${idx !== channels.length - 1 ? 'border-b border-slate-50' : ''}`}
                      >
                         <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center shrink-0">
                            {channel.isPrivate ? <Lock size={20} /> : <Hash size={20} />}
                         </div>
                         <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-baseline mb-1">
                               <h4 className="font-bold text-slate-800 truncate">{channel.name}</h4>
                               {lastMsg && <span className="text-[10px] text-slate-400 shrink-0">{formatTime(lastMsg.timestamp)}</span>}
                            </div>
                            <p className="text-sm text-slate-500 truncate">
                               {lastMsg ? <span className="text-slate-700 font-medium">{getEmployee(lastMsg.senderId)?.firstName}: <span className="font-normal text-slate-500">{lastMsg.content}</span></span> : <span className="italic opacity-50">No messages yet</span>}
                            </p>
                         </div>
                      </div>
                   );
                })}
             </div>
          </div>

          {/* Direct Messages Section */}
          <div>
             <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 px-2">Direct Messages</h3>
             <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
                {employees
                  .filter(e => e.id !== currentUser.id)
                  .filter(e => e.firstName.toLowerCase().includes(searchTerm.toLowerCase()) || e.lastName.toLowerCase().includes(searchTerm.toLowerCase()))
                  .map((emp, idx) => {
                   const lastMsg = getLastMessage(emp.id, 'direct');
                   const employeeListFiltered = employees.filter(e => e.id !== currentUser.id);
                   const isTypingHere = typingChatId === emp.id;

                   return (
                      <div 
                        key={emp.id} 
                        onClick={() => { setActiveChatId(emp.id); setActiveChatType('direct'); setView('room'); }}
                        className={`p-4 flex items-center gap-4 active:bg-slate-50 transition-colors cursor-pointer ${idx !== employeeListFiltered.length - 1 ? 'border-b border-slate-50' : ''}`}
                      >
                         <div className="relative shrink-0">
                            <img src={emp.avatarUrl} className="w-12 h-12 rounded-full border border-slate-100" />
                            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                         </div>
                         <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-baseline mb-1">
                               <h4 className="font-bold text-slate-800 truncate">{emp.firstName} {emp.lastName}</h4>
                               {lastMsg && <span className="text-[10px] text-slate-400 shrink-0">{formatTime(lastMsg.timestamp)}</span>}
                            </div>
                            <p className={`text-sm truncate ${lastMsg ? 'text-slate-600' : 'text-slate-400 italic'}`}>
                               {isTypingHere ? <span className="text-indigo-600 font-bold animate-pulse">กำลังพิมพ์...</span> : (lastMsg ? lastMsg.content : `Start chatting with ${emp.firstName}`)}
                            </p>
                         </div>
                      </div>
                   );
                })}
             </div>
          </div>

       </div>
    </div>
  );

  // --- RENDER CHAT ROOM ---
  const renderRoom = () => {
     const chatTitle = activeChatType === 'channel' ? getChannel(activeChatId!)?.name : getEmployee(activeChatId!)?.firstName;
     const chatSubtitle = activeChatType === 'channel' ? 'Official Group' : getEmployee(activeChatId!)?.position;
     const chatAvatar = activeChatType === 'channel' ? null : getEmployee(activeChatId!)?.avatarUrl;
     
     // Check if current active chat is the one typing
     const isTyping = activeChatId === typingChatId;

     return (
        <div className="flex flex-col h-full bg-[#f0f2f5] fixed inset-0 z-50 animate-in slide-in-from-right duration-200">
           {/* Header */}
           <div className="px-4 py-3 bg-white border-b border-slate-200 flex items-center justify-between shadow-sm shrink-0">
              <div className="flex items-center gap-2">
                 <button onClick={() => setView('list')} className="p-2 -ml-2 text-slate-500 hover:bg-slate-50 rounded-full">
                    <ChevronLeft size={24} />
                 </button>
                 {activeChatType === 'channel' ? (
                    <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-lg">#</div>
                 ) : (
                    <img src={chatAvatar} className="w-10 h-10 rounded-full border border-slate-100" />
                 )}
                 <div>
                    <h3 className="font-bold text-slate-800 text-base leading-tight">{chatTitle}</h3>
                    <p className="text-[10px] text-green-600 font-medium flex items-center gap-1">
                       <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span> Online
                    </p>
                 </div>
              </div>
              <button className="p-2 text-slate-400 hover:text-slate-600"><MoreVertical size={20}/></button>
           </div>

           {/* Messages Area */}
           <div className="flex-1 overflow-y-auto p-4 custom-scrollbar bg-[#eef0f3]">
              {filteredMessages.map((msg, idx) => {
                 const isMe = msg.senderId === currentUser.id;
                 const sender = getEmployee(msg.senderId);
                 const prevMsg = filteredMessages[idx - 1];
                 const showHeader = !prevMsg || prevMsg.senderId !== msg.senderId || (new Date(msg.timestamp).getTime() - new Date(prevMsg.timestamp).getTime() > 60000 * 5);

                 return (
                    <div key={msg.id} className={`flex flex-col mb-1 ${isMe ? 'items-end' : 'items-start'} ${showHeader ? 'mt-4' : ''}`}>
                       {showHeader && !isMe && activeChatType === 'channel' && (
                          <span className="text-[10px] text-slate-500 ml-10 mb-1">{sender?.firstName}</span>
                       )}
                       <div className="flex items-end gap-2 max-w-[80%]">
                          {!isMe && showHeader && (
                             <img src={sender?.avatarUrl} className="w-8 h-8 rounded-full border border-white shadow-sm mb-1" />
                          )}
                          {!isMe && !showHeader && <div className="w-8" />} {/* Spacer */}
                          
                          <div className={`px-4 py-2.5 rounded-2xl text-sm shadow-sm relative group break-words ${
                             isMe 
                               ? 'bg-indigo-600 text-white rounded-br-sm' 
                               : 'bg-white text-slate-800 rounded-bl-sm border border-slate-200'
                          }`}>
                             {msg.content}
                             <div className={`text-[9px] mt-1 text-right opacity-70 ${isMe ? 'text-indigo-200' : 'text-slate-400'}`}>
                                {new Date(msg.timestamp).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })}
                             </div>
                          </div>
                       </div>
                    </div>
                 );
              })}
              
              {/* Typing Indicator Bubble */}
              {isTyping && (
                 <div className="flex flex-col items-start mt-2 animate-in fade-in slide-in-from-bottom-2 duration-300">
                    <div className="flex items-end gap-2">
                       <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center border border-white mb-1">
                          <span className="text-[8px] text-slate-500">...</span>
                       </div>
                       <div className="bg-white border border-slate-200 px-4 py-3 rounded-2xl rounded-bl-sm shadow-sm">
                          <div className="flex gap-1">
                             <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                             <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-75"></div>
                             <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-150"></div>
                          </div>
                       </div>
                    </div>
                 </div>
              )}

              <div ref={messagesEndRef} />
           </div>

           {/* Input Area */}
           <div className="p-3 bg-white border-t border-slate-200 pb-safe">
              <form onSubmit={handleSendMessage} className="flex items-end gap-2">
                 <div className="flex gap-1 text-slate-400 pb-2">
                    <button type="button" className="p-2 hover:bg-slate-100 rounded-full"><Camera size={22}/></button>
                    <button type="button" className="p-2 hover:bg-slate-100 rounded-full"><ImageIcon size={22}/></button>
                 </div>
                 <div className="flex-1 bg-slate-100 rounded-2xl flex items-center px-4 py-2 border border-transparent focus-within:border-indigo-300 focus-within:bg-white transition-all">
                    <textarea 
                      ref={textareaRef}
                      placeholder="พิมพ์ข้อความ..." 
                      className="w-full bg-transparent outline-none text-sm text-slate-800 placeholder:text-slate-400 py-1 resize-none max-h-32"
                      rows={1}
                      value={inputMessage}
                      onChange={handleInputResize}
                      onKeyDown={(e) => { if(e.key === 'Enter' && !e.shiftKey) handleSendMessage(e) }}
                    />
                 </div>
                 <button 
                   type="submit" 
                   disabled={!inputMessage.trim()}
                   className="p-3 bg-indigo-600 text-white rounded-full shadow-lg shadow-indigo-200 disabled:opacity-50 disabled:shadow-none transition-all active:scale-90 flex items-center justify-center mb-0.5"
                 >
                    <Send size={18} className={inputMessage.trim() ? 'ml-0.5' : ''} />
                 </button>
              </form>
           </div>
        </div>
     );
  };

  return view === 'list' ? renderList() : renderRoom();
};
