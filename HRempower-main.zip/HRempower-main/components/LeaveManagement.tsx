
import React, { useState, useMemo } from 'react';
import { Employee, LeaveRequest, LeaveType, LeaveStatus, CompanySettings } from '../types';
import { Calendar as CalendarIcon, Clock, CheckCircle, XCircle, AlertCircle, Plus, LayoutList, ChevronLeft, ChevronRight, FileText, User, MoreHorizontal, PieChart, Filter, Upload, Paperclip, Briefcase, Info } from 'lucide-react';

interface LeaveManagementProps {
  employees: Employee[];
  leaves: LeaveRequest[];
  onAddLeave: (leave: LeaveRequest) => void;
  onUpdateStatus: (leaveId: string, status: LeaveStatus) => void;
  companySettings?: CompanySettings;
}

export const LeaveManagement: React.FC<LeaveManagementProps> = ({ employees, leaves, onAddLeave, onUpdateStatus, companySettings }) => {
  const [showModal, setShowModal] = useState(false);
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list');
  const [calendarDate, setCalendarDate] = useState(new Date());
  
  // Filter State
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('ALL');

  const [newLeave, setNewLeave] = useState<Partial<LeaveRequest> & { attachment?: File | null }>({
    employeeId: '',
    type: companySettings?.leaveQuotas[0]?.type || LeaveType.SICK,
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
    reason: '',
    attachment: null
  });

  // --- Helpers ---
  const getEmployeeName = (id: string) => {
    const emp = employees.find(e => e.id === id);
    return emp ? `${emp.firstName} ${emp.lastName}` : id;
  };

  const getEmployeeAvatar = (id: string) => {
    const emp = employees.find(e => e.id === id);
    return emp?.avatarUrl || '';
  };

  // --- SETTINGS-AWARE CALCULATION ---
  const calculateDuration = (start: string, end: string) => {
    if (!start || !end) return 0;
    
    // Legacy / Fallback Mode if no settings
    if (!companySettings) {
        const s = new Date(start);
        const e = new Date(end);
        const diffTime = Math.abs(e.getTime() - s.getTime());
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    }

    // Smart Mode: Count only Working Days (Excluding Weekends & Holidays defined in Settings)
    let workingDays = 0;
    const cur = new Date(start);
    const stop = new Date(end);
    
    while (cur <= stop) {
        const dayName = cur.toLocaleDateString('en-US', { weekday: 'short' }); // Mon, Tue...
        const dateStr = cur.toISOString().split('T')[0];
        
        const isWorkDay = companySettings.workDays.includes(dayName);
        const isHoliday = companySettings.publicHolidays.some(h => h.date === dateStr);
        
        if (isWorkDay && !isHoliday) {
            workingDays++;
        }
        
        // Next day
        cur.setDate(cur.getDate() + 1);
    }
    
    return workingDays;
  };

  const getUsedDays = (empId: string, type: string) => {
    if (!empId) return 0;
    const activeLeaves = leaves.filter(l => 
      l.employeeId === empId && 
      l.type === type && 
      (l.status === LeaveStatus.APPROVED || l.status === LeaveStatus.PENDING) 
    );
    return activeLeaves.reduce((sum, l) => sum + calculateDuration(l.startDate, l.endDate), 0);
  };

  // Filter Logic
  const filteredLeaves = useMemo(() => {
    return leaves.filter(leave => {
      if (filterStatus === 'ALL') return true;
      if (filterStatus === 'PENDING') return leave.status === LeaveStatus.PENDING;
      if (filterStatus === 'APPROVED') return leave.status === LeaveStatus.APPROVED;
      if (filterStatus === 'REJECTED') return leave.status === LeaveStatus.REJECTED;
      return true;
    }).sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
  }, [leaves, filterStatus]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newLeave.employeeId && newLeave.startDate && newLeave.endDate && newLeave.reason) {
      
      // --- VALIDATION: Check Quota ---
      const duration = calculateDuration(newLeave.startDate, newLeave.endDate);
      const used = getUsedDays(newLeave.employeeId, newLeave.type || '');
      const quotaSetting = companySettings?.leaveQuotas.find(q => q.type === newLeave.type);
      const totalQuota = quotaSetting ? quotaSetting.quota : 0;
      const remaining = Math.max(0, totalQuota - used);

      if (duration === 0) {
         alert("ช่วงเวลาที่เลือกไม่มีวันทำงาน (เป็นวันหยุดทั้งหมด)");
         return;
      }

      if (duration > remaining) {
         alert(`ไม่สามารถส่งคำขอได้: วันลาคงเหลือไม่พอ\n(ใช้ ${duration} วัน / คงเหลือ ${remaining} วัน)`);
         return;
      }
      // -------------------------------

      const emp = employees.find(e => e.id === newLeave.employeeId);
      const leave: LeaveRequest = {
        id: `L${Date.now()}`,
        orgId: emp?.orgId || '',
        employeeId: newLeave.employeeId,
        type: newLeave.type || 'Other',
        startDate: newLeave.startDate,
        endDate: newLeave.endDate,
        reason: newLeave.reason,
        status: LeaveStatus.PENDING,
      };
      onAddLeave(leave);
      setShowModal(false);
      setNewLeave(prev => ({ 
        ...prev, 
        type: companySettings?.leaveQuotas[0]?.type || LeaveType.SICK, 
        startDate: new Date().toISOString().split('T')[0], 
        endDate: new Date().toISOString().split('T')[0], 
        reason: '',
        attachment: null
      }));
    }
  };

  // --- Calendar Logic ---
  const getDaysInMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const getFirstDayOfMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth(), 1).getDay();

  const handlePrevMonth = () => setCalendarDate(new Date(calendarDate.getFullYear(), calendarDate.getMonth() - 1, 1));
  const handleNextMonth = () => setCalendarDate(new Date(calendarDate.getFullYear(), calendarDate.getMonth() + 1, 1));

  const getLeavesForDate = (dateStr: string) => {
    return leaves.filter(leave => 
      leave.status === LeaveStatus.APPROVED &&
      leave.startDate <= dateStr && 
      leave.endDate >= dateStr
    );
  };

  // Stats Calculation
  const stats = useMemo(() => {
    const pending = leaves.filter(l => l.status === LeaveStatus.PENDING).length;
    const approvedMonth = leaves.filter(l => l.status === LeaveStatus.APPROVED && l.startDate.startsWith(calendarDate.toISOString().slice(0, 7))).length;
    const sickLeaves = leaves.filter(l => (l.type === LeaveType.SICK || l.type.includes('ป่วย')) && l.status === LeaveStatus.APPROVED).length;
    
    // Mock Quota for Demo (assuming standard 10 days vacation)
    const myVacationUsed = 3; 
    const vacationQuota = 10;

    return { pending, approvedMonth, sickLeaves, myVacationUsed, vacationQuota };
  }, [leaves, calendarDate]);

  // Leave Type Colors
  const getTypeColor = (type: string) => {
    if (type.includes('ป่วย') || type.includes('Sick')) return 'bg-red-100 text-red-700 border-red-200';
    if (type.includes('พักร้อน') || type.includes('Vacation')) return 'bg-blue-100 text-blue-700 border-blue-200';
    if (type.includes('กิจ') || type.includes('Personal')) return 'bg-amber-100 text-amber-700 border-amber-200';
    return 'bg-slate-100 text-slate-700 border-slate-200';
  };

  const getStatusBadge = (status: LeaveStatus) => {
    switch (status) {
      case LeaveStatus.APPROVED:
        return <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-600 border border-emerald-100"><CheckCircle size={12}/> อนุมัติ</span>;
      case LeaveStatus.REJECTED:
        return <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-red-50 text-red-600 border border-red-100"><XCircle size={12}/> ไม่อนุมัติ</span>;
      default:
        return <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-600 border border-amber-100"><Clock size={12}/> รอตรวจสอบ</span>;
    }
  };

  const renderCalendar = () => {
    const daysInMonth = getDaysInMonth(calendarDate);
    const firstDay = getFirstDayOfMonth(calendarDate);
    const days = [];

    // Empty cells
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="min-h-[100px] bg-slate-50/30 border-b border-r border-slate-100"></div>);
    }

    // Day cells
    for (let day = 1; day <= daysInMonth; day++) {
      const dateStr = `${calendarDate.getFullYear()}-${String(calendarDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const dayName = new Date(dateStr).toLocaleDateString('en-US', { weekday: 'short' });
      
      const dayLeaves = getLeavesForDate(dateStr);
      const isToday = new Date().toISOString().split('T')[0] === dateStr;
      
      // Use Settings for Calendar Display
      const isCompanyHoliday = companySettings?.publicHolidays.some(h => h.date === dateStr);
      const isCompanyWorkDay = companySettings?.workDays.includes(dayName);
      const isWeekend = !isCompanyWorkDay;

      const holidayName = companySettings?.publicHolidays.find(h => h.date === dateStr)?.name;

      days.push(
        <div 
          key={day} 
          onClick={() => {
             setNewLeave(prev => ({ ...prev, startDate: dateStr, endDate: dateStr }));
             setShowModal(true);
          }}
          className={`min-h-[100px] border-b border-r border-slate-100 p-2 relative group transition-colors cursor-pointer hover:bg-slate-50
            ${isToday ? 'bg-blue-50/40' : 'bg-white'} 
            ${isWeekend ? 'bg-slate-50/30' : ''}
            ${isCompanyHoliday ? 'bg-red-50/30' : ''}
          `}
        >
          <div className="flex justify-between items-start mb-1">
             <span className={`text-sm font-semibold w-7 h-7 flex items-center justify-center rounded-full ${isToday ? 'bg-blue-600 text-white shadow-md shadow-blue-200' : isWeekend || isCompanyHoliday ? 'text-red-400' : 'text-slate-700'}`}>
               {day}
             </span>
             <button className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-blue-600 transition-opacity">
                <Plus size={14} />
             </button>
          </div>
          
          {isCompanyHoliday && (
             <div className="text-[9px] text-red-500 font-bold bg-red-50 px-1.5 py-0.5 rounded border border-red-100 mb-1 truncate" title={holidayName}>
                {holidayName}
             </div>
          )}

          <div className="space-y-1">
            {dayLeaves.map(leave => (
              <div key={leave.id} className={`text-[10px] px-2 py-1 rounded-md border flex items-center gap-1.5 shadow-sm truncate font-medium ${getTypeColor(leave.type)}`}>
                <img src={getEmployeeAvatar(leave.employeeId)} className="w-3.5 h-3.5 rounded-full border border-white" />
                <span className="truncate">{getEmployeeName(leave.employeeId).split(' ')[0]}</span>
              </div>
            ))}
          </div>
        </div>
      );
    }
    return days;
  };

  return (
    <div className="space-y-6 animate-fade-in font-sans pb-12">
      {/* ... Header & Stats (unchanged) ... */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 tracking-tight">ระบบการลา (Leave Management)</h2>
          <p className="text-slate-500 mt-1">จัดการคำขอลาและดูปฏิทินวันหยุดของทีม</p>
        </div>
        
        <div className="flex items-center gap-3">
           <div className="bg-white p-1 rounded-xl shadow-sm border border-slate-200 flex">
              <button 
                onClick={() => setViewMode('list')}
                className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${viewMode === 'list' ? 'bg-slate-800 text-white shadow' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}
              >
                <LayoutList size={16} /> รายการ
              </button>
              <button 
                onClick={() => setViewMode('calendar')}
                className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${viewMode === 'calendar' ? 'bg-slate-800 text-white shadow' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}
              >
                <CalendarIcon size={16} /> ปฏิทิน
              </button>
           </div>

           <button 
             onClick={() => setShowModal(true)}
             className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-3 rounded-xl shadow-lg shadow-blue-200 font-bold text-sm flex items-center gap-2 transition-transform active:scale-95"
           >
             <Plus size={18} />
             <span>ขอลาหยุด</span>
           </button>
        </div>
      </div>

      {/* Stats Dashboard (unchanged) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
         <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group hover:border-amber-200 transition-colors cursor-pointer" onClick={() => { setViewMode('list'); setFilterStatus('PENDING'); }}>
           <div>
             <p className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-1">รอดำเนินการ</p>
             <div className="text-3xl font-bold text-slate-800">{stats.pending} <span className="text-sm font-normal text-slate-400">รายการ</span></div>
           </div>
           <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Clock size={24} />
           </div>
         </div>
         <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group hover:border-emerald-200 transition-colors">
           <div>
             <p className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-1">อนุมัติเดือนนี้</p>
             <div className="text-3xl font-bold text-slate-800">{stats.approvedMonth} <span className="text-sm font-normal text-slate-400">รายการ</span></div>
           </div>
           <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-500 flex items-center justify-center group-hover:scale-110 transition-transform">
              <CheckCircle size={24} />
           </div>
         </div>
         <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group hover:border-red-200 transition-colors">
           <div>
             <p className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-1">ลาป่วย (Sick Leave)</p>
             <div className="text-3xl font-bold text-slate-800">{stats.sickLeaves} <span className="text-sm font-normal text-slate-400">ครั้ง</span></div>
           </div>
           <div className="w-12 h-12 rounded-xl bg-red-50 text-red-500 flex items-center justify-center group-hover:scale-110 transition-transform">
              <AlertCircle size={24} />
           </div>
         </div>
         <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm group hover:border-blue-200 transition-colors">
           <div className="flex justify-between items-start mb-2">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wide">โควต้าพักร้อนของฉัน</p>
              <PieChart size={20} className="text-blue-500 opacity-50" />
           </div>
           <div className="flex items-end gap-2 mb-2">
              <span className="text-3xl font-bold text-slate-800">{stats.vacationQuota - stats.myVacationUsed}</span>
              <span className="text-sm font-medium text-slate-400 mb-1">/ {stats.vacationQuota} วัน</span>
           </div>
           <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
              <div className="bg-blue-500 h-full rounded-full transition-all duration-1000" style={{ width: `${(stats.myVacationUsed / stats.vacationQuota) * 100}%` }}></div>
           </div>
         </div>
      </div>

      {viewMode === 'list' ? (
        /* ============ LIST VIEW ============ */
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
               <FileText size={18} className="text-slate-400"/> ประวัติการลาทั้งหมด
            </h3>
            <div className="flex bg-slate-100 p-1 rounded-lg">
               <button onClick={() => setFilterStatus('ALL')} className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${filterStatus === 'ALL' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>ทั้งหมด ({leaves.length})</button>
               <button onClick={() => setFilterStatus('PENDING')} className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${filterStatus === 'PENDING' ? 'bg-white text-amber-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>รออนุมัติ ({leaves.filter(l => l.status === LeaveStatus.PENDING).length})</button>
               <button onClick={() => setFilterStatus('APPROVED')} className={`px-3 py-1 rounded-md text-xs font-bold transition-all ${filterStatus === 'APPROVED' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>อนุมัติแล้ว</button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-bold border-b border-slate-200">
                <tr>
                  <th className="px-6 py-4">พนักงาน</th>
                  <th className="px-6 py-4">ประเภทการลา</th>
                  <th className="px-6 py-4">ช่วงเวลา</th>
                  <th className="px-6 py-4">วันทำงานจริง (Working Days)</th>
                  <th className="px-6 py-4">เหตุผล</th>
                  <th className="px-6 py-4 text-center">สถานะ</th>
                  <th className="px-6 py-4 text-right">จัดการ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredLeaves.map((leave) => (
                  <tr key={leave.id} className="hover:bg-slate-50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <img src={getEmployeeAvatar(leave.employeeId)} className="w-9 h-9 rounded-full border border-slate-200" />
                        <div>
                           <div className="font-bold text-slate-800">{getEmployeeName(leave.employeeId)}</div>
                           <div className="text-xs text-slate-400">ID: {leave.employeeId}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4"><span className={`px-2.5 py-1 rounded-md text-xs font-bold border ${getTypeColor(leave.type)}`}>{leave.type}</span></td>
                    <td className="px-6 py-4">
                      <div className="font-medium text-slate-700 flex items-center gap-2">
                           <CalendarIcon size={14} className="text-slate-400"/>
                           {new Date(leave.startDate).toLocaleDateString('th-TH', { day: 'numeric', month: 'short' })} 
                           <span className="text-slate-300">-</span>
                           {new Date(leave.endDate).toLocaleDateString('th-TH', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                       <span className="font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                          {calculateDuration(leave.startDate, leave.endDate)} วัน
                       </span>
                    </td>
                    <td className="px-6 py-4 text-slate-500 max-w-[200px] truncate" title={leave.reason}>{leave.reason}</td>
                    <td className="px-6 py-4 text-center">{getStatusBadge(leave.status)}</td>
                    <td className="px-6 py-4 text-right">
                      {leave.status === LeaveStatus.PENDING ? (
                        <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => onUpdateStatus(leave.id, LeaveStatus.APPROVED)} className="p-1.5 bg-white border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50 text-slate-400 hover:text-emerald-600 rounded-lg shadow-sm transition-all"><CheckCircle size={18} /></button>
                          <button onClick={() => onUpdateStatus(leave.id, LeaveStatus.REJECTED)} className="p-1.5 bg-white border border-slate-200 hover:border-red-500 hover:bg-red-50 text-slate-400 hover:text-red-600 rounded-lg shadow-sm transition-all"><XCircle size={18} /></button>
                        </div>
                      ) : <button className="text-slate-300 hover:text-slate-500"><MoreHorizontal size={18}/></button>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* ============ CALENDAR VIEW ============ */
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
           <div className="p-5 border-b border-slate-200 flex justify-between items-center bg-white sticky top-0 z-10">
              <div className="flex items-center gap-4">
                 <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2"><CalendarIcon className="text-blue-600" /> {calendarDate.toLocaleDateString('th-TH', { month: 'long', year: 'numeric' })}</h3>
                 <div className="flex bg-slate-100 rounded-lg p-0.5">
                    <button onClick={handlePrevMonth} className="p-1.5 hover:bg-white rounded-md text-slate-500 shadow-sm transition-all"><ChevronLeft size={18} /></button>
                    <button onClick={handleNextMonth} className="p-1.5 hover:bg-white rounded-md text-slate-500 shadow-sm transition-all"><ChevronRight size={18} /></button>
                 </div>
              </div>
              <div className="flex gap-4 text-xs font-bold text-slate-500">
                 <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span> พักร้อน</div>
                 <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-red-500"></span> ลาป่วย</div>
                 <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-red-50/50 border border-red-200"></span> วันหยุดบริษัท</div>
              </div>
           </div>
           <div className="grid grid-cols-7 border-b border-slate-200 bg-slate-50">
             {['อา', 'จ', 'อ', 'พ', 'พฤ', 'ศ', 'ส'].map((day, i) => (<div key={i} className={`py-3 text-center text-sm font-bold uppercase tracking-wider ${i === 0 || i === 6 ? 'text-red-400' : 'text-slate-500'}`}>{day}</div>))}
           </div>
           <div className="grid grid-cols-7 bg-slate-50 gap-px border-l border-t border-slate-200">{renderCalendar()}</div>
        </div>
      )}

      {/* --- ADD LEAVE MODAL --- */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-0 overflow-hidden scale-100 animate-in zoom-in-95 duration-200 border border-slate-200">
            <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex justify-between items-center">
               <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2"><div className="bg-blue-100 text-blue-600 p-2 rounded-lg"><Plus size={18} /></div> ส่งคำขอลาหยุด</h3>
               <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600 transition-colors"><XCircle size={24} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase">พนักงาน (Employee)</label>
                <div className="relative">
                   <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                   <select required className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none text-sm font-medium transition-all appearance-none" value={newLeave.employeeId} onChange={e => setNewLeave({...newLeave, employeeId: e.target.value})}>
                     <option value="">-- เลือกพนักงาน --</option>
                     {employees.map(e => <option key={e.id} value={e.id}>{e.firstName} {e.lastName} - {e.position}</option>)}
                   </select>
                </div>
              </div>
              
              {/* Type Selection - Linked to Settings */}
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase flex justify-between">
                   <span>ประเภทการลา (Leave Type)</span>
                   {newLeave.employeeId && <span className="text-[10px] text-blue-600 bg-blue-50 px-2 rounded">โควต้าจาก Settings</span>}
                </label>
                <div className="grid grid-cols-2 gap-3 max-h-48 overflow-y-auto custom-scrollbar pr-1">
                   {companySettings?.leaveQuotas.map(q => {
                      const used = newLeave.employeeId ? getUsedDays(newLeave.employeeId, q.type) : 0;
                      const remaining = Math.max(0, q.quota - used);
                      return (
                        <button key={q.type} type="button" onClick={() => setNewLeave({...newLeave, type: q.type})} className={`p-3 rounded-xl border text-sm font-bold text-left transition-all relative overflow-hidden group ${newLeave.type === q.type ? 'bg-blue-50 border-blue-500 text-blue-700 ring-1 ring-blue-500' : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'}`}>
                           <div className="mb-1 truncate pr-2" title={q.type}>{q.type}</div>
                           <div className="flex justify-between items-end"><span className="text-[10px] font-normal opacity-70">{newLeave.employeeId ? `เหลือ ${remaining} วัน` : `โควต้า ${q.quota} วัน`}</span>{newLeave.employeeId && (<span className="text-[9px] text-slate-400 bg-white/50 px-1 rounded">ใช้ไป {used}</span>)}</div>
                           {newLeave.type === q.type && <div className="absolute top-2 right-2 w-2 h-2 bg-blue-500 rounded-full"></div>}
                        </button>
                      );
                   })}
                </div>
              </div>

              {/* Date Range with Smart Calc Preview */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                 <label className="block text-xs font-bold text-slate-500 mb-3 uppercase">ช่วงเวลาที่ลา (Date Range)</label>
                 <div className="flex items-center gap-3">
                    <input required type="date" className="flex-1 border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none" value={newLeave.startDate} onChange={e => setNewLeave({...newLeave, startDate: e.target.value})} />
                    <span className="text-slate-400">ถึง</span>
                    <input required type="date" className="flex-1 border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none" value={newLeave.endDate} onChange={e => setNewLeave({...newLeave, endDate: e.target.value})} />
                 </div>
                 {newLeave.startDate && newLeave.endDate && (
                    <div className="mt-3 flex justify-between items-center text-xs">
                       <span className="text-slate-500 flex items-center gap-1"><Info size={12}/> ไม่รวมวันหยุด (Working Days Only)</span>
                       <span className="text-blue-600 font-bold bg-blue-100 px-2 py-0.5 rounded text-sm">
                          {calculateDuration(newLeave.startDate, newLeave.endDate)} วัน
                       </span>
                    </div>
                 )}
              </div>

              <div><label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase">เหตุผล (Reason)</label><textarea required className="w-full border border-slate-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none h-24 resize-none bg-slate-50 focus:bg-white transition-colors" placeholder="โปรดระบุสาเหตุการลา..." value={newLeave.reason} onChange={e => setNewLeave({...newLeave, reason: e.target.value})}></textarea></div>
              <div><label className="block text-xs font-bold text-slate-500 mb-1.5 uppercase">แนบเอกสาร (Evidence)</label><div className="border-2 border-dashed border-slate-300 rounded-xl p-4 flex flex-col items-center justify-center text-center hover:bg-slate-50 transition-colors cursor-pointer relative"><input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={e => setNewLeave({...newLeave, attachment: e.target.files?.[0]})} />{newLeave.attachment ? (<div className="flex items-center gap-2 text-indigo-600 font-bold"><Paperclip size={18} /><span className="text-sm">{newLeave.attachment.name}</span></div>) : (<><div className="bg-slate-100 p-2 rounded-full mb-2"><Upload size={20} className="text-slate-400"/></div><p className="text-xs text-slate-500 font-medium">คลิกเพื่ออัปโหลดใบรับรองแพทย์ หรือเอกสารอื่นๆ</p></>)}</div></div>
              <div className="flex justify-end gap-3 pt-2"><button type="button" onClick={() => setShowModal(false)} className="px-5 py-2.5 text-slate-600 hover:bg-slate-100 rounded-xl font-bold text-sm transition-colors">ยกเลิก</button><button type="submit" className="px-6 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 font-bold text-sm shadow-lg shadow-blue-200 transition-all transform active:scale-95 flex items-center gap-2"><CheckCircle size={18} /> ยืนยันการลา</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
