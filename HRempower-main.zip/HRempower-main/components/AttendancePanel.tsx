
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Employee, AttendanceRecord, TimeRequest, TimeRequestType, TimeRequestStatus, CompanySettings, Role, Department } from '../types';
import { Clock, LogIn, LogOut, MapPin, Camera, RefreshCw, User, FileText, CheckCircle, AlertTriangle, Send, Map as MapIcon, Edit3, MessageSquare, Smartphone, Monitor, QrCode, Download, Navigation, AlertCircle, Info, Wifi, RefreshCcw, FileSpreadsheet, Filter, Video, VideoOff } from 'lucide-react';

// --- OPTIMIZED TIMER COMPONENT ---
// Separated to prevent re-rendering the camera/map every second
const WorkingTimer = ({ startTime }: { startTime: string }) => {
  const [duration, setDuration] = useState('00:00:00');

  useEffect(() => {
    if (!startTime) return;
    const start = new Date(startTime).getTime();
    
    const updateTimer = () => {
      const now = new Date().getTime();
      const diff = Math.max(0, now - start);
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);
      setDuration(`${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`);
    };

    updateTimer(); // Initial run
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [startTime]);

  return (
    <div className="text-3xl font-bold text-slate-800 font-mono tracking-tight animate-pulse-slow">
      {duration}
    </div>
  );
};

interface AttendancePanelProps {
  employees: Employee[];
  attendance: AttendanceRecord[];
  timeRequests: TimeRequest[];
  companySettings: CompanySettings;
  onCheckIn: (employeeId: string, location: string, photoUrl: string, note?: string) => void;
  onCheckOut: (employeeId: string, location: string, photoUrl: string, note?: string) => void;
  onRequestTime: (request: TimeRequest) => void;
  onRequestAction: (requestId: string, status: TimeRequestStatus) => void;
  currentUser: Employee;
}

export const AttendancePanel: React.FC<AttendancePanelProps> = ({ 
  employees, attendance, timeRequests, companySettings,
  onCheckIn, onCheckOut, onRequestTime, onRequestAction, currentUser 
}) => {
  // Determine if we are on a real mobile device to force the "Mobile" view
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  
  useEffect(() => {
    const handleResize = () => setIsSmallScreen(window.innerWidth < 768);
    handleResize(); // Init
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // View Mode: Web Portal vs Mobile App Simulation
  const [viewPlatform, setViewPlatform] = useState<'web' | 'mobile'>('web');

  // Force Mobile view on small screens
  useEffect(() => {
    if (isSmallScreen) {
      setViewPlatform('mobile');
    }
  }, [isSmallScreen]);

  const [selectedEmployee, setSelectedEmployee] = useState<string>(currentUser.id);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState<'log' | 'request'>('log');
  
  // Mobile UI States
  const [mobileView, setMobileView] = useState<'camera' | 'map'>('camera');
  const [note, setNote] = useState('');

  // Location & Geofencing State
  const [currentLocation, setCurrentLocation] = useState<{lat: number, lng: number} | null>(null);
  const [locationError, setLocationError] = useState<string>('');
  const [matchedLocationName, setMatchedLocationName] = useState<string | null>(null);
  const [isWithinRange, setIsWithinRange] = useState<boolean>(true); // Default to true initially to prevent flash
  
  // Camera State
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraError, setCameraError] = useState<string>('');
  const [isCameraReady, setIsCameraReady] = useState(false);

  // Report Filters
  const [filterYear, setFilterYear] = useState<number>(new Date().getFullYear());
  const [filterMonth, setFilterMonth] = useState<string>(String(new Date().getMonth() + 1)); // "1"-"12" or "All"
  const [filterDept, setFilterDept] = useState<string>('All');

  // GPS Configuration State (For fallback logic)
  const [gpsOptions, setGpsOptions] = useState({ 
    enableHighAccuracy: true, 
    timeout: 30000, 
    maximumAge: 10000 // Allow cached position up to 10s old to prevent timeout
  });
  const [retryCount, setRetryCount] = useState(0);

  // Timer State (Removed main state, using sub-component)
  const [currentTime, setCurrentTime] = useState(new Date());

  // Request Form State
  const [reqType, setReqType] = useState<TimeRequestType>(TimeRequestType.ADJUSTMENT);
  const [reqDate, setReqDate] = useState(new Date().toISOString().split('T')[0]);
  const [reqStart, setReqStart] = useState('');
  const [reqEnd, setReqEnd] = useState('');
  const [reqReason, setReqReason] = useState('');

  const isAdmin = currentUser.role === Role.SUPER_ADMIN || currentUser.role === Role.CEO || currentUser.role === Role.HR_MANAGER;

  // Update selection if currentUser changes
  useEffect(() => {
    setSelectedEmployee(currentUser.id);
  }, [currentUser]);

  // --- Real Camera Logic ---
  const startCamera = async () => {
    setCameraError('');
    setIsCameraReady(false);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'user', width: { ideal: 480 }, height: { ideal: 640 } } 
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setIsCameraReady(true);
        }
      } else {
        setCameraError('Browser does not support camera.');
      }
    } catch (err: any) {
      console.error("Camera Error:", err);
      setCameraError('ไม่สามารถเข้าถึงกล้องได้ กรุณาอนุญาตสิทธิ์ (Permission Denied)');
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setIsCameraReady(false);
    }
  };

  useEffect(() => {
    if (viewPlatform === 'mobile' && mobileView === 'camera') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [viewPlatform, mobileView]);

  // --- Geolocation Logic ---
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371e3; // Earth radius in meters
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c; // Distance in meters
  };

  const handleRetryGPS = () => {
    setLocationError('');
    setRetryCount(prev => prev + 1);
    // Reset to high accuracy on manual retry
    setGpsOptions(prev => ({ ...prev, enableHighAccuracy: true }));
  };

  useEffect(() => {
    // Clock (Only for top bar display, independent of working duration)
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);

    // Watch Position
    let watchId: number;
    if (navigator.geolocation && viewPlatform === 'mobile') {
      watchId = navigator.geolocation.watchPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setCurrentLocation({ lat: latitude, lng: longitude });
          setLocationError('');

          // Updated Logic: Check against multiple locations
          if (companySettings.isGeofencingEnabled) {
             const locations = companySettings.locations || [];
             let found = false;
             let nearestName = '';
             let minDistance = Infinity;

             if (locations.length > 0) {
                // Check all configured locations
                for (const loc of locations) {
                   const dist = calculateDistance(latitude, longitude, loc.lat, loc.lng);
                   if (dist <= loc.radius) {
                      found = true;
                      nearestName = loc.name;
                      break; // Found a valid location
                   }
                   if (dist < minDistance) {
                      minDistance = dist;
                      nearestName = `${loc.name} (${Math.round(dist)}m)`;
                   }
                }
             } else if (companySettings.gpsLatitude) {
                // Fallback to old single location if array is empty (Legacy support)
                const dist = calculateDistance(latitude, longitude, companySettings.gpsLatitude, companySettings.gpsLongitude);
                if (dist <= companySettings.gpsRadiusMeters) {
                   found = true;
                   nearestName = 'Default Office';
                }
             }

             setIsWithinRange(found);
             setMatchedLocationName(found ? nearestName : (minDistance < 2000 ? `Near: ${nearestName}` : 'Unknown Area'));
          } else {
             setIsWithinRange(true); // Always allow if geofencing disabled
             setMatchedLocationName('Anywhere');
          }
        },
        (error) => {
          console.error("Geolocation error:", error.message, "Code:", error.code);
          
          // Automatic Fallback Strategy for Timeout
          if (error.code === 3 && gpsOptions.enableHighAccuracy) { // 3 = TIMEOUT
             console.warn("High Accuracy GPS Timeout. Switching to Low Accuracy...");
             setGpsOptions(prev => ({ ...prev, enableHighAccuracy: false }));
             return; // The state change will trigger useEffect re-run
          }

          let msg = "GPS Error";
          switch(error.code) {
             case 1: // PERMISSION_DENIED
               if (error.message.toLowerCase().includes("permissions policy")) {
                 msg = "สิทธิ์ GPS ถูกระงับโดยระบบ (Policy)";
               } else {
                 msg = "กรุณาอนุญาตสิทธิ์เข้าถึง GPS"; 
               }
               break;
             case 2: // POSITION_UNAVAILABLE
               msg = "ไม่สามารถระบุตำแหน่งได้ (Position Unavailable)"; 
               break;
             case 3: // TIMEOUT
               msg = "หมดเวลาเชื่อมต่อ GPS (Timeout)"; 
               break;
             default: 
               msg = `GPS Error: ${error.message}`;
          }
          setLocationError(msg);
          // If strict geofencing is on, deny access on error
          if (companySettings.isGeofencingEnabled) {
             setIsWithinRange(false);
          }
        },
        gpsOptions
      );
    }

    return () => {
      clearInterval(timer);
      if (watchId) navigator.geolocation.clearWatch(watchId);
    };
  }, [companySettings, viewPlatform, gpsOptions, retryCount]);


  // Calculate Check-In Status
  const todayStr = new Date().toISOString().split('T')[0];
  // Check strict "Currently Checked In" status - find the latest record for today
  const personalAttendance = attendance.filter(a => a.employeeId === selectedEmployee);
  const todayRecords = personalAttendance.filter(r => r.date === todayStr);
  const latestTodayRecord = todayRecords.sort((a,b) => new Date(b.checkIn || '').getTime() - new Date(a.checkIn || '').getTime())[0];
  
  const isCheckedIn = !!latestTodayRecord && latestTodayRecord.checkOut === null;

  // --- FILTERED DATA FOR TABLE & EXPORT ---
  const reportData = useMemo(() => {
    let data = attendance;

    if (!isAdmin) {
      data = data.filter(a => a.employeeId === currentUser.id);
    }

    data = data.filter(a => new Date(a.date).getFullYear() === filterYear);

    if (filterMonth !== 'All') {
      data = data.filter(a => (new Date(a.date).getMonth() + 1) === parseInt(filterMonth));
    }

    if (isAdmin && filterDept !== 'All') {
      data = data.filter(a => {
        const emp = employees.find(e => e.id === a.employeeId);
        return emp?.department === filterDept;
      });
    }

    return data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [attendance, isAdmin, currentUser.id, filterYear, filterMonth, filterDept, employees]);
  
  const getEmployee = (id: string) => employees.find(e => e.id === id);
  const selectedEmpDetails = getEmployee(selectedEmployee);

  const handleAction = async (type: 'in' | 'out') => {
    if (!selectedEmployee) return;
    
    // --- Rule 1: Geofencing Check ---
    if (companySettings.isGeofencingEnabled && !isWithinRange) {
       alert("คุณอยู่นอกพื้นที่ที่กำหนด ไม่สามารถลงเวลาได้");
       return;
    }
    if (locationError) {
       alert(`ไม่สามารถลงเวลาได้: ${locationError}`);
       return;
    }

    // --- Rule 2: Anti-Duplicate Punch Check ---
    if (isProcessing) {
        return; // Prevent button spamming
    }
    
    // Double check state to prevent race conditions (Simulated)
    const freshAttendance = attendance.filter(a => a.employeeId === selectedEmployee && a.date === todayStr);
    const freshLatest = freshAttendance.sort((a,b) => new Date(b.checkIn || '').getTime() - new Date(a.checkIn || '').getTime())[0];
    const freshIsCheckedIn = !!freshLatest && freshLatest.checkOut === null;

    if (freshIsCheckedIn !== isCheckedIn) {
        alert("สถานะของคุณเปลี่ยนไป กรุณารีเฟรชหน้าจอ");
        return;
    }

    // Validation
    if (type === 'in' && isCheckedIn) {
        alert("คุณได้ลงเวลาเข้างานไปแล้ว");
        return;
    }
    if (type === 'out' && !isCheckedIn) {
        alert("คุณยังไม่ได้ลงเวลาเข้างาน");
        return;
    }

    setIsProcessing(true);

    // --- Rule 3: Mandatory Camera Check & Capture ---
    let capturedPhotoUrl = selectedEmpDetails?.avatarUrl || '';
    
    if (videoRef.current && canvasRef.current) {
        // Capture frame
        const video = videoRef.current;
        const canvas = canvasRef.current;
        const context = canvas.getContext('2d');
        
        if (context) {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
            // Get Data URL
            capturedPhotoUrl = canvas.toDataURL('image/jpeg', 0.8);
        }
    } else {
        // Camera not ready?
        alert("ไม่สามารถถ่ายภาพได้ กรุณาตรวจสอบกล้อง (Camera is required for attendance)");
        setIsProcessing(false);
        return;
    }
    
    // Simulate API Processing Delay
    setTimeout(() => {
      const locationStr = matchedLocationName && isWithinRange 
         ? matchedLocationName 
         : currentLocation 
            ? `${currentLocation.lat.toFixed(6)}, ${currentLocation.lng.toFixed(6)}` 
            : 'Unknown Location';

      if (type === 'out') {
        onCheckOut(selectedEmployee, locationStr, capturedPhotoUrl, note);
      } else {
        onCheckIn(selectedEmployee, locationStr, capturedPhotoUrl, note);
      }
      setIsProcessing(false);
      setNote(''); 
    }, 1500);
  };

  const handleRequestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(selectedEmployee && reqDate && reqStart && reqEnd) {
      const newRequest: TimeRequest = {
        id: `TR-${Date.now()}`,
        orgId: currentUser.orgId,
        employeeId: selectedEmployee,
        type: reqType,
        date: reqDate,
        startTime: reqStart,
        endTime: reqEnd,
        reason: reqReason,
        status: TimeRequestStatus.PENDING
      };
      onRequestTime(newRequest);
      setReqReason('');
      setReqStart('');
      setReqEnd('');
      alert('ส่งคำขอเรียบร้อยแล้ว');
    }
  };

  const handleExportCSV = () => {
    const headers = ['Employee ID,Name,Department,Date,Check In,Check Out,Status,Location,Note'];
    const rows = reportData.map(record => {
        const emp = employees.find(e => e.id === record.employeeId);
        const name = emp ? `${emp.firstName} ${emp.lastName}` : 'Unknown';
        const dept = emp ? emp.department : '-';
        
        const checkInTime = record.checkIn ? new Date(record.checkIn).toLocaleTimeString('th-TH', { hour12: false }) : '-';
        const checkOutTime = record.checkOut ? new Date(record.checkOut).toLocaleTimeString('th-TH', { hour12: false }) : '-';
        
        const safeLocation = (record.checkInLocation || '').replace(/"/g, '""');
        const safeNote = (record.checkInNote || '').replace(/"/g, '""');

        return `${record.employeeId},"${name}","${dept}",${record.date},${checkInTime},${checkOutTime},${record.status},"${safeLocation}","${safeNote}"`;
    });

    const csvContent = "\uFEFF" + [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `attendance_report_${filterYear}_${filterMonth !== 'All' ? filterMonth : 'All'}.csv`;
    link.click();
  };

  // Render Log Table Component
  const renderLogTable = () => (
    <div className="space-y-4">
      {/* Filters Toolbar */}
      <div className="flex flex-col md:flex-row gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
         <div className="flex items-center gap-2 flex-1">
            <Filter size={16} className="text-slate-400" />
            <span className="text-xs font-bold text-slate-500 uppercase">Filters:</span>
            
            {/* Year Selector */}
            <select 
               value={filterYear}
               onChange={(e) => setFilterYear(Number(e.target.value))}
               className="bg-white border border-slate-200 text-sm rounded-lg px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
            >
               {Array.from({length: 5}, (_, i) => new Date().getFullYear() - i).map(year => (
                  <option key={year} value={year}>{year}</option>
               ))}
            </select>

            {/* Month Selector */}
            <select 
               value={filterMonth}
               onChange={(e) => setFilterMonth(e.target.value)}
               className="bg-white border border-slate-200 text-sm rounded-lg px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
            >
               <option value="All">All Months</option>
               {Array.from({length: 12}, (_, i) => i + 1).map(month => (
                  <option key={month} value={month}>
                     {new Date(0, month - 1).toLocaleString('th-TH', { month: 'long' })}
                  </option>
               ))}
            </select>

            {/* Dept Selector (Admin Only) */}
            {isAdmin && (
               <select 
                  value={filterDept}
                  onChange={(e) => setFilterDept(e.target.value)}
                  className="bg-white border border-slate-200 text-sm rounded-lg px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer max-w-[150px]"
               >
                  <option value="All">All Departments (ทั้งองค์กร)</option>
                  {Object.values(Department).map(dept => (
                     <option key={dept} value={dept}>{dept}</option>
                  ))}
               </select>
            )}
         </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-4 mb-2">
         <div className="bg-green-50 border border-green-100 p-3 rounded-xl">
            <p className="text-xs text-green-600 font-bold uppercase">มาทันเวลา</p>
            <p className="text-xl font-bold text-green-700">{reportData.filter(a => a.status === 'Present').length} <span className="text-xs">รายการ</span></p>
         </div>
         <div className="bg-amber-50 border border-amber-100 p-3 rounded-xl">
            <p className="text-xs text-amber-600 font-bold uppercase">สาย</p>
            <p className="text-xl font-bold text-amber-700">{reportData.filter(a => a.status === 'Late').length} <span className="text-xs">ครั้ง</span></p>
         </div>
         <div className="bg-blue-50 border border-blue-100 p-3 rounded-xl">
            <p className="text-xs text-blue-600 font-bold uppercase">บันทึกทั้งหมด</p>
            <p className="text-xl font-bold text-blue-700">{reportData.length} <span className="text-xs">รายการ</span></p>
         </div>
      </div>

      <div className="max-h-[500px] overflow-y-auto custom-scrollbar border rounded-xl border-slate-200">
        <table className="w-full text-left border-collapse">
          <thead className="bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider sticky top-0 z-10 shadow-sm">
            <tr>
              <th className="px-4 py-3">วันที่</th>
              {isAdmin && <th className="px-4 py-3">พนักงาน</th>}
              <th className="px-4 py-3">เวลาเข้า</th>
              <th className="px-4 py-3">เวลาออก</th>
              <th className="px-4 py-3">สถานะ</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 bg-white">
            {reportData.map((record) => {
              const emp = employees.find(e => e.id === record.employeeId);
              return (
                <tr key={record.id} className="hover:bg-blue-50/30 transition-colors group">
                  <td className="px-4 py-4 text-slate-700 font-medium text-sm">
                    {new Date(record.date).toLocaleDateString('th-TH', { day: 'numeric', month: 'short' })}
                  </td>
                  {isAdmin && (
                    <td className="px-4 py-4">
                       <div className="flex items-center gap-2">
                          <img src={record.checkInPhoto || emp?.avatarUrl} className="w-8 h-8 rounded-full border border-slate-100 object-cover" alt="Proof" />
                          <div>
                             <div className="text-xs font-bold text-slate-700">{emp?.firstName}</div>
                             <div className="text-[9px] text-slate-400">{emp?.department}</div>
                          </div>
                       </div>
                    </td>
                  )}
                  <td className="px-4 py-4">
                    <div className="font-mono text-sm text-green-700 font-bold">
                      {record.checkIn ? new Date(record.checkIn).toLocaleTimeString('th-TH', {hour: '2-digit', minute:'2-digit'}) : '-'}
                    </div>
                    {record.checkInLocation && <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1 max-w-[100px] truncate" title={record.checkInLocation}><MapPin size={10}/> {record.checkInLocation}</div>}
                  </td>
                  <td className="px-4 py-4">
                     <div className="font-mono text-sm text-amber-700 font-bold">
                       {record.checkOut ? new Date(record.checkOut).toLocaleTimeString('th-TH', {hour: '2-digit', minute:'2-digit'}) : '-'}
                     </div>
                  </td>
                  <td className="px-4 py-4">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide
                      ${record.status === 'Present' ? 'bg-green-100 text-green-700 border border-green-200' : 
                        record.status === 'Late' ? 'bg-red-100 text-red-700 border border-red-200' : 'bg-slate-100 text-slate-700 border border-slate-200'}`}>
                      {record.status}
                    </span>
                  </td>
                </tr>
              );
            })}
            {reportData.length === 0 && (
              <tr>
                <td colSpan={isAdmin ? 5 : 4} className="px-6 py-12 text-center text-slate-400">
                  ไม่พบข้อมูลตามเงื่อนไขที่เลือก
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Hidden Canvas for Capture */}
      <canvas ref={canvasRef} className="hidden"></canvas>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">ระบบลงเวลา (Time Attendance)</h2>
          <p className="text-slate-500">บันทึกเวลาเข้า-ออกงาน ด้วยการสแกนใบหน้าและพิกัด GPS</p>
        </div>
        
        {/* Toggle View Mode */}
        {!isSmallScreen && (
          <div className="flex bg-white border border-slate-200 rounded-lg p-1 shadow-sm">
             <button 
               onClick={() => setViewPlatform('web')}
               className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-2 transition-all ${viewPlatform === 'web' ? 'bg-slate-800 text-white shadow' : 'text-slate-500 hover:bg-slate-100'}`}
             >
               <Monitor size={14} /> Web Portal
             </button>
             <button 
               onClick={() => setViewPlatform('mobile')}
               className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-2 transition-all ${viewPlatform === 'mobile' ? 'bg-blue-600 text-white shadow' : 'text-slate-500 hover:bg-slate-100'}`}
             >
               <Smartphone size={14} /> Mobile App
             </button>
          </div>
        )}
      </div>

      {viewPlatform === 'web' ? (
        /* ============ WEB PORTAL VIEW (READ ONLY) ============ */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
           
           {/* Left: Mobile Restriction Banner */}
           <div className="lg:col-span-4 space-y-4">
              <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-6 text-white shadow-xl flex flex-col items-center text-center">
                 <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mb-4 backdrop-blur-sm border border-white/10">
                    <Smartphone size={32} className="text-blue-400" />
                 </div>
                 <h3 className="text-lg font-bold mb-2">ลงเวลาผ่านมือถือเท่านั้น</h3>
                 <p className="text-sm text-slate-300 mb-6 leading-relaxed">
                    เพื่อความแม่นยำของพิกัด GPS และการยืนยันตัวตนด้วยใบหน้า (Photo Check-in) <br/>
                    กรุณาใช้งานผ่านแอปพลิเคชัน EmpowerHR บนมือถือ
                 </p>
                 
                 <div className="bg-white p-3 rounded-xl mb-4">
                    <QrCode size={120} className="text-slate-900" />
                 </div>
                 <p className="text-xs text-slate-400 uppercase tracking-wider font-bold mb-4">Scan to Download</p>
              </div>
           </div>

           {/* Right: Full logs */}
           <div className="lg:col-span-8 bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
              <div className="flex justify-between items-center mb-6">
                 <h3 className="font-bold text-slate-800 text-lg flex items-center gap-2">
                   <Navigation size={20} className="text-blue-600" /> ประวัติการลงเวลา
                 </h3>
                 <div className="flex gap-2 items-center">
                    <button 
                        onClick={handleExportCSV}
                        className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm transition-colors"
                    >
                        <FileSpreadsheet size={16} /> Export Excel
                    </button>
                 </div>
              </div>
              
              {activeTab === 'log' ? renderLogTable() : (
                 <div className="max-w-xl mx-auto py-4">
                    <div className="flex items-center gap-2 mb-4 text-slate-500 cursor-pointer hover:text-blue-600" onClick={() => setActiveTab('log')}>
                       <Edit3 size={16}/> <span>กลับไปหน้าประวัติ</span>
                    </div>
                    <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 text-center">
                        <p>กรุณายื่นคำขอผ่านมือถือเพื่อความถูกต้องของข้อมูล</p>
                    </div>
                 </div>
              )}
           </div>

        </div>
      ) : (
        /* ============ MOBILE APP MODE (Native-like UI) ============ */
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
          
          {/* === LEFT: MOBILE SIMULATION / ACTUAL MOBILE VIEW === */}
          <div className="xl:col-span-5 flex flex-col items-center">
            <div className={`w-full max-w-[400px] bg-slate-900 rounded-[3rem] p-4 shadow-2xl border-4 border-slate-800 relative overflow-hidden ring-4 ring-slate-100 ${isSmallScreen ? 'border-0 p-0 rounded-none ring-0 shadow-none bg-transparent' : ''}`}>
               {/* Phone Notch (Hidden on real mobile) */}
               {!isSmallScreen && (
                 <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-32 h-7 bg-black rounded-full z-20 flex items-center justify-center">
                    <div className="w-20 h-4 bg-slate-900/50 rounded-full"></div>
                 </div>
               )}
               
               {/* Screen Content */}
               <div className={`bg-slate-50 rounded-[2.5rem] h-[750px] overflow-hidden flex flex-col relative ${isSmallScreen ? 'h-auto min-h-[80vh] rounded-none bg-transparent' : ''}`}>
                  
                  {/* Status Bar (Hidden on real mobile) */}
                  {!isSmallScreen && (
                    <div className="h-14 flex justify-between items-center px-8 pt-4 pb-2 text-slate-900 text-xs font-medium z-10 bg-white/80 backdrop-blur-md sticky top-0">
                       <span>{currentTime.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })}</span>
                       <div className="flex gap-1.5 items-center">
                          <Wifi size={14} className="text-slate-800"/>
                          <span className="w-5 h-3 border border-slate-400 rounded-sm relative ml-1">
                            <span className="absolute inset-0.5 bg-slate-800 w-[70%]"></span>
                          </span>
                       </div>
                    </div>
                  )}

                  {/* App Content */}
                  <div className="flex-1 flex flex-col p-6 bg-gradient-to-br from-slate-50 to-slate-100 overflow-y-auto custom-scrollbar">
                     
                     {/* User Greeting */}
                     {!isSmallScreen && (
                       <div className="flex items-center gap-3 mb-6">
                          <img src={currentUser.avatarUrl} className="w-12 h-12 rounded-full border-2 border-white shadow-sm" />
                          <div>
                             <p className="text-xs text-slate-500">Welcome back,</p>
                             <h3 className="font-bold text-slate-800 text-lg leading-tight">{currentUser.firstName}</h3>
                          </div>
                       </div>
                     )}

                     {/* Main Viewfinder/Map Area */}
                     <div className="relative w-full aspect-[3/3.8] bg-slate-900 rounded-3xl overflow-hidden shadow-lg border border-slate-200 mb-4 group">
                        
                        {/* GPS Info Overlay */}
                        <div className="absolute top-4 left-4 right-4 z-20 flex flex-col gap-2">
                           {/* Status Badge */}
                           <div className={`backdrop-blur px-3 py-2 rounded-xl border shadow-sm flex items-center justify-between ${isWithinRange && !locationError ? 'bg-green-500/90 text-white border-green-400' : 'bg-red-500/90 text-white border-red-400'}`}>
                               <div className="flex items-center gap-2">
                                  <Navigation size={14} className={isWithinRange && !locationError ? '' : 'animate-pulse'} /> 
                                  <span className="text-xs font-bold">{locationError ? 'GPS Error' : isWithinRange ? `In Area: ${matchedLocationName || 'Yes'}` : 'Out of Range'}</span>
                               </div>
                           </div>
                        </div>

                        {/* Visuals */}
                        {mobileView === 'camera' ? (
                          <>
                             {/* Camera Live Feed */}
                             <div className="w-full h-full bg-black flex items-center justify-center relative">
                                <video 
                                  ref={videoRef}
                                  autoPlay 
                                  playsInline 
                                  muted 
                                  className="w-full h-full object-cover transform scale-x-[-1]" 
                                ></video>
                                
                                {!isCameraReady && !cameraError && (
                                   <div className="absolute inset-0 flex items-center justify-center bg-slate-900">
                                      <RefreshCw className="animate-spin text-white opacity-50" size={32} />
                                   </div>
                                )}

                                {cameraError && (
                                   <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900 p-6 text-center">
                                      <VideoOff size={48} className="text-red-500 mb-4" />
                                      <p className="text-white text-sm font-bold">{cameraError}</p>
                                      <button onClick={startCamera} className="mt-4 px-4 py-2 bg-white/10 text-white text-xs rounded-full border border-white/20">Try Again</button>
                                   </div>
                                )}
                             </div>

                             {/* Face ID Frame Overlay */}
                             <div className="absolute inset-0 z-10 pointer-events-none flex items-center justify-center">
                                {/* Corners */}
                                <div className={`w-64 h-64 border-2 rounded-[2rem] relative transition-colors duration-500 ${isWithinRange && !locationError ? 'border-green-400/60' : 'border-red-400/60'}`}>
                                   <div className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-white rounded-tl-xl -mt-1 -ml-1"></div>
                                   <div className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-white rounded-tr-xl -mt-1 -mr-1"></div>
                                   <div className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-white rounded-bl-xl -mb-1 -ml-1"></div>
                                   <div className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-white rounded-br-xl -mb-1 -mr-1"></div>
                                   
                                   {/* Scanning Line */}
                                   {!isCheckedIn && !isProcessing && isWithinRange && !locationError && isCameraReady && (
                                      <div className="absolute top-0 left-0 w-full h-1 bg-green-400/80 shadow-[0_0_15px_rgba(74,222,128,0.8)] animate-[scan_2s_ease-in-out_infinite]"></div>
                                   )}
                                </div>
                                
                                {isProcessing && (
                                   <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm">
                                      <div className="border-t-4 border-green-400 rounded-full w-12 h-12 animate-spin"></div>
                                   </div>
                                )}
                             </div>
                          </>
                        ) : (
                          /* Map View Placeholder */
                          <div className="w-full h-full bg-slate-100 relative flex items-center justify-center text-slate-400">
                             <MapIcon size={48} />
                          </div>
                        )}
                     </div>

                     {/* Note Input */}
                     <div className="mb-4">
                        <div className="relative">
                           <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                              <Edit3 size={14} />
                           </div>
                           <input 
                             type="text" 
                             placeholder="หมายเหตุ (เช่น เข้าไซตงานลูกค้า)..." 
                             className="w-full pl-9 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm disabled:bg-slate-100 disabled:text-slate-400"
                             value={note}
                             onChange={(e) => setNote(e.target.value)}
                             disabled={(!isWithinRange && companySettings.isGeofencingEnabled) || !!locationError}
                           />
                        </div>
                     </div>

                     {/* Working Duration Display */}
                     {isCheckedIn && latestTodayRecord?.checkIn && (
                        <div className="mb-4 text-center">
                           <p className="text-xs text-slate-400 mb-1 uppercase tracking-wider font-bold">Working Duration</p>
                           {/* Use the new optimized component here */}
                           <WorkingTimer startTime={latestTodayRecord.checkIn} />
                        </div>
                     )}

                     {/* Action Buttons Grid */}
                     <div className="mt-auto grid grid-cols-2 gap-4">
                        <button
                          disabled={isCheckedIn || isProcessing || (companySettings.isGeofencingEnabled && !isWithinRange) || !!locationError || !isCameraReady}
                          onClick={() => handleAction('in')}
                          className={`w-full py-4 rounded-2xl flex flex-col items-center justify-center gap-2 font-bold shadow-lg transition-all transform active:scale-95 relative overflow-hidden ${
                            isCheckedIn || isProcessing || (companySettings.isGeofencingEnabled && !isWithinRange) || !!locationError || !isCameraReady
                              ? 'bg-slate-100 text-slate-300 shadow-none cursor-not-allowed border border-slate-200'
                              : 'bg-gradient-to-br from-emerald-500 to-green-600 text-white shadow-emerald-200 hover:shadow-xl'
                          }`}
                        >
                           {isProcessing && !isCheckedIn ? <RefreshCw size={24} className="animate-spin" /> : <LogIn size={24} />}
                           <span className="text-sm">เข้างาน (IN)</span>
                        </button>

                        <button
                          disabled={!isCheckedIn || isProcessing || (companySettings.isGeofencingEnabled && !isWithinRange) || !!locationError || !isCameraReady}
                          onClick={() => handleAction('out')}
                          className={`w-full py-4 rounded-2xl flex flex-col items-center justify-center gap-2 font-bold shadow-lg transition-all transform active:scale-95 relative overflow-hidden ${
                            !isCheckedIn || isProcessing || (companySettings.isGeofencingEnabled && !isWithinRange) || !!locationError || !isCameraReady
                              ? 'bg-slate-100 text-slate-300 shadow-none cursor-not-allowed border border-slate-200'
                              : 'bg-gradient-to-br from-orange-500 to-red-600 text-white shadow-orange-200 hover:shadow-xl'
                          }`}
                        >
                           {isProcessing && isCheckedIn ? <RefreshCw size={24} className="animate-spin" /> : <LogOut size={24} />}
                           <span className="text-sm">ออกงาน (OUT)</span>
                        </button>
                     </div>
                        
                     {/* Status Text */}
                     <div className="mt-3 flex justify-center items-center gap-2 h-6">
                        {locationError ? (
                           <div className="flex items-center gap-2">
                             <span className="text-[10px] text-red-500 font-bold">{locationError}</span>
                             <button onClick={handleRetryGPS} className="text-[10px] text-blue-600 font-bold underline flex items-center gap-1">
                               <RefreshCcw size={10} /> Retry
                             </button>
                           </div>
                        ) : isWithinRange ? (
                           <>
                              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                              <span className="text-[10px] text-green-600 font-bold">GPS: Good ({matchedLocationName})</span>
                              <span className="text-slate-300 mx-1">|</span>
                              <span className={`w-2 h-2 rounded-full ${isCameraReady ? 'bg-green-500' : 'bg-red-500'} animate-pulse`}></span>
                              <span className={`text-[10px] font-bold ${isCameraReady ? 'text-green-600' : 'text-red-500'}`}>Camera: {isCameraReady ? 'Ready' : 'Waiting'}</span>
                           </>
                        ) : (
                           <span className="text-[10px] text-red-400 font-bold">Please move closer to office</span>
                        )}
                     </div>
                  </div>

                  {/* Home Indicator */}
                  {!isSmallScreen && (
                    <div className="h-5 bg-white flex justify-center items-center">
                       <div className="w-32 h-1 bg-slate-300 rounded-full"></div>
                    </div>
                  )}
               </div>
            </div>
          </div>

          {/* === RIGHT: LOGS & REQUESTS (7 cols) === */}
          <div className="xl:col-span-7 space-y-6">
            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden h-full min-h-[600px] flex flex-col">
              {/* Tabs */}
              <div className="flex border-b border-slate-200">
                <button 
                  onClick={() => setActiveTab('log')}
                  className={`flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 transition-colors relative ${activeTab === 'log' ? 'text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
                >
                  <Navigation size={18} /> ประวัติการลงเวลา
                  {activeTab === 'log' && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-blue-600"></div>}
                </button>
                <button 
                  onClick={() => setActiveTab('request')}
                  className={`flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 transition-colors relative ${activeTab === 'request' ? 'text-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
                >
                  <FileText size={18} /> ขอแก้เวลา / OT
                  {activeTab === 'request' && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-blue-600"></div>}
                </button>
              </div>

              {/* Content Area */}
              <div className="flex-1 overflow-y-auto p-6 bg-slate-50/30 custom-scrollbar">
                
                {activeTab === 'log' && renderLogTable()}

                {activeTab === 'request' && (
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8 h-full">
                      {/* Request Form */}
                      <div className="space-y-4">
                         <h3 className="font-bold text-slate-800 flex items-center gap-2">
                           <Send size={18} className="text-blue-600" /> ส่งคำขอใหม่
                         </h3>
                         <form onSubmit={handleRequestSubmit} className="space-y-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                            <div>
                               <label className="block text-xs font-bold text-slate-500 mb-1">ประเภทคำขอ</label>
                               <div className="grid grid-cols-2 gap-2">
                                  <button 
                                    type="button" 
                                    onClick={() => setReqType(TimeRequestType.ADJUSTMENT)}
                                    className={`py-2 px-3 rounded-lg text-xs font-bold border transition-all ${reqType === TimeRequestType.ADJUSTMENT ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-white border-slate-200 text-slate-500'}`}
                                  >
                                     แก้ไขเวลา (ลืมสแกน)
                                  </button>
                                  <button 
                                    type="button" 
                                    onClick={() => setReqType(TimeRequestType.OT)}
                                    className={`py-2 px-3 rounded-lg text-xs font-bold border transition-all ${reqType === TimeRequestType.OT ? 'bg-orange-50 border-orange-200 text-orange-700' : 'bg-white border-slate-200 text-slate-500'}`}
                                  >
                                     ขอทำ OT (ล่วงเวลา)
                                  </button>
                               </div>
                            </div>
                            
                            <div>
                               <label className="block text-xs font-bold text-slate-500 mb-1">วันที่</label>
                               <input type="date" required className="w-full border border-slate-200 rounded-xl p-2.5 text-sm focus:ring-2 focus:ring-blue-500" value={reqDate} onChange={e => setReqDate(e.target.value)} />
                            </div>

                            <div className="grid grid-cols-2 gap-3">
                               <div>
                                  <label className="block text-xs font-bold text-slate-500 mb-1">เริ่ม</label>
                                  <input type="time" required className="w-full border border-slate-200 rounded-xl p-2.5 text-sm" value={reqStart} onChange={e => setReqStart(e.target.value)} />
                               </div>
                               <div>
                                  <label className="block text-xs font-bold text-slate-500 mb-1">สิ้นสุด</label>
                                  <input type="time" required className="w-full border border-slate-200 rounded-xl p-2.5 text-sm" value={reqEnd} onChange={e => setReqEnd(e.target.value)} />
                               </div>
                            </div>

                            <div>
                               <label className="block text-xs font-bold text-slate-500 mb-1">เหตุผล</label>
                               <textarea 
                                 required 
                                 rows={3}
                                 className="w-full border border-slate-200 rounded-xl p-3 text-sm resize-none focus:ring-2 focus:ring-blue-500" 
                                 placeholder="ระบุสาเหตุ..."
                                 value={reqReason}
                                 onChange={e => setReqReason(e.target.value)}
                               ></textarea>
                            </div>

                            <button type="submit" className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-lg shadow-blue-200 transition-all active:scale-95">
                              ยืนยันส่งคำขอ
                            </button>
                         </form>
                      </div>
                   </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
