
// ... existing imports ...
import { Department, Employee, EmployeeStatus, AttendanceRecord, LeaveRequest, LeaveType, LeaveStatus, PayrollRecord, Post, Shift, ShiftAssignment, TimeRequest, TimeRequestType, TimeRequestStatus, ExpenseRequest, ExpenseType, ExpenseStatus, Task, TaskStatus, TeamMessage, Role, CompanySettings, Gender, EmploymentType, Nationality, Religion, MaritalStatus, Goal, PerformanceReview, GoalType, GoalStatus, GoalApprovalStatus, GoalScope, Channel, KnowledgeItem, Organization, EmployeeDocument, Asset, WorkHistory, PayrollWorkflowStatus, RolePermissions } from './types';

// Default Permissions Strategy (Granular)
export const DEFAULT_ROLE_PERMISSIONS: RolePermissions[] = [
  { 
    role: Role.CEO, 
    permissions: [
      'employee_view', 'employee_view_full', 'employee_create', 'employee_edit', 'employee_delete',
      'attendance_view', 'attendance_manage', 'shift_manage',
      'leave_view', 'leave_approve',
      'payroll_view', 'payroll_calc', 'payroll_approve', 'payroll_export',
      'goal_view', 'goal_manage', 'review_manage',
      'settings_manage', 'data_view_all', 'announcement_create'
    ] 
  },
  { 
    role: Role.HR_MANAGER, 
    permissions: [
      'employee_view', 'employee_view_full', 'employee_create', 'employee_edit', 'employee_delete',
      'attendance_view', 'attendance_manage', 'shift_manage',
      'leave_view', 'leave_approve',
      'payroll_view', 'payroll_calc', 'payroll_approve', 'payroll_export',
      'goal_view', 'goal_manage', 'review_manage',
      'settings_manage', 'data_view_all', 'announcement_create'
    ] 
  },
  { 
    role: Role.HR_STAFF, 
    permissions: [
      'employee_view', 'employee_create', 'employee_edit',
      'attendance_view', 'attendance_manage', 'shift_manage',
      'leave_view', 'leave_approve',
      // Removed 'payroll_view' from default to ensure strict access per request
      'data_view_all'
    ] 
  },
  { 
    role: Role.MANAGER, 
    permissions: [
      'employee_view', 
      'attendance_view', 'attendance_manage',
      'leave_view', 'leave_approve',
      'goal_view', 'goal_manage', 'review_manage',
      'announcement_create'
    ] 
  },
  { 
    role: Role.STAFF, 
    permissions: [] // Staff usually has no special permissions beyond self-service
  },
  // Super Admin is handled via code logic (always true)
];

// ... (Keep existing code) ...
const DEFAULT_SETTINGS: CompanySettings = {
  name: 'บริษัท เอ็มพาวเวอร์ เอชอาร์ จำกัด',
  nameEn: 'EmpowerHR Co., Ltd.',
  address: '123 อาคารสาทรซิตี้ทาวเวอร์ ชั้น 10 ถนนสาทรใต้ แขวงทุ่งมหาเมฆ เขตสาทร กรุงเทพมหานคร 10120',
  phone: '02-123-4567',
  email: 'hr@empowerhr.com',
  website: 'www.empowerhr.com',
  taxId: '0105551234567',
  socialSecurityId: '1000000001',
  branchCode: '00000',
  logoUrl: 'https://ui-avatars.com/api/?name=Empower+HR&background=5d4886&color=fff&size=128',
  
  workDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
  workStartTime: '09:00',
  workEndTime: '18:00',
  lateThresholdMinutes: 15,
  isGeofencingEnabled: true,
  gpsLatitude: 13.7563,
  gpsLongitude: 100.5018,
  gpsRadiusMeters: 500,
  locations: [
     { id: 'LOC_HQ', name: 'สำนักงานใหญ่ (HQ)', lat: 13.7563, lng: 100.5018, radius: 500 }
  ],
  publicHolidays: [
    { id: 'H1', date: '2023-10-13', name: 'วันคล้ายวันสวรรคต ร.9' },
    { id: 'H2', date: '2023-10-23', name: 'วันปิยมหาราช' },
    { id: 'H3', date: '2023-12-05', name: 'วันพ่อแห่งชาติ' },
    { id: 'H4', date: '2023-12-10', name: 'วันรัฐธรรมนูญ' },
    { id: 'H5', date: '2023-12-31', name: 'วันสิ้นปี' },
    { id: 'H6', date: '2024-01-01', name: 'วันขึ้นปีใหม่' },
    // 2025 Holidays for testing payroll
    { id: 'H25-1', date: '2025-12-05', name: 'วันพ่อแห่งชาติ' },
    { id: 'H25-2', date: '2025-12-10', name: 'วันรัฐธรรมนูญ' },
    { id: 'H25-3', date: '2025-12-31', name: 'วันสิ้นปี' },
  ],
  leaveQuotas: [
    { type: 'ลาป่วย (Sick Leave)', quota: 30 },
    { type: 'ลาพักร้อน (Vacation)', quota: 6 },
    { type: 'ลากิจ (Personal Leave)', quota: 3 },
    { type: 'ลาคลอด (Maternity)', quota: 98 },
    { type: 'ลาทำหมัน (Sterilization)', quota: 1 },
    { type: 'ลาเกณฑ์ทหาร (Military Service)', quota: 60 },
    { type: 'ลาฝึกอบรม (Training)', quota: 30 }
  ],
  payrollRules: {
    socialSecurityRate: 0.05,
    maxSocialSecurityBase: 15000,
    latePenaltyPerTime: 100,
    otRateMultiplier: 1.5
  },
  employmentTypes: [
    {
      id: 'ET1',
      name: 'รายเดือน (Monthly)',
      nameEn: 'Monthly',
      paymentType: 'Monthly',
      salaryBasis: 'Standard30',
      otBasis: 'Salary',
      conditions: {
        ot: { enabled: true, rates: { otNormal: { mode: 'Multiplier', rate: 1.5 }, workDayOff: { mode: 'Multiplier', rate: 1.0 }, otDayOff: { mode: 'Multiplier', rate: 3.0 }, workPublicHoliday: { mode: 'Multiplier', rate: 1.0 }, otPublicHoliday: { mode: 'Multiplier', rate: 3.0 } } },
        late: { action: 'DeductSalary', calculationMode: 'ProRated', enabled: true },
        absent: { action: 'DeductSalary', calculationMode: 'ProRated', enabled: true },
        missingPunch: { action: 'None', calculationMode: 'Fixed', enabled: true },
        earlyLeave: { action: 'None', calculationMode: 'ProRated', enabled: false }
      },
      calculateTax: true,
      calculateSSO: true
    }
  ],
  notificationSettings: {
    probation: {
      day30: { enabled: true, notifyHR: true, notifyManager: true, notifyEmployee: true },
      day60: { enabled: true, notifyHR: true, notifyManager: true, notifyEmployee: true },
      day90: { enabled: true, notifyHR: true, notifyManager: true, notifyEmployee: true },
      day119: { enabled: true, notifyHR: true, notifyManager: true, notifyEmployee: true },
    },
    general: {
      leaveRequest: { enabled: true, notifyHR: false, notifyManager: true, notifyEmployee: true },
      overtimeRequest: { enabled: true, notifyHR: false, notifyManager: true, notifyEmployee: true },
      payrollReady: { enabled: true, notifyHR: false, notifyManager: false, notifyEmployee: true },
      documentExpiry: { enabled: true, notifyHR: true, notifyManager: false, notifyEmployee: true },
    }
  },
  rolePermissions: DEFAULT_ROLE_PERMISSIONS
};

export const MOCK_ORGANIZATIONS: Organization[] = [
  {
    id: 'ORG001',
    name: 'EmpowerHR Demo Corp',
    settings: DEFAULT_SETTINGS,
    createdAt: '2023-01-01',
    isActive: true
  },
  {
    id: 'ORG002',
    name: 'Tech Startup B',
    settings: {
        ...DEFAULT_SETTINGS,
        name: 'Tech Startup B',
        logoUrl: 'https://ui-avatars.com/api/?name=Tech+B&background=10b981&color=fff&size=128',
    },
    createdAt: '2023-05-01',
    isActive: true
  }
];

export const SUPER_ADMIN_ORG_ID = 'SUPER_ADMIN_SYS';
export const MOCK_COMPANY_SETTINGS = DEFAULT_SETTINGS;

const COMMON_DOCS: EmployeeDocument[] = [
  { id: 'D1', name: 'Employment_Contract.pdf', type: 'PDF', uploadDate: '2023-01-15', size: '2.4 MB', category: 'Contract', url: '#' },
  { id: 'D2', name: 'ID_Card_Copy.jpg', type: 'JPG', uploadDate: '2023-01-10', size: '1.1 MB', category: 'Identity', url: '#' },
  { id: 'D3', name: 'University_Transcript.pdf', type: 'PDF', uploadDate: '2023-01-10', size: '3.5 MB', category: 'Education', url: '#' },
];

const COMMON_ASSETS: Asset[] = [
  { id: 'A1', name: 'MacBook Pro 14"', serialNumber: 'FVFX1234XYZ', type: 'Laptop', assignedDate: '2023-01-15', status: 'Assigned', value: 75000 },
  { id: 'A2', name: 'Dell Monitor 27"', serialNumber: 'CN-0X123-74445', type: 'Monitor', assignedDate: '2023-01-15', status: 'Assigned', value: 12000 },
];

const WORK_HISTORY: WorkHistory[] = [
  { id: 'WH1', date: '2023-01-15', action: 'Joined', description: 'Started as IT Manager', by: 'System' },
  { id: 'WH2', date: '2023-05-15', action: 'Probation Passed', description: 'Passed probation with Score 95/100', by: 'HR Manager' },
];

export const MOCK_EMPLOYEES: Employee[] = [
  // --- SUPER ADMIN ---
  {
    id: 'ADMIN_YAFAD',
    orgId: SUPER_ADMIN_ORG_ID,
    firstName: 'Yafad',
    lastName: 'System Admin',
    email: 'yafad',
    phone: '1000000',
    position: 'Super Administrator',
    department: Department.EXECUTIVE,
    division: 'System',
    status: EmployeeStatus.PERMANENT,
    employmentType: EmploymentType.MONTHLY,
    role: Role.SUPER_ADMIN,
    joinDate: '2020-01-01',
    avatarUrl: 'https://ui-avatars.com/api/?name=Yafad+Admin&background=0f172a&color=fff',
    salary: 0,
    managerId: null,
    documents: [], assets: [], history: []
  },
  // --- ORG 001 Employees ---
  {
    id: 'E000',
    orgId: 'ORG001',
    firstName: 'อาทิตย์',
    lastName: 'บริหาร',
    email: 'arthit@company.com',
    phone: '081-111-1111',
    position: 'CEO',
    department: Department.EXECUTIVE,
    division: 'Management Board',
    status: EmployeeStatus.PERMANENT,
    employmentType: EmploymentType.MONTHLY,
    role: Role.CEO,
    joinDate: '2020-01-01',
    avatarUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=200',
    salary: 150000,
    basePositionAllowance: 20000,
    baseTravelAllowance: 5000,
    managerId: null,
    bankName: 'KBank',
    bankAccountNumber: '000-0-00000-0',
    documents: COMMON_DOCS,
    assets: [COMMON_ASSETS[0]],
    history: [{ id: 'H1', date: '2020-01-01', action: 'Joined', description: 'Founder', by: 'Board' }]
  },
  {
    id: 'E001',
    orgId: 'ORG001',
    firstName: 'สมชาย',
    lastName: 'ใจดี',
    email: 'somchai@company.com',
    phone: '089-999-8888',
    position: 'IT Manager',
    department: Department.IT,
    division: 'Technology',
    status: EmployeeStatus.PERMANENT,
    employmentType: EmploymentType.MONTHLY,
    role: Role.MANAGER,
    joinDate: '2022-01-15',
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200',
    salary: 85000,
    basePositionAllowance: 10000,
    baseTravelAllowance: 3000,
    managerId: 'E000',
    bankName: 'SCB',
    bankAccountNumber: '123-4-56789-0',
    gender: Gender.MALE,
    nationality: Nationality.THAI,
    religion: Religion.BUDDHISM,
    maritalStatus: MaritalStatus.MARRIED,
    address: '99/99 หมู่บ้านจัดสรร ถนนสุขุมวิท เขตบางนา กทม. 10260',
    emergencyContact: { firstName: 'สมหญิง', lastName: 'ใจดี', phone: '081-234-5678', relation: 'ภรรยา' },
    documents: COMMON_DOCS,
    assets: COMMON_ASSETS,
    history: WORK_HISTORY
  },
  {
    id: 'E002',
    orgId: 'ORG001',
    firstName: 'วิภา',
    lastName: 'รักงาน',
    email: 'wipa@company.com',
    phone: '086-555-4444',
    position: 'HR Manager',
    department: Department.HR,
    division: 'Administration',
    status: EmployeeStatus.PERMANENT,
    employmentType: EmploymentType.MONTHLY,
    role: Role.HR_MANAGER,
    joinDate: '2021-05-20',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200',
    salary: 55000,
    basePositionAllowance: 5000,
    baseDiligenceAllowance: 2000,
    managerId: 'E000',
    bankName: 'KBank',
    bankAccountNumber: '987-6-54321-0',
    documents: [COMMON_DOCS[0], COMMON_DOCS[1]],
    assets: [COMMON_ASSETS[0]],
    history: [{ id: 'H1', date: '2021-05-20', action: 'Joined', description: 'Started as HR Manager', by: 'CEO' }]
  },
  {
    id: 'E003',
    orgId: 'ORG001',
    firstName: 'Kyaw',
    lastName: 'Min',
    email: 'kyaw@company.com',
    phone: '090-123-4567',
    position: 'Developer',
    department: Department.IT,
    division: 'Technology',
    status: EmployeeStatus.PROBATION,
    employmentType: EmploymentType.MONTHLY,
    role: Role.STAFF,
    joinDate: '2023-09-01',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
    salary: 35000,
    baseDiligenceAllowance: 1000,
    managerId: 'E001',
    bankName: 'BBL',
    bankAccountNumber: '555-5-55555-5',
    nationality: Nationality.MYANMAR,
    documents: [], assets: [], history: []
  },
  {
    id: 'E004',
    orgId: 'ORG001',
    firstName: 'กานดา',
    lastName: 'มณี',
    email: 'kanda@company.com',
    phone: '091-234-5678',
    position: 'Junior Developer',
    department: Department.IT,
    division: 'Technology',
    status: EmployeeStatus.PERMANENT,
    employmentType: EmploymentType.MONTHLY,
    role: Role.STAFF,
    joinDate: '2023-01-01',
    avatarUrl: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=200',
    salary: 28000,
    baseDiligenceAllowance: 1000,
    managerId: 'E001',
    bankName: 'KBANK',
    bankAccountNumber: '111-222-333',
    documents: [], assets: [], history: []
  },
  {
    id: 'E005',
    orgId: 'ORG001',
    firstName: 'น้องใหม่',
    lastName: 'มาแรง',
    email: 'newbie@company.com',
    phone: '099-888-7777',
    position: 'Sales Executive',
    department: Department.SALES,
    division: 'Commercial',
    status: EmployeeStatus.PERMANENT,
    employmentType: EmploymentType.MONTHLY,
    role: Role.STAFF,
    joinDate: '2023-01-16', 
    avatarUrl: 'https://ui-avatars.com/api/?name=Nong+Mai&background=f472b6&color=fff',
    salary: 25000,
    basePerDiem: 3000,
    baseTravelAllowance: 2000,
    managerId: 'E000',
    bankName: 'SCB',
    bankAccountNumber: '999-9-99999-9',
    documents: [], assets: [], history: []
  }
];

const { attendance: generatedAttendance, timeRequests: generatedTimeRequests, leaves: generatedLeaves, expenses: generatedExpenses } = generateMockData();

export const MOCK_ATTENDANCE: AttendanceRecord[] = generatedAttendance;
export const MOCK_TIME_REQUESTS: TimeRequest[] = generatedTimeRequests;
export const MOCK_LEAVES: LeaveRequest[] = generatedLeaves;
export const MOCK_EXPENSES: ExpenseRequest[] = generatedExpenses;

export const MOCK_PAYROLL: PayrollRecord[] = [
  {
    id: 'PAY-NOV25-E001',
    orgId: 'ORG001',
    employeeId: 'E001',
    month: '2025-11',
    baseSalary: 85000,
    otHours: 10,
    ot: 5000,
    positionAllowance: 10000,
    travelAllowance: 3000,
    bonus: 0,
    expenses: 0,
    deduction: 750, 
    socialSecurity: 750,
    tax: 3000,
    lateDeduction: 0,
    lateCount: 0,
    netTotal: 98500,
    status: 'Paid',
    workflowStatus: PayrollWorkflowStatus.PAID,
    paymentDate: '2025-11-28',
    payableDays: 30,
    auditLogs: []
  }
];

export const MOCK_POSTS: Post[] = [
  { id: 'POST01', orgId: 'ORG001', authorId: 'E002', content: '🎉 ขอต้อนรับพนักงานใหม่ "น้องใหม่ มาแรง" (Sales) เข้าสู่ครอบครัว EmpowerHR ครับ!', timestamp: '2023-10-16T09:00:00', likes: 12, likedBy: [], comments: [], isAnnouncement: false }
];

export const MOCK_SHIFTS: Shift[] = [
  { id: 'S1', name: 'กะเช้า (Morning)', code: 'M', startTime: '08:00', endTime: '17:00', colorClass: 'bg-yellow-100 text-yellow-800 border-yellow-200' },
  { id: 'OFF', name: 'วันหยุด (Off)', code: 'OFF', startTime: '-', endTime: '-', colorClass: 'bg-slate-100 text-slate-500 border-slate-200' },
];

export const MOCK_SHIFT_ASSIGNMENTS: ShiftAssignment[] = [];
export const MOCK_TASKS: Task[] = [];
export const MOCK_TEAM_MESSAGES: TeamMessage[] = [];
export const MOCK_CHANNELS: Channel[] = [{ id: 'general', orgId: 'ORG001', name: 'General', description: 'พูดคุยทั่วไป', ownerId: 'E000', memberIds: ['E000', 'E001', 'E002', 'E003', 'E004', 'E005'], isPrivate: false }];

// Updated Mock Goals with Hierarchy
export const MOCK_GOALS: Goal[] = [
  {
    id: 'G1', orgId: 'ORG001', title: 'Achieve 100M Revenue', description: 'Company-wide annual target',
    type: GoalType.OKR, scope: GoalScope.COMPANY, metric: 'Revenue', targetValue: 100, currentValue: 65, unit: 'M THB',
    startDate: '2024-01-01', endDate: '2024-12-31', dueDate: '2024-12-31', 
    status: GoalStatus.IN_PROGRESS, approvalStatus: GoalApprovalStatus.APPROVED, // Set as Approved
    progress: 65, weight: 100
  },
  {
    id: 'G2', orgId: 'ORG001', divisionName: 'Technology', parentId: 'G1', // Linked to Company Goal
    title: 'Launch Product V2', description: 'Major tech milestone',
    type: GoalType.OKR, scope: GoalScope.DIVISION, metric: 'Milestones', targetValue: 5, currentValue: 3, unit: 'Phases',
    startDate: '2024-01-01', endDate: '2024-06-30', dueDate: '2024-06-30', 
    status: GoalStatus.IN_PROGRESS, approvalStatus: GoalApprovalStatus.APPROVED,
    progress: 60, weight: 50
  },
  {
    id: 'G3', orgId: 'ORG001', departmentId: Department.IT, parentId: 'G2', // Linked to Division Goal
    title: 'Migrate to Cloud', description: 'IT Dept Objective',
    type: GoalType.KPI, scope: GoalScope.DEPARTMENT, metric: 'Services', targetValue: 20, currentValue: 18, unit: 'Services',
    startDate: '2024-01-01', endDate: '2024-03-31', dueDate: '2024-03-31', 
    status: GoalStatus.IN_PROGRESS, approvalStatus: GoalApprovalStatus.APPROVED,
    progress: 90, weight: 30
  },
  {
    id: 'G4', orgId: 'ORG001', employeeId: 'E001', parentId: 'G3', // Linked to Dept Goal
    title: 'Setup Kubernetes Cluster', description: 'Somchai\'s Key Result',
    type: GoalType.KPI, scope: GoalScope.INDIVIDUAL, metric: 'Complete', targetValue: 1, currentValue: 1, unit: 'Cluster',
    startDate: '2024-02-01', endDate: '2024-02-28', dueDate: '2024-02-28', 
    status: GoalStatus.COMPLETED, approvalStatus: GoalApprovalStatus.APPROVED,
    progress: 100, weight: 20
  },
  // --- ADDED FOR TESTING: Active Goal for Check-in ---
  {
    id: 'G5', orgId: 'ORG001', employeeId: 'E001', // Somchai
    title: 'Complete React Certification', description: 'Self-improvement goal for Q1',
    type: GoalType.KPI, scope: GoalScope.INDIVIDUAL, metric: 'Course Modules', targetValue: 10, currentValue: 2, unit: 'Modules',
    startDate: '2024-01-01', endDate: '2024-03-31', dueDate: '2024-03-31', 
    status: GoalStatus.IN_PROGRESS, approvalStatus: GoalApprovalStatus.APPROVED, // Approved = Visible Update Button
    progress: 20, weight: 10
  }
];

export const MOCK_REVIEWS: PerformanceReview[] = [];
export const MOCK_KNOWLEDGE_BASE: KnowledgeItem[] = [];

// ... generateMockData logic ...
function generateMockData() {
  const attendance: AttendanceRecord[] = [];
  const timeRequests: TimeRequest[] = [];
  const leaves: LeaveRequest[] = [];
  const expenses: ExpenseRequest[] = [];
  
  // --- DECEMBER 2025 SIMULATION DATA (Full Payroll Test) ---
  const dec2025Days = Array.from({length: 31}, (_, i) => i + 1);
  const dec2025Prefix = '2025-12-';

  dec2025Days.forEach(day => {
     const d = String(day).padStart(2, '0');
     const dateStr = `${dec2025Prefix}${d}`;
     const dateObj = new Date(dateStr);
     const dayOfWeek = dateObj.getDay(); // 0 Sun, 6 Sat
     const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
     const isHoliday = day === 5 || day === 10 || day === 31; // Father's Day, Constitution, NYE

     // Work Days
     if (!isWeekend && !isHoliday) {
        // 1. E001 (Somchai) - Manager (Perfect Attendance + OT)
        attendance.push({ 
            id: `A-E001-${dateStr}`, orgId: 'ORG001', employeeId: 'E001', date: dateStr, 
            checkIn: `${dateStr}T08:30:00`, checkOut: `${dateStr}T19:00:00`, status: 'Present', checkInLocation: 'Office' 
        });

        // 2. E002 (Wipa) - HR (Vacation last week Dec 25-30)
        if (day < 25) {
            attendance.push({ 
                id: `A-E002-${dateStr}`, orgId: 'ORG001', employeeId: 'E002', date: dateStr, 
                checkIn: `${dateStr}T08:50:00`, checkOut: `${dateStr}T18:00:00`, status: 'Present', checkInLocation: 'Office' 
            });
        }

        // 3. E003 (Kyaw) - Dev (Late & Absent)
        if (day === 2 || day === 8 || day === 15) {
            // LATE 3 Times
            attendance.push({ 
                id: `A-E003-${dateStr}`, orgId: 'ORG001', employeeId: 'E003', date: dateStr, 
                checkIn: `${dateStr}T09:45:00`, checkOut: `${dateStr}T18:00:00`, status: 'Late', checkInLocation: 'Office' 
            });
        } else if (day === 20) {
            // ABSENT (No Record)
        } else {
            attendance.push({ 
                id: `A-E003-${dateStr}`, orgId: 'ORG001', employeeId: 'E003', date: dateStr, 
                checkIn: `${dateStr}T08:55:00`, checkOut: `${dateStr}T18:00:00`, status: 'Present', checkInLocation: 'Office' 
            });
        }

        // 4. E004 (Kanda) - Dev (Sick Leave & OT)
        if (day !== 18) { // 18 is Sick
            attendance.push({ 
                id: `A-E004-${dateStr}`, orgId: 'ORG001', employeeId: 'E004', date: dateStr, 
                checkIn: `${dateStr}T08:30:00`, checkOut: `${dateStr}T20:00:00`, status: 'Present', checkInLocation: 'Office' 
            });
        }

        // 5. E005 (Newbie) - Sales (Unpaid Leave)
        if (day !== 12) { // 12 is Unpaid Leave
             attendance.push({ 
                id: `A-E005-${dateStr}`, orgId: 'ORG001', employeeId: 'E005', date: dateStr, 
                checkIn: `${dateStr}T08:50:00`, checkOut: `${dateStr}T18:00:00`, status: 'Present', checkInLocation: 'Client Site' 
            });
        }
     }
  });

  // --- MOCK REQUESTS (APPROVED FOR PAYROLL) ---
  
  // 1. OT Requests
  timeRequests.push({ 
      id: 'OT-DEC25-1', orgId: 'ORG001', employeeId: 'E001', type: TimeRequestType.OT, 
      date: '2025-12-15', startTime: '18:00', endTime: '21:00', reason: 'Project Deadline', status: TimeRequestStatus.APPROVED 
  });
  timeRequests.push({ 
      id: 'OT-DEC25-2', orgId: 'ORG001', employeeId: 'E004', type: TimeRequestType.OT, 
      date: '2025-12-22', startTime: '18:00', endTime: '22:00', reason: 'Urgent Bug Fix', status: TimeRequestStatus.APPROVED 
  });

  // 2. Leave Requests
  leaves.push({ 
      id: 'L-DEC25-1', orgId: 'ORG001', employeeId: 'E002', type: LeaveType.VACATION, 
      startDate: '2025-12-25', endDate: '2025-12-30', reason: 'Year End Vacation', status: LeaveStatus.APPROVED 
  });
  leaves.push({ 
      id: 'L-DEC25-2', orgId: 'ORG001', employeeId: 'E004', type: LeaveType.SICK, 
      startDate: '2025-12-18', endDate: '2025-12-18', reason: 'Flu', status: LeaveStatus.APPROVED 
  });
  leaves.push({ 
      id: 'L-DEC25-3', orgId: 'ORG001', employeeId: 'E005', type: LeaveType.PERSONAL, 
      startDate: '2025-12-12', endDate: '2025-12-12', reason: 'Personal Business (Unpaid)', status: LeaveStatus.APPROVED 
  });

  // 3. Expenses
  expenses.push({
      id: 'EXP-DEC25-1', orgId: 'ORG001', employeeId: 'E001', type: ExpenseType.TRAVEL,
      amount: 2500, date: '2025-12-10', description: 'Client Visit (Grab)', status: ExpenseStatus.APPROVED
  });
  expenses.push({
      id: 'EXP-DEC25-2', orgId: 'ORG001', employeeId: 'E005', type: ExpenseType.FOOD,
      amount: 500, date: '2025-12-20', description: 'Team Lunch', status: ExpenseStatus.APPROVED
  });

  return { attendance, timeRequests, leaves, expenses };
}
