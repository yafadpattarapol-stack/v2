
export enum Department {
  HR = 'HR',
  IT = 'IT',
  SALES = 'Sales',
  MARKETING = 'Marketing',
  OPERATIONS = 'Operations',
  EXECUTIVE = 'Executive'
}

// Updated Status per request
export enum EmployeeStatus {
  PROBATION = 'ทดลองงาน (Probation)',
  PERMANENT = 'บรรจุ (Permanent)',
  RESIGNED = 'ลาออก (Resigned)',
  RETIRED = 'เกษียณ (Retired)',
  TERMINATED = 'เลิกจ้าง (Terminated)'
}

export enum EmploymentType {
  MONTHLY = 'รายเดือน (Monthly)',
  DAILY = 'รายวัน (Daily)',
  PART_TIME = 'พาร์ทไทม์ (Part-time)',
  CONTRACT = 'สัญญาจ้าง (Contract)'
}

export enum Role {
  SUPER_ADMIN = 'Super Admin',
  CEO = 'CEO',
  HR_MANAGER = 'HR Manager',
  HR_STAFF = 'HR Staff',
  MANAGER = 'Manager',
  STAFF = 'Staff'
}

export enum Gender {
  MALE = 'ชาย (Male)',
  FEMALE = 'หญิง (Female)',
  OTHER = 'อื่นๆ (Other)'
}

export enum Nationality {
  THAI = 'ไทย (Thai)',
  LAO = 'ลาว (Lao)',
  MYANMAR = 'พม่า (Myanmar)',
  CAMBODIAN = 'กัมพูชา (Cambodian)',
  OTHER = 'อื่นๆ (Other)'
}

export enum Religion {
  BUDDHISM = 'พุทธ (Buddhism)',
  ISLAM = 'อิสลาม (Islam)',
  CHRISTIANITY = 'คริสต์ (Christianity)',
  HINDUISM = 'ฮินดู (Hinduism)',
  OTHER = 'อื่นๆ (Other)',
  NONE = 'ไม่ระบุ (None)'
}

export enum MaritalStatus {
  SINGLE = 'โสด (Single)',
  MARRIED = 'สมรส (Married)',
  DIVORCED = 'หย่าร้าง (Divorced)',
  WIDOWED = 'หม้าย (Widowed)'
}

export enum Tab {
  DASHBOARD = 'dashboard',
  APPROVALS = 'approvals',
  EMPLOYEES = 'employees',
  ATTENDANCE = 'attendance',
  SHIFT = 'shift',
  LEAVE = 'leave',
  PAYROLL = 'payroll',
  COLLAB = 'collab',
  AI = 'ai',
  SETTINGS = 'settings',
  PERFORMANCE = 'performance',
  SUPER_ADMIN = 'super_admin',
  PROFILE = 'profile' // New Mobile Profile Tab
}

export interface EmergencyContact {
  firstName: string;
  lastName: string;
  phone: string;
  relation: string;
}

// --- New Types for 360 Profile ---
export interface EmployeeDocument {
  id: string;
  name: string;
  type: 'PDF' | 'JPG' | 'DOCX';
  uploadDate: string;
  size: string;
  category: 'Contract' | 'Identity' | 'Education' | 'Other';
  url: string;
}

export interface Asset {
  id: string;
  name: string;
  serialNumber: string;
  type: 'Laptop' | 'Monitor' | 'Mobile' | 'Peripheral' | 'Other';
  assignedDate: string;
  status: 'Assigned' | 'Returned' | 'Repair';
  value?: number;
}

export interface WorkHistory {
  id: string;
  date: string;
  action: 'Joined' | 'Promoted' | 'Salary Adjustment' | 'Transfer' | 'Probation Passed';
  description: string;
  by: string; // Adjusted by whom
}

export interface Employee {
  id: string;
  orgId: string; // Multi-tenant ID
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  
  // Security
  password?: string;
  forcePasswordChange?: boolean;

  // Personal Fields
  nationalId?: string; // เลขบัตรประชาชน
  passportNo?: string; // เลขพาสปอร์ต (For foreigners)
  workPermitNo?: string; // เลขใบอนุญาตทำงาน
  ssoNo?: string; // เลขประกันสังคม
  
  gender?: Gender;
  birthDate?: string; // YYYY-MM-DD
  nationality?: Nationality;
  religion?: Religion;
  maritalStatus?: MaritalStatus;
  
  address?: string;
  emergencyContact?: EmergencyContact;
  
  // Bank Details (Added as necessary)
  bankName?: string;
  bankAccountNumber?: string;

  // Work Fields
  position: string;
  department: string; // Changed from enum to string to allow custom departments
  division?: string; // ฝ่าย
  status: EmployeeStatus;
  employmentType: EmploymentType;
  role: Role;
  
  // Dates
  joinDate: string; // วันเริ่มงาน
  probationDate?: string; // วันผ่านโปร/บรรจุ
  resignDate?: string; // วันลาออก
  retireDate?: string; // วันเกษียณ

  avatarUrl: string;
  
  // Salary History
  salary: number; // Current Base Salary (เงินเดือนปัจจุบัน)
  startingSalary?: number; // เงินเดือนเริ่มต้น
  probationSalary?: number; // เงินเดือนหลังบรรจุ

  // Base Allowances (Standard recurring payments)
  basePositionAllowance?: number; // ค่าตำแหน่งมาตรฐาน
  baseTravelAllowance?: number; // ค่าเดินทางมาตรฐาน
  basePerDiem?: number; // เบี้ยเลี้ยงมาตรฐาน
  baseDiligenceAllowance?: number; // เบี้ยขยันมาตรฐาน

  managerId?: string | null;

  // Extended Profile Data
  documents?: EmployeeDocument[];
  assets?: Asset[];
  history?: WorkHistory[];
}

export interface AttendanceRecord {
  id: string;
  orgId: string; // Multi-tenant ID
  employeeId: string;
  date: string; // YYYY-MM-DD
  checkIn: string | null; // ISO Date string
  checkOut: string | null; // ISO Date string
  status: 'Present' | 'Late' | 'Absent' | 'Half-Day';
  
  // New fields for Mock GPS & Photo
  checkInLocation?: string;
  checkInPhoto?: string;
  checkInNote?: string;
  
  checkOutLocation?: string;
  checkOutPhoto?: string;
  checkOutNote?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

// --- New Modules ---

export enum LeaveType {
  SICK = 'ลาป่วย (Sick Leave)',
  VACATION = 'ลาพักร้อน (Vacation)',
  PERSONAL = 'ลากิจ (Personal Leave)',
  MATERNITY = 'ลาคลอด (Maternity)'
}

export enum LeaveStatus {
  PENDING = 'รออนุมัติ',
  APPROVED = 'อนุมัติ',
  REJECTED = 'ไม่อนุมัติ'
}

export interface LeaveRequest {
  id: string;
  orgId: string; // Multi-tenant ID
  employeeId: string;
  type: string; // Changed from LeaveType to string to allow custom types
  startDate: string;
  endDate: string;
  reason: string;
  status: LeaveStatus;
}

// Workflow Status Enum
export enum PayrollWorkflowStatus {
  DRAFT = 'Draft',             // 1. Calculate: Editable
  VERIFIED = 'Verified',       // 2. Checked by HR: Editable
  APPROVED = 'Approved',       // 3. Approved by CEO: Locked
  BANK_PROCESSING = 'BankProcessing', // 4. Sent to Bank: Locked
  PAID = 'Paid'                // 5. Completed: Locked
}

// Audit Log Interfaces
export interface PayrollChange {
  field: string;
  oldValue: any;
  newValue: any;
}

export interface PayrollAuditLog {
  id: string;
  timestamp: string;
  actorId: string; // Who made the change
  action: 'Create' | 'Update' | 'StatusChange' | 'Recalculate' | 'System';
  details: string; // Human readable summary
  changes?: PayrollChange[]; // Detailed breakdown
}

export interface PayrollRecord {
  id: string;
  orgId: string; // Multi-tenant ID
  employeeId: string;
  month: string; // "YYYY-MM"
  baseSalary: number;
  
  // Earnings
  otHours: number;
  ot: number; // Amount
  positionAllowance?: number; // ค่าตำแหน่ง
  travelAllowance?: number; // ค่าเดินทาง
  perDiem?: number; // เบี้ยเลี้ยง
  diligenceAllowance?: number; // เบี้ยขยัน
  bonus?: number; // โบนัส
  expenses?: number; // Approved Expenses (New)
  
  // Deductions
  deduction: number; // General deductions (Deprecated/Combined)
  otherDeduction?: number; // หักอื่นๆ
  absentDeduction?: number; // ขาดงาน
  unpaidLeaveDeduction?: number; // ลาไม่รับเงิน (Leave without Pay)
  lateCount: number;
  lateDeduction: number; // สาย
  socialSecurity: number;
  tax: number;
  
  netTotal: number;
  status: 'Paid' | 'Pending'; // Payment Status
  paymentDate?: string;
  
  // Transparency fields
  payableDays?: number; // Calculated days (e.g., 16/30)
  memo?: string; // E.g., "Prorated (Join 15 Mar)"
  
  // History Snapshot
  isFinalized?: boolean; // New: True = Locked/Final, False = Draft
  isOutSync?: boolean; // New: True = Data changed after calculation (Needs Recalc)
  calculatedAt?: string; // ISO Date of calculation
  ruleSnapshot?: string; // JSON string of rules used

  // Manual Adjustment Fields (HR Override)
  isAdjusted?: boolean;
  manualAdjustment?: number; // +/- amount
  manuallyOverriddenFields?: string[]; // New: Track which fields are manual
  adjustmentReason?: string;
  paymentNote?: string; // General note/remark from HR (e.g., Bonus included)

  // 2-Step Verification Audit Trail
  workflowStatus: PayrollWorkflowStatus;
  verifiedBy?: string; // Employee ID of HR who verified
  verifiedAt?: string; // ISO Date
  approvedBy?: string; // Employee ID of Approver
  approvedAt?: string; // ISO Date
  revision?: number; // Revision counter
  
  // Full Audit Trail
  auditLogs: PayrollAuditLog[]; 
}

// --- Expenses ---
export enum ExpenseType {
  TRAVEL = 'ค่าเดินทาง (Travel)',
  FOOD = 'ค่าเบี้ยเลี้ยง/อาหาร (Food/Per Diem)',
  EQUIPMENT = 'อุปกรณ์ทำงาน (Equipment)',
  OTHER = 'อื่นๆ (Other)'
}

export enum ExpenseStatus {
  PENDING = 'รอตรวจสอบ',
  APPROVED = 'อนุมัติ',
  REJECTED = 'ไม่อนุมัติ',
  PAID = 'จ่ายแล้ว'
}

export interface ExpenseRequest {
  id: string;
  orgId: string; // Multi-tenant ID
  employeeId: string;
  type: ExpenseType;
  amount: number;
  date: string;
  description: string;
  receiptUrl?: string;
  status: ExpenseStatus;
}

export interface PostComment {
  id: string;
  authorId: string;
  content: string;
  timestamp: string;
}

export interface Post {
  id: string;
  orgId: string; // Multi-tenant ID
  authorId: string;
  content: string;
  timestamp: string;
  likes: number; // Count
  likedBy: string[]; // IDs of employees who liked
  comments: PostComment[];
  isAnnouncement?: boolean; // New: Is this a company-wide announcement?
}

export interface AppNotification {
  id: string;
  orgId: string;
  userId: string; // The receiver
  type: 'Announcement' | 'Alert' | 'Task';
  title: string;
  message: string;
  isRead: boolean;
  timestamp: string;
  linkTo?: Tab;
}

// --- Shift Management ---

export interface Shift {
  id: string;
  // Shifts are usually org-specific settings now, but for simplicity in types we keep it generic or attach orgId if needed
  name: string;
  code: string;
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  colorClass: string;
}

export interface ShiftAssignment {
  id: string;
  orgId: string; // Multi-tenant ID
  employeeId: string;
  date: string; // YYYY-MM-DD
  shiftId: string;
}

// --- Time Adjustment & OT ---

export enum TimeRequestType {
  ADJUSTMENT = 'Time Adjustment (แก้ไขเวลา)',
  OT = 'Overtime Request (ขอทำ OT)'
}

export enum TimeRequestStatus {
  PENDING = 'Pending',
  APPROVED = 'Approved',
  REJECTED = 'Rejected'
}

export interface TimeRequest {
  id: string;
  orgId: string; // Multi-tenant ID
  employeeId: string;
  type: TimeRequestType;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  reason: string;
  status: TimeRequestStatus;
}

// --- Task Management (Enhanced for Lark-like features) ---
export type TaskStatus = 'Todo' | 'In Progress' | 'Done';
export type TaskPriority = 'Low' | 'Medium' | 'High';

export interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}

export interface TaskComment {
  id: string;
  authorId: string;
  content: string;
  timestamp: string;
}

export interface Task {
  id: string;
  orgId: string; // Multi-tenant ID
  title: string;
  description: string;
  assigneeId: string; // The person doing the task
  reporterId?: string; // The owner/creator of the task
  collaboratorIds?: string[]; // People involved/watching
  dueDate: string;
  status: TaskStatus;
  priority: TaskPriority;
  createdAt: string; // New Field
  
  // Extended Lark-like features
  checklist: ChecklistItem[];
  comments: TaskComment[];
  tags: string[];
  attachments: string[]; // URLs
}

// --- Chat System ---
export interface Channel {
  id: string;
  orgId: string; // Multi-tenant ID
  name: string;
  description?: string;
  ownerId: string;
  memberIds: string[];
  avatarUrl?: string; // URL or Emoji
  isPrivate: boolean;
}

export interface TeamMessage {
  id: string;
  orgId: string; // Multi-tenant ID
  senderId: string;
  receiverId?: string | null; // If null, it's a channel message
  channelId?: string; // 'general', 'announcements', etc.
  content: string;
  timestamp: string;
}

// --- Settings ---
export interface PayrollRules {
  socialSecurityRate: number; // e.g. 0.05 (5%)
  maxSocialSecurityBase: number; // e.g. 15000
  latePenaltyPerTime: number; // e.g. 100 THB
  otRateMultiplier: number; // e.g. 1.5
}

// Detailed condition rule
export interface EmploymentConditionRule {
  action: 'None' | 'DeductSalary'; // ไม่มีการหัก | หักเป็นเงิน
  calculationMode: 'ProRated' | 'Fixed'; // คิดตามสัดส่วนเงินได้ | กำหนดเอง
  fixedAmount?: number;
  enabled: boolean;
}

// Detailed OT Rule
export interface OTRateConfig {
  mode: 'Multiplier' | 'Fixed'; // คูณเท่า | เหมาจ่าย
  rate: number;
}

// Standard 5-tier OT Structure for Thai Payroll (Granular Control)
export interface OTRule {
  enabled: boolean;
  rates: {
    otNormal: OTRateConfig;          // OT วันทำงานปกติ (1.5x)
    
    // Weekly Holiday (วันหยุดประจำสัปดาห์)
    workDayOff: OTRateConfig;        // ทำงานวันหยุด (เวลาปกติ)
    otDayOff: OTRateConfig;          // OT วันหยุด (นอกเวลาปกติ)
    
    // Public Holiday (วันหยุดนักขัตฤกษ์)
    workPublicHoliday: OTRateConfig; // ทำงานวันหยุดนักขัตฤกษ์ (เวลาปกติ)
    otPublicHoliday: OTRateConfig;   // OT วันหยุดนักขัตฤกษ์ (นอกเวลาปกติ)
  };
}

export interface EmploymentTypeConfig {
  id: string;
  name: string;
  nameEn: string;
  paymentType: 'Monthly' | 'Daily'; // รายเดือน / รายวัน
  
  // Salary Calculation
  // Standard30: (Salary/30) * WorkDays. Capped at Salary.
  // Custom: Manual override
  // ActualDays: Added back for type compatibility if needed, though UI enforces Standard30
  salaryBasis: 'Standard30' | 'Custom' | 'ActualDays'; 
  
  // OT Calculation
  otBasis: 'Salary' | 'Custom'; // ตามเงินเดือน / กำหนดเอง
  
  // Granular Conditions
  conditions: {
    ot: OTRule;
    late: EmploymentConditionRule;
    absent: EmploymentConditionRule;
    missingPunch: EmploymentConditionRule; // ลืมลงเวลา
    earlyLeave: EmploymentConditionRule;
  };
  
  // Tax & SSO
  calculateTax: boolean;
  calculateSSO: boolean;
}

// --- Notification Settings ---
export interface NotificationRule {
  enabled: boolean;
  notifyHR: boolean;
  notifyManager: boolean;
  notifyEmployee: boolean;
}

export interface NotificationSettings {
  probation: {
    day30: NotificationRule;
    day60: NotificationRule;
    day90: NotificationRule;
    day119: NotificationRule;
  };
  general: {
    leaveRequest: NotificationRule;
    overtimeRequest: NotificationRule;
    payrollReady: NotificationRule;
    documentExpiry: NotificationRule;
  };
}

// --- Dynamic Granular Permissions ---
export type PermissionKey = 
  // Employee
  | 'employee_view'       // View employee list and basic profiles
  | 'employee_view_full'  // View full profile (salary, personal)
  | 'employee_create'     // Create new employee
  | 'employee_edit'       // Edit employee data
  | 'employee_delete'     // Remove employee
  
  // Time & Attendance
  | 'attendance_view'     // View attendance logs
  | 'attendance_manage'   // Edit attendance / manage requests
  | 'shift_manage'        // Manage shifts/schedules
  
  // Leave
  | 'leave_view'          // View leave calendar/requests
  | 'leave_approve'       // Approve/Reject leave
  
  // Payroll
  | 'payroll_view'        // View payroll dashboard (overview)
  | 'payroll_calc'        // Run calculations
  | 'payroll_approve'     // Approve payments
  | 'payroll_export'      // Export bank files
  
  // Performance
  | 'goal_view'           // View goals
  | 'goal_manage'         // Create/Edit/Delete goals
  | 'review_manage'       // Conduct reviews
  
  // System
  | 'settings_manage'     // Manage company settings
  | 'data_view_all'       // See all data across departments (Admin/CEO)
  | 'announcement_create' // Post company announcements
;

export interface RolePermissions {
  role: Role;
  permissions: PermissionKey[];
}

export interface CheckInLocation {
  id: string;
  name: string;
  lat: number;
  lng: number;
  radius: number; // meters
}

export interface CompanySettings {
  name: string;
  nameEn?: string; // English Name
  address: string;
  phone: string;
  email?: string;
  website?: string;
  
  // Legal & IDs
  taxId?: string; // เลขประจำตัวผู้เสียภาษี
  socialSecurityId?: string; // เลขประกันสังคมนายจ้าง
  branchCode?: string; // รหัสสาขา (00000)
  logoUrl?: string;

  // Work Rules
  workDays: string[]; // e.g., ["Mon", "Tue"...]
  workStartTime: string;
  workEndTime: string;
  lateThresholdMinutes: number; // Late after 9:15 etc.
  
  // Holidays
  publicHolidays: { id: string; date: string; name: string }[];
  
  // Leave Policy
  leaveQuotas: { type: string; quota: number }[]; // Quota in days per year
  
  // Payroll Rules
  payrollRules: PayrollRules;
  employmentTypes: EmploymentTypeConfig[];

  // Location / Geofencing
  isGeofencingEnabled: boolean;
  gpsLatitude: number; // Keep for backward compatibility/default
  gpsLongitude: number; // Keep for backward compatibility/default
  gpsRadiusMeters: number; // Keep for backward compatibility/default
  locations: CheckInLocation[]; // NEW: Multi-location support

  // Notification
  notificationSettings: NotificationSettings;

  // RBAC Settings
  rolePermissions: RolePermissions[];
}

// --- Organization Entity (Multi-Tenancy) ---
export interface Organization {
  id: string;
  name: string;
  settings: CompanySettings;
  createdAt: string;
  isActive: boolean;
}

// --- Performance ---
export enum GoalType {
  KPI = 'KPI',
  OKR = 'OKR'
}

// Execution Status (ความคืบหน้า)
export enum GoalStatus {
  NOT_STARTED = 'Not Started',
  IN_PROGRESS = 'In Progress',
  COMPLETED = 'Completed'
}

// Workflow Status (สถานะการอนุมัติ) - NEW for Annual Goal Flow
export enum GoalApprovalStatus {
  DRAFT = 'Draft',             // ร่าง: แก้ไขได้, ยังไม่ส่ง
  PENDING = 'Pending Review',  // รออนุมัติ: ล็อคชั่วคราว, รอ Manager
  APPROVED = 'Approved',       // อนุมัติแล้ว: ล็อคถาวร (แก้ไขไม่ได้ถ้าไม่ปลดล็อค)
  REJECTED = 'Rejected'        // ตีกลับ: กลับมาแก้ไขได้
}

export enum GoalScope {
  COMPANY = 'Company',
  DIVISION = 'Division',
  DEPARTMENT = 'Department',
  INDIVIDUAL = 'Individual'
}

export interface Goal {
  id: string;
  orgId: string; // Multi-tenant ID
  employeeId?: string; // Optional for Company scope
  departmentId?: string; // Only for Department scope
  divisionName?: string; // New: For Division scope
  parentId?: string; // New: Link to parent goal (Alignment)
  title: string;
  description: string;
  
  status: GoalStatus; // Execution Status
  approvalStatus: GoalApprovalStatus; // New: Workflow Status
  
  progress: number;
  dueDate: string;
  // Extended fields
  type: GoalType;
  scope: GoalScope; // Updated Scope Field
  metric: string;
  targetValue: number;
  currentValue: number;
  unit: string;
  startDate: string;
  endDate?: string;
  weight: number;
  
  feedback?: string; // Reason for rejection
  
  // --- NEW: Progress Verification Workflow ---
  pendingCurrentValue?: number; // Temporary value awaiting approval
  pendingUpdateNote?: string; // NEW: Comment/Evidence for the update
  lastUpdatedBy?: string; // ID of person who updated
}

export interface CompetencyScore {
  name: string;
  rating: number; // 1-5
  comment?: string;
}

export interface PerformanceReview {
  id: string;
  orgId: string; // Multi-tenant ID
  employeeId: string;
  reviewerId: string;
  period: string; // e.g. "Q4 2025"
  
  // Scores
  goalsScore: number; // % Achievement from Goals (Weighted)
  competencyScore: number; // % from Competencies
  finalScore: number; // 70:30 Split (or other config)
  grade: 'A' | 'B' | 'C' | 'D' | 'F';
  
  rating: number; // Legacy field (can act as final star rating 1-5)
  feedback: string;
  date: string;
  
  status: 'Draft' | 'Submitted' | 'Finalized';
  
  // Details
  competencies?: CompetencyScore[];
}

// --- Knowledge Base (AI) ---
export interface KnowledgeItem {
  id: string;
  orgId: string; // Multi-tenant ID
  title: string;
  category: 'Policy' | 'Benefit' | 'Bonus' | 'General';
  content: string;
  lastUpdated: string;
}
