
import { Role, PermissionKey, RolePermissions } from '../types';
import { DEFAULT_ROLE_PERMISSIONS } from '../constants';

/**
 * Centralized Permission Logic
 * Now Supports Dynamic Role-Based Access Control (RBAC) via settings.
 */

// Helper to check dynamic permissions
const hasPermission = (role: Role, key: PermissionKey, rolePermissions: RolePermissions[] = DEFAULT_ROLE_PERMISSIONS): boolean => {
  // 1. Super Admin always has full access (Hardcoded Safety)
  if (role === Role.SUPER_ADMIN) return true;

  // 2. Safe Fallback: If rolePermissions is null/undefined, use defaults
  const permissionsList = rolePermissions || DEFAULT_ROLE_PERMISSIONS;

  // 3. Find config for this role
  const config = permissionsList.find(rp => rp.role === role);
  
  // 4. Check if key exists in enabled permissions (Safe Access)
  return config ? (config.permissions || []).includes(key) : false;
};

// IMPORTANT: This object maps old "feature-based" checks to the new "granular permission keys".
// This ensures we don't have to refactor the entire app's component logic immediately.
export const Permissions = {
  // สิทธิ์ในการจัดการข้อมูลพนักงาน (เพิ่ม/แก้ไข/ลบ)
  canManageEmployees: (role: Role, rolePermissions?: RolePermissions[]): boolean => {
    // Requires either Create or Edit rights
    return hasPermission(role, 'employee_create', rolePermissions) || hasPermission(role, 'employee_edit', rolePermissions);
  },

  // สิทธิ์ในการจัดการเงินเดือน (คำนวณ/สั่งจ่าย/แก้ไข)
  canManagePayroll: (role: Role, rolePermissions?: RolePermissions[]): boolean => {
    return hasPermission(role, 'payroll_calc', rolePermissions);
  },

  // สิทธิ์ในการดูข้อมูลเงินเดือน (ดูภาพรวม) - HR Staff อาจดูได้แต่แก้ไม่ได้
  canViewPayroll: (role: Role, rolePermissions?: RolePermissions[]): boolean => {
    return hasPermission(role, 'payroll_view', rolePermissions);
  },

  // สิทธิ์ในการอนุมัติคำขอต่างๆ (ลา/OT/เบิกจ่าย)
  canApproveRequests: (role: Role, rolePermissions?: RolePermissions[]): boolean => {
    // A generic check for "Approver". Usually tied to Leave/Attendance
    return hasPermission(role, 'leave_approve', rolePermissions) || hasPermission(role, 'attendance_manage', rolePermissions);
  },

  // สิทธิ์ในการจัดการโครงสร้างองค์กรและตั้งค่าระบบ
  canEditCompanySettings: (role: Role, rolePermissions?: RolePermissions[]): boolean => {
    return hasPermission(role, 'settings_manage', rolePermissions);
  },

  // สิทธิ์ในการจัดการประเมินผล (Performance)
  canManagePerformance: (role: Role, rolePermissions?: RolePermissions[]): boolean => {
    return hasPermission(role, 'goal_manage', rolePermissions) || hasPermission(role, 'review_manage', rolePermissions);
  },

  // สิทธิ์ในการมองเห็นข้อมูลทั้งองค์กร (ถ้าไม่มีสิทธิ์นี้ จะเห็นแค่ทีมตัวเองหรือตัวเอง)
  canViewAllData: (role: Role, rolePermissions?: RolePermissions[]): boolean => {
    return hasPermission(role, 'data_view_all', rolePermissions);
  },
  
  // --- New Granular Helpers (for future use) ---
  canViewEmployees: (role: Role, rolePermissions?: RolePermissions[]): boolean => hasPermission(role, 'employee_view', rolePermissions),
  canDeleteEmployees: (role: Role, rolePermissions?: RolePermissions[]): boolean => hasPermission(role, 'employee_delete', rolePermissions),
  canPostAnnouncement: (role: Role, rolePermissions?: RolePermissions[]): boolean => hasPermission(role, 'announcement_create', rolePermissions),
};
